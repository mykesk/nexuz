#https://es.stackoverflow.com/questions/84389/c%C3%B3mo-hacer-truncate-table-en-sqlite
#https://docs.python.org/3/library/sqlite3.html
# algoritmo de "The Gestalt Approach" para similitudes

import sqlite3
import pandas as pd 
import os
import difflib
import pyautogui as py
import getpass
import socket
from datetime import datetime
#==============================================================================  
USERNAME = getpass.getuser().upper()
PCNAME = socket.gethostname().upper()
#==============================================================================
# Funciones para gestionar múltiples períodos cargados
#==============================================================================
def GuardarPeriodoCargado(base_p, periodo):
    """Agrega un período a la lista de cargados"""
    try:
        conn = sqlite3.connect(base_p)
        cur = conn.cursor()
        
        # Crear tabla de configuración si no existe
        cur.execute('''CREATE TABLE IF NOT EXISTS config_app 
                       (clave TEXT PRIMARY KEY, valor TEXT)''')
        
        # Obtener períodos cargados actuales
        cur.execute('SELECT valor FROM config_app WHERE clave = "periodos_cargados"')
        resultado = cur.fetchone()
        
        if resultado:
            periodos = resultado[0].split("|")
        else:
            periodos = []
        
        # Agregar nuevo período si no existe
        if periodo not in periodos:
            periodos.append(periodo)
            periodos_str = "|".join(periodos)
            
            cur.execute('DELETE FROM config_app WHERE clave = "periodos_cargados"')
            cur.execute('INSERT INTO config_app (clave, valor) VALUES (?, ?)', 
                        ('periodos_cargados', periodos_str))
        
        conn.commit()
        conn.close()
        print(f" Período guardado: {periodo}")
    except Exception as e:
        print(f"Error guardando período: {e}")

def ObtenerPeriodosDisponibles(base_p):
    """Obtiene lista de períodos cargados"""
    try:
        conn = sqlite3.connect(base_p)
        cur = conn.cursor()
        
        # Crear tabla si no existe
        cur.execute('''CREATE TABLE IF NOT EXISTS config_app 
                       (clave TEXT PRIMARY KEY, valor TEXT)''')
        
        # Obtener períodos disponibles
        cur.execute('SELECT valor FROM config_app WHERE clave = "periodos_cargados"')
        resultado = cur.fetchone()
        conn.close()
        
        if resultado and resultado[0]:
            return resultado[0].split("|")
        else:
            return []
    except Exception as e:
        print(f"Error leyendo períodos: {e}")
        return []

def LimpiarPeriodoCargado(base_p, periodo):
    """Elimina un período de la lista de cargados"""
    try:
        conn = sqlite3.connect(base_p)
        cur = conn.cursor()
        
        # Obtener períodos cargados actuales
        cur.execute('SELECT valor FROM config_app WHERE clave = "periodos_cargados"')
        resultado = cur.fetchone()
        
        if resultado:
            periodos = resultado[0].split("|")
            if periodo in periodos:
                periodos.remove(periodo)
                periodos_str = "|".join(periodos) if periodos else ""
                
                cur.execute('DELETE FROM config_app WHERE clave = "periodos_cargados"')
                if periodos_str:
                    cur.execute('INSERT INTO config_app (clave, valor) VALUES (?, ?)', 
                                ('periodos_cargados', periodos_str))
        
        conn.commit()
        conn.close()
        print(f" Período limpiado: {periodo}")
    except Exception as e:
        print(f"Error limpiando período: {e}")

#==============================================================================  
# Función para normalizar separadores en archivos grandes (;  -> |)
#==============================================================================
def NormalizarSeparadoresEnArchivo(nombre_archivo, encoding='latin-1', tamanio_buffer=8192*10):
    """
    Normaliza archivos TXT grandes reemplazando ";" por "|" de forma eficiente.
    Procesa el archivo en buffers para no cargar todo en memoria.
    
    Args:
        nombre_archivo: Ruta del archivo TXT
        encoding: Codificación del archivo (default: latin-1)
        tamanio_buffer: Tamaño del buffer en bytes (default: ~80KB por lectura)
    
    Returns:
        nombre_archivo (sin cambios, modifica el archivo in-place)
    """
    try:
        print(f" Normalizando separadores en archivo: {nombre_archivo}")
        print(f"   Tamaño buffer: {tamanio_buffer / 1024:.1f} KB")
        
        archivo_temp = nombre_archivo + '.normalizando'
        contador_filas = 0
        contador_cambios = 0
        
        with open(nombre_archivo, 'r', encoding=encoding) as f_original:
            with open(archivo_temp, 'w', encoding=encoding) as f_temporal:
                while True:
                    # Leer buffer del archivo
                    contenido = f_original.read(tamanio_buffer)
                    
                    if not contenido:
                        break
                    
                    # Reemplazar ; por | (conserva los ; dentro de comillas si existen)
                    contenido_normalizado = contenido.replace(';', '|')
                    contador_cambios += contenido.count(';')
                    
                    # Escribir buffer normalizado
                    f_temporal.write(contenido_normalizado)
                    
                    # Contar líneas procesadas (aproximado)
                    contador_filas += contenido.count('\n')
                    
                    if contador_filas % 1000000 == 0 and contador_filas > 0:
                        print(f"   Procesadas {contador_filas:,} filas ({contador_cambios:,} ; reemplazados)")
        
        # Reemplazar archivo original con el normalizado
        import shutil
        shutil.move(archivo_temp, nombre_archivo)
        
        print(f" Normalización completada:")
        print(f"   Total filas procesadas: {contador_filas:,}")
        print(f"   Total ';' reemplazados por '|': {contador_cambios:,}")
        return nombre_archivo
        
    except Exception as e:
        print(f" Error normalizando archivo: {e}")
        # Limpiar archivo temporal si existe
        try:
            import os
            if os.path.exists(nombre_archivo + '.normalizando'):
                os.remove(nombre_archivo + '.normalizando')
        except:
            pass
        raise

#==============================================================================  
# 
# 
#==============================================================================
def CargarDataBaseSQLite(nombre_archivo,base_p,nombre_tabla,periodo=""):
    pass
    try:
        c=1
        l=1000000
        # Si se especifica período, usar tabla específica del período
        if periodo:
            tabla_final = nombre_tabla + "_" + periodo
        else:
            tabla_final = nombre_tabla
        
        # PASO 1: Normalizar separadores en el archivo ANTES de cargarlo
        print("PASO 1: Normalizando separadores en el archivo TXT...")
        NormalizarSeparadoresEnArchivo(nombre_archivo)
        print("PASO 1:  Separadores normalizados\n")
        
        # PASO 2: Cargar con pandas usando separador estandarizado
        print("PASO 2: Cargando datos a base de datos...")
        for df in pd.read_csv(nombre_archivo, sep="|", encoding='latin-1', keep_default_na=False, dtype=str, chunksize=l):
            print("Lectura parte --->" + str(c))
            df.columns = df.columns.str.strip()
            conn = sqlite3.connect(base_p)
            df.to_sql(tabla_final, conn, if_exists='append', index=False)
            conn.close()
            c=c+1
        
        del df
        print(f" Datos cargados en tabla: {tabla_final}")
    except:
       try:
           conn.close()
       except:
           pass
       pass
#==============================================================================  
#==============================================================================  
# 
# 
#==============================================================================
def DeleteTotalBaseSQLite(nombre_tabla,base_p):
    try:
        conn = sqlite3.connect(base_p)
        cur = conn.cursor()
        cur.execute("DELETE FROM " + nombre_tabla)
        conn.commit()
        conn.close()
    except:
       conn.close()
       pass

#==============================================================================
#==============================================================================
def DropTableBaseSQLite(nombre_tabla,base_p,periodo=""):
    try:
        # Si se especifica período, usar tabla específica del período
        if periodo:
            tabla_final = nombre_tabla + "_" + periodo
        else:
            tabla_final = nombre_tabla
            
        conn = sqlite3.connect(base_p)
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS " + tabla_final)
        cur.execute('VACUUM')
        conn.commit()
        conn.close()
        print(f" Tabla eliminada: {tabla_final}")
    except:
       try:
           conn.close()
       except:
           pass
       pass

#==============================================================================
#==============================================================================  
# Funcion que busca personas naturales en una o múltiples tablas (por período)
# 
#==============================================================================
def SelectCasosNPersonaN(apellidop,apellidom,nombre,base_p,reporte,nombre_tabla,campob,periodos_activos=None):
    try:
        # Si no hay períodos específicos, buscar en tabla base
        if not periodos_activos:
            periodos_activos = [nombre_tabla]
        else:
            # Convertir períodos a nombres de tablas
            periodos_activos = [nombre_tabla + "_" + p for p in periodos_activos]
        
        df_total = None
        
        for tabla_final in periodos_activos:
            try:
                cadsql='''SELECT * FROM ''' + tabla_final + ''' WHERE  ''' + campob[0] + ''' like "%''' + apellidop + '''%" AND
''' + campob[1] + ''' like "%''' + apellidom + '''%" AND ''' + campob[2] + ''' like "%''' + nombre +'''%"'''
                conn = sqlite3.connect(base_p)
                cur = conn.cursor()
                res=cur.execute(cadsql)
                rows = res.fetchall()
                cant=len(rows)
                print(f"Resultados en {tabla_final}: {cant}")
                
                if cant>0:            
                    columnas = [columna[0] for columna in cur.description]
                    df = pd.DataFrame(rows, columns=columnas)
                    
                    if df_total is None:
                        df_total = df
                    else:
                        df_total = pd.concat([df_total, df], ignore_index=True)
                
                conn.close()
            except Exception as e:
                print(f"No se encontraron resultados en {tabla_final}")
                try:
                    conn.close()
                except:
                    pass
        
        if df_total is not None:
            return [60, df_total]
        else:
            return [0, '']
   
    except Exception as e:
       print(e)
       print("Se produjo un error---> SelectCasosNPersonaN ---->" + apellidop + "|"+apellidom + "|" + nombre)
       try:
           conn.close()
       except:
           pass
       return [0,'Error']
       pass

#==============================================================================
#==============================================================================  
# Funcion que busca personas juridicas en una o múltiples tablas (por período)
# 
#==============================================================================
def SelectCasosNPersonaJ(nombre,base_p,reporte,nombre_tabla,campob,periodos_activos=None):
    try:
        # Si no hay períodos específicos, buscar en tabla base
        if not periodos_activos:
            periodos_activos = [nombre_tabla]
        else:
            # Convertir períodos a nombres de tablas
            periodos_activos = [nombre_tabla + "_" + p for p in periodos_activos]
        
        df_total = None
        
        for tabla_final in periodos_activos:
            try:
                cadsql='''SELECT * FROM '''+ tabla_final + ''' WHERE  ''' + campob[3] + ''' like "%''' + nombre + '''%"'''
                conn = sqlite3.connect(base_p)
                cur = conn.cursor()
                res=cur.execute(cadsql)
                rows = res.fetchall()
                cant=len(rows)
                print(f"Resultados en {tabla_final}: {cant}")
                
                if cant>0:            
                    columnas = [columna[0] for columna in cur.description]
                    df = pd.DataFrame(rows, columns=columnas)
                    
                    if df_total is None:
                        df_total = df
                    else:
                        df_total = pd.concat([df_total, df], ignore_index=True)
                
                conn.close()
            except Exception as e:
                print(f"No se encontraron resultados en {tabla_final}")
                try:
                    conn.close()
                except:
                    pass
        
        if df_total is not None:
            return [60, df_total]
        else:
            return [0, '']
   
    except Exception as e:
       print(e)
       print("Se produjo un error---> SelectCasosNPersonaJ ---->" + nombre )
       try:
           conn.close()
       except:
           pass
       return [0,'Error']
       pass

#==============================================================================
#==============================================================================  
# Funcion 
# 
#==============================================================================
def gradosimilitud(df,nombre,idpersona,column1,column2,column3):
    try:
        nombreb=nombre.upper()
        dfr=df.copy()  # Use .copy() to avoid working on a view of the original DataFrame
        dfr=dfr.assign(nombrebusq="")
        dfr=dfr.assign(porcetbusq=0.0)  # Initialize as numeric (float) to hold similarity ratios
        #print(df)
        if idpersona=='1' : #indica busqueda de persona natural
            for indice, fila  in df.iterrows(): # fila in df.itertuples(): 
                nombree=fila[column1].strip()+" "+fila[column2].strip()+" "+fila[column3].strip()
                nombree=nombree.upper()
                similitud = difflib.SequenceMatcher(None, nombreb, nombree).ratio()
                #filar=fila.to_frame()
                #filar=filar.assign(nombrebusq=[nombreb])
                #filar=filar.assign(porcetbusq=[similitud])
                dfr.loc[indice, 'nombrebusq']=nombreb
                dfr.loc[indice, 'porcetbusq']=similitud
                
        elif idpersona=='2': #indica busqueda de persona juridica
            for indice, fila in df.iterrows():
                nombree=fila[column1].strip()
                nombree=nombree.upper()
                similitud = difflib.SequenceMatcher(None, nombreb, nombree).ratio()
                dfr.loc[indice, 'nombrebusq']=nombreb
                dfr.loc[indice, 'porcetbusq']=similitud
                #print(nombree,similitud)
        print(1,dfr['porcetbusq'])
        return [1,dfr]
    except Exception as e:
        print(e)
        print("Se produjo un error---> gradosimilitud ---->" + nombre )
        return [0,'Error']
        pass
#==============================================================================
#==============================================================================  
# Función para buscar por documento (NRO_DOC / num_docpre)
# Considerando tipos de documento: cod_docpre (01=DNI, 06=RUC, etc.)
#==============================================================================
def SelectPorDocumento(nro_doc, base_p, nombre_tabla, campob_doc, periodos_activos=None):
    """
    Busca en la base de datos por número de documento (DNI, RUC, etc.)
    
    Args:
        nro_doc: Número de documento a buscar
        base_p: Ruta de la base de datos SQLite
        nombre_tabla: Nombre de la tabla
        campob_doc: Nombre de la columna que contiene el documento (ej: num_docpre)
        periodos_activos: Lista de períodos a buscar
    
    Returns:
        [porcentaje, dataframe] o [0, ''] si no encuentra
    """
    try:
        nro_doc = str(nro_doc).strip()
        
        if not nro_doc or nro_doc in ['SN', '-', '']:
            return [0, '']
        
        # Si no hay períodos específicos, buscar en tabla base
        if not periodos_activos:
            periodos_activos = [nombre_tabla]
        else:
            # Convertir períodos a nombres de tablas
            periodos_activos = [nombre_tabla + "_" + p for p in periodos_activos]
        
        df_total = None
        
        for tabla_final in periodos_activos:
            try:
                # Búsqueda exacta por número de documento
                cadsql = '''SELECT * FROM ''' + tabla_final + ''' WHERE ''' + campob_doc + ''' = "''' + nro_doc + '''"'''
                conn = sqlite3.connect(base_p)
                cur = conn.cursor()
                res = cur.execute(cadsql)
                rows = res.fetchall()
                cant = len(rows)
                
                print(f"Búsqueda por documento en {tabla_final}: {cant} resultado(s)")
                
                if cant > 0:
                    columnas = [columna[0] for columna in cur.description]
                    df = pd.DataFrame(rows, columns=columnas)
                    
                    if df_total is None:
                        df_total = df
                    else:
                        df_total = pd.concat([df_total, df], ignore_index=True)
                
                conn.close()
            except Exception as e:
                print(f"Error buscando en {tabla_final}: {str(e)}")
                try:
                    conn.close()
                except:
                    pass
        
        if df_total is not None:
            return [100, df_total]  # 100% de coincidencia por búsqueda exacta de documento
        else:
            return [0, '']
    
    except Exception as e:
        print(f"Error en SelectPorDocumento: {str(e)}")
        return [0, 'Error']

#==============================================================================
# 
# 
#==============================================================================
def procesobusuqeda(base_p,nomb_archivo_busqueda,nombre_tabla,parametrosb,rutac,periodos_activos=None):
    nombrea = datetime.now().strftime("%y%m%d_%H%M%S")
    band=0
    bandc=0
    bandf=0
    df_excelb = pd.read_excel(nomb_archivo_busqueda)
    # Ensure the Porcentaje column exists and can hold string values to avoid
    # chained-assignment warnings and dtype errors when assigning text.
    if "Porcentaje" not in df_excelb.columns:
        df_excelb["Porcentaje"] = "0"
    else:
        # convert to object so we can assign strings even if original dtype was numeric
        try:
            df_excelb["Porcentaje"] = df_excelb["Porcentaje"].astype(object)
        except Exception:
            df_excelb["Porcentaje"] = df_excelb["Porcentaje"].apply(lambda x: x if pd.notna(x) else "0")
    
    # Inicializar todas las filas con Porcentaje = "0" antes de buscar
    for ind, fila in df_excelb.iterrows():
        if pd.notna(fila["NOMBRE_BUSQUEDA"]) and fila["NOMBRE_BUSQUEDA"].strip() != "":
            if df_excelb.loc[ind, "Porcentaje"] == "" or pd.isna(df_excelb.loc[ind, "Porcentaje"]):
                df_excelb.loc[ind, "Porcentaje"] = "0"
    
    for ind, fila  in df_excelb.iterrows():
        print("---->"+str(ind))
        try:
            # Validar que NOMBRE_BUSQUEDA existe y no está vacío
            if pd.isna(fila["NOMBRE_BUSQUEDA"]) or fila["NOMBRE_BUSQUEDA"].strip() == "":
                print(f"⚠ Fila {ind}: NOMBRE_BUSQUEDA está vacío")
                df_excelb.loc[ind, "Porcentaje"] = "Nombre vacío"
                continue
            
            # PASO 1: Intentar buscar primero por NRO_DOC
            lstresultb1 = None
            porcentaje_doc = 0
            
            if "NRO_DOC" in fila and pd.notna(fila["NRO_DOC"]):
                nro_doc = str(fila["NRO_DOC"]).strip()
                if nro_doc and nro_doc not in ['SN', '-', '']:
                    print(f"   Buscando por NRO_DOC: {nro_doc}")
                    lstresultb1 = SelectPorDocumento(nro_doc, base_p, nombre_tabla, "num_docpre", periodos_activos)
                    if lstresultb1[0] > 0:
                        porcentaje_doc = lstresultb1[0]
                        print(f"   ✓ Encontrado por documento: {nro_doc}")
            
            # PASO 2: Si no encuentra por documento, buscar por nombre
            if porcentaje_doc == 0 or lstresultb1[0] == 0:
                print(f"   Buscando por nombre...")
                if (fila["TIPO_EMP"].strip() =="PERSONA NATURAL CON NEGOCIO" or 
                    fila["TIPO_EMP"].strip() =="PERSONA NATURAL SIN NEGOCIO" or
                    fila["TIPO_EMP"].strip() =="SUCESION INDIVISA CON NEGOCIO" or
                    fila["TIPO_EMP"].strip() =="SUCESION INDIVISA SIN NEGOCIO" ):
                    # Persona Natural
                    nombreb=fila["NOMBRE_BUSQUEDA"].strip().split("|")
                    
                    # Validar que tengamos 3 partes (apellido_p, apellido_m, nombre)
                    if len(nombreb) < 3:
                        print(f"⚠ Fila {ind}: NOMBRE_BUSQUEDA incompleto para Persona Natural")
                        print(f"   Esperado: APELLIDO_P|APELLIDO_M|NOMBRE")
                        print(f"   Recibido: {fila['NOMBRE_BUSQUEDA']} (solo tiene {len(nombreb)} parte(s))")
                        df_excelb.loc[ind, "Porcentaje"] = "Formato incorrecto"
                        continue
                    
                    lstresultb1=SelectCasosNPersonaN(nombreb[0].strip(),
                                nombreb[1].strip(),nombreb[2].strip(),base_p,"3",nombre_tabla,parametrosb,periodos_activos)
                else:
                    # Persona Jurídica
                    nombreb=fila["NOMBRE_BUSQUEDA"].strip()
                    lstresultb1=SelectCasosNPersonaJ(nombreb.strip(),base_p,"3",nombre_tabla,parametrosb,periodos_activos)
            
            # PASO 3: Procesar resultados
            if lstresultb1 is None or lstresultb1[0] == 0:
                df_excelb.loc[ind, "Porcentaje"] = "Sin coincidencias"
                bandc = 0
            else:
                # Usar el porcentaje del documento si fue encontrado, si no usar el de búsqueda por nombre
                porcentaje_final = porcentaje_doc if porcentaje_doc > 0 else lstresultb1[0]
                df_excelb.loc[ind, "Porcentaje"] = str(porcentaje_final)
                bandc = 1
                
                # Calcular grado de similitud
                if (fila["TIPO_EMP"].strip() =="PERSONA NATURAL CON NEGOCIO" or 
                    fila["TIPO_EMP"].strip() =="PERSONA NATURAL SIN NEGOCIO" or
                    fila["TIPO_EMP"].strip() =="SUCESION INDIVISA CON NEGOCIO" or
                    fila["TIPO_EMP"].strip() =="SUCESION INDIVISA SIN NEGOCIO" ):
                    nombreb=fila["NOMBRE_BUSQUEDA"].strip().split("|")
                    lstresultb2_0=gradosimilitud(lstresultb1[1],nombreb[0].strip()+ " " + nombreb[1].strip()+ " " +nombreb[2].strip(),
                                                 "1",parametrosb[0],parametrosb[1],parametrosb[2])
                else:
                    nombreb=fila["NOMBRE_BUSQUEDA"].strip()
                    lstresultb2_0=gradosimilitud(lstresultb1[1],nombreb.strip(),
                                                 "2",parametrosb[0],parametrosb[1],parametrosb[2])
            
            if band==0:            
                if bandc==1:
                    band=band+1
                    listresultbf=lstresultb2_0[1]
                    bandf=1
            else:
                if bandc==1:
                    listresultbf=pd.concat([listresultbf, lstresultb2_0[1]])
                    bandf=1
            
            print(f"Resultado: {fila['NOMBRE_BUSQUEDA']}")
            
        except Exception as e:
            print(f" Error procesando fila {ind}: {str(e)}")
            df_excelb.loc[ind, "Porcentaje"] = f"Error: {str(e)[:30]}"
            continue
    
    # Crear un único archivo Excel con múltiples hojas
    archivo_salida = rutac + "\\" + "Base_Busqueda_R_Cajas_CredDesembolsados.xlsx"
    
    with pd.ExcelWriter(archivo_salida, engine='openpyxl') as writer:
        # Primera hoja: REPORTE (Reporte_Final)
        df_excelb.to_excel(writer, sheet_name='REPORTE', index=False)
        
        # Segunda hoja: DETALLE (Reporte_Detallado) - solo si hay resultados detallados
        if bandf==1:
            listresultbf.to_excel(writer, sheet_name='DETALLE', index=False)
    
    print(f" Archivo guardado: {archivo_salida}")
        
#==============================================================================
#==============================================================================
#Parametros de Iniciio
#Función que obtiene datos de parametros de inicio
#==============================================================================
def ParametrosInicio():
    varInicial =[['Ruta del Aplicativo'],[''],[''],['']]
    varInicial[1][0]=os.getcwd() 
    i=1
    j=0
    #path_varini=varInicial[1][0]+ '\\VariablesInicioAPP.txt'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    path_varini=varInicial[1][0]+ '\\Parametros_Inicio.db' 
    if not os.path.exists(path_varini):
        print("Verificar ParametrosInicio(): No existe BD en la carpeta")
        while i>0:
            i=varInicial[1][0].find("\\",i)
            #print (i)
            if i!=-1:
                j=i
            i=i+1
        #print(j)
        varInicial[1][0]=varInicial[1][0][0:j]
        path_varini=varInicial[1][0]+ '\\Parametros_Inicio.db'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    
    varInicial[0].append('Nombre de PC') #
    varInicial[1].append(PCNAME) #
    varInicial[2].append('') #
    varInicial[3].append('') #
    varInicial[0].append('Usuario') #
    varInicial[1].append(USERNAME) #
    varInicial[2].append('') #
    varInicial[3].append('') #
    abspath_usuario=os.path.abspath(path_varini)#Ruta del archivo txt   
    con = sqlite3.connect(abspath_usuario)
    cur = con.cursor()
    res = cur.execute("select NombreCampo, ValorCampo,CodigoCampo,TipoCampo from ParametrosInicio")
    row=res.fetchone()
    while row:
        varInicial[0].append(row[0]) #NombreCampo
        varInicial[1].append(row[1]) #ValorCampo
        varInicial[2].append(row[2]) #CodigoCampo
        varInicial[3].append(row[3]) #TipoCampo
        #print(row[0],row[1])
        row=res.fetchone()
    print(varInicial[0][4:])
    return varInicial
#==============================================================================
#==============================================================================  
# Funcion principal que llama a las diversas funciones para la ejecucion de los 
# procesos
#==============================================================================
def main():
    global varinicio
    varinicio=ParametrosInicio()
    
    # Rutas de archivos de datos
    archivo_202501_202506=varinicio[1][0] + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202501_202506.txt"
    archivo_202507_202512=varinicio[1][0] + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202507_202512.txt"
    
    base_p=varinicio[1][0] + r"\Base_Datos\Base_Datos_Proceso.db"
    nomb_archivo_busqueda=varinicio[1][0] + r"\Base_Busqueda.xlsx"
    nombre_tabla="BANCOS_CAJAS_CREDDESEMBOLSADOS"
    
    # Obtener períodos ya cargados
    periodos_cargados = ObtenerPeriodosDisponibles(base_p)

    try:
        pass
        #########   Declarando Constantes ##################
        OPT_CLOSE = "SÍ, CERRAR"
        OPT_CARGAR_DATA1 = 'CARGAR DATA 2025-01-06'
        OPT_CARGAR_DATA2 = 'CARGAR DATA 2025-07-12'
        OPT_REPROCESAR = "PROCESAR BÚSQUEDA"
        OPT_LIMPIAR_TODAS = "LIMPIAR BASES"
        
        # Mostrar estado de períodos cargados
        estado_periodos = "Períodos cargados: " + (", ".join(periodos_cargados) if periodos_cargados else "NINGUNO")
        
        opt = py.confirm(
            "**************************************************"+'\n'+   
            "Bienvenido al Robot Cajas y Bancos" +'\n'+      
            "**************************************************"+'\n'+                                                            
            "Pre-condiciones:" +'\n' + '\n'+
            "1.- Los datos de búsqueda deben estar en archivo Base_Busqueda.xlsx" +'\n'+'\n'+
            "2.- La base de datos debe estar almacenada en \\Base_Datos\\Base_Cajas."+ '\n'+'\n'+
            estado_periodos + '\n',
            "Ejecutando Aplicativo Robot Cajas v02",
            [OPT_CLOSE,
             OPT_CARGAR_DATA1,
             OPT_CARGAR_DATA2,
             OPT_REPROCESAR,
             OPT_LIMPIAR_TODAS]
        )

        if opt == OPT_CLOSE:
            py.alert("Cerrando el aplicativo Robot Cajas")
            
        elif opt == OPT_CARGAR_DATA1: 
            periodo = "2025_01_06"
            print(f"Cargando DATA 2025-01-06 (Período: {periodo})...")
            try:
                CargarDataBaseSQLite(archivo_202501_202506, base_p, nombre_tabla, periodo)
                GuardarPeriodoCargado(base_p, periodo)
                periodos_cargados = ObtenerPeriodosDisponibles(base_p)
                py.alert(f" Data 2025-01-06 cargada exitosamente.\n Períodos disponibles: {', '.join(periodos_cargados)}")
            except Exception as e:
                py.alert(f" Error al cargar Data 2025-01-06:\n{str(e)}")
                print(e)
                
        elif opt == OPT_CARGAR_DATA2:
            periodo = "2025_07_12"
            print(f"Cargando DATA 2025-07-12 (Período: {periodo})...")
            try:
                CargarDataBaseSQLite(archivo_202507_202512, base_p, nombre_tabla, periodo)
                GuardarPeriodoCargado(base_p, periodo)
                periodos_cargados = ObtenerPeriodosDisponibles(base_p)
                py.alert(f" Data 2025-07-12 cargada exitosamente.\n Períodos disponibles: {', '.join(periodos_cargados)}")
            except Exception as e:
                py.alert(f" Error al cargar Data 2025-07-12:\n{str(e)}")
                print(e)
                
        elif opt == OPT_REPROCESAR:
            if not periodos_cargados:
                py.alert(" ERROR: No hay datos cargados.\nCarga DATA 2025-01-06 o DATA 2025-07-12 primero.")
            else:
                print(f"Procesando búsqueda con períodos: {', '.join(periodos_cargados)}...")
                procesobusuqeda(base_p,nomb_archivo_busqueda,nombre_tabla,["nom_aplpatpre","nom_aplmatpre","nom_pre","nom_razpre"]
                                ,varinicio[1][0],periodos_cargados)
                py.alert(f" Búsqueda completada.\n Búsqueda en períodos: {', '.join(periodos_cargados)}\n Reportes generados en: {varinicio[1][0]}")
                
        elif opt == OPT_LIMPIAR_TODAS:
            try:
                periodos_a_limpiar = ObtenerPeriodosDisponibles(base_p)
                
                if not periodos_a_limpiar:
                    py.alert("⚠ No hay bases cargadas para limpiar.")
                else:
                    # Confirmar antes de limpiar todo
                    confirmar = py.confirm(
                        f"¿Deseas eliminar TODAS las bases de datos?\n\nPeríodos a limpiar: {', '.join(periodos_a_limpiar)}\n\nEsta acción no se puede deshacer.",
                        "Confirmar limpieza",
                        ["SÍ, LIMPIAR TODO", "NO, CANCELAR"]
                    )
                    
                    if confirmar == "SÍ, LIMPIAR TODO":
                        # Limpiar cada período
                        for periodo in periodos_a_limpiar:
                            DropTableBaseSQLite(nombre_tabla, base_p, periodo)
                            LimpiarPeriodoCargado(base_p, periodo)
                        
                        py.alert(" TODAS las bases de datos han sido limpiadas exitosamente.")
                    else:
                        py.alert(" Limpieza cancelada.")
                        
            except Exception as e:
                py.alert(f" Error al limpiar bases:\n{str(e)}")
                print(e)

        
    except Exception as e:
        print(e)
        print("Se produjo un error")
        SystemExit()
         
if __name__ == "__main__":
    main()