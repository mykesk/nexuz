"""
app_driver.py - Controlador de la aplicación RSIRAT
Encapsula:
  1. Apertira/cierre de app (pyautogui + .lnk)
  2. Login (campos, detección de errores contraseña)
  3. Navegación (Cobranza Coactiva, Exp. Cob. Individual)
  4. Entrada de expedientes (inicial, con Accesos)
  5. Accesos → Cambio de Expediente
  6. Trabar Embargo, Intervención, Depósito
  7. Ingreso de INTERVENTOR, PLAZO, MONTO
  8. Detecciones centralizadas de mensajes (MessageCatalog)
  9. Extracción de RC
  10. Cierre de diálogos

Retorna siempre Outcome explícito
"""

import time
import logging
import os
import sys
import re
import ctypes
from pathlib import Path
from typing import Optional, Tuple

import pyautogui
import cv2
import numpy as np
from PIL import ImageGrab
from pywinauto import Application, Desktop, findwindows

from logica import Outcome


# CONSTANTES Y SELECTORES
RSIRAT_WINDOW_PATTERNS = [
    "SIRAT"
]
RSIRAT_WAIT_TIMEOUT = 30
UI_WAIT_SMALL = 0.5
UI_WAIT_MEDIUM = 1.0
UI_WAIT_LARGE = 2.0
DETECT_TIMEOUT = 2.0
MSAA_BACKEND = "uia"





# APP DRIVER CLASS
class AppDriver:
    """Controlador de aplicación RSIRAT."""
    
    def __init__(self, logger: logging.Logger, shortcut_path: Path, img_dir: Path = None):
        self.logger = logger
        self.shortcut_path = shortcut_path
        self.img_dir = img_dir or Path(__file__).parent / "IMG"  # Default: IMG/ en mismo directorio del script
        self.app = None
        self.main_window = None
        # Variables para almacenar coordenadas reutilizables
        self.trabar_embargo_coords = None
        self.proceso_embargo_coords = None
    
    # APERTURA / CIERRE
    
    def open_app(self) -> bool:
        """
        Abre RSIRAT usando el acceso directo.
        
        OPTIMIZADO: Sin sleep fijo de 15 segundos.
        El timeout de búsqueda de ventana SIRAT (30s) maneja la espera dinámica.
        """
        try:
            self.logger.info(f"[ACCIÓN] Abriendo {self.shortcut_path.name}...")
            self.logger.info(f"  └─ Ruta: {self.shortcut_path}")
            self.logger.info(f"  └─ Comando: os.startfile()")
            os.startfile(str(self.shortcut_path))
            self.logger.info(f"  └─ Aplicación iniciada (esperando ventana de login en siguiente paso)...")
            return True
        except Exception as e:
            self.logger.error(f" Error abriendo aplicación: {e}")
            return False
    
    def close_app(self) -> bool:
        """Cierra RSIRAT con Alt+F4."""
        try:
            self.logger.info("[ACCIÓN] Cerrando aplicación...")
            self.logger.info("  └─ Combinación de teclas: ALT+F4")
            pyautogui.hotkey('alt', 'f4')
            self.logger.info("  └─ Esperando 2 segundos...")
            time.sleep(2)
            self.logger.info(" Aplicación cerrada")
            return True
        except Exception as e:
            self.logger.error(f" Error cerrando aplicación: {e}")
            return False
    
    def find_and_fill_dependencia_field(self, dependencia: str) -> bool:
        """
        Encuentra el campo DEPENDENCIA usando imagen 001.png (OpenCV)
        y digita la dependencia automáticamente.
        
        Pasos:
        1. Buscar imagen 001.png en carpeta IMG/ usando OpenCV (template matching)
        2. Si se encuentra: clic + digitar dependencia
        3. Presionar TAB para avanzar a contraseña
        
        Retorna: True si exitoso, False si falla
        """
        try:
            self.logger.info("Buscando campo DEPENDENCIA usando imagen 001.png (OpenCV)...")
            
            # Usar self.img_dir que fue pasado en constructor
            image_path = self.img_dir / "001.png"
            
            self.logger.info(f"Buscando imagen en: {image_path}")
            
            if not image_path.exists():
                self.logger.error(f"Imagen no encontrada: {image_path}")
                return False
            
            self.logger.info(f" Imagen encontrada: {image_path}")
            
            # Cargar template con OpenCV
            template = cv2.imread(str(image_path))
            if template is None:
                self.logger.error(f"No se pudo cargar la imagen: {image_path}")
                return False
            
            # Capturar pantalla actual
            screen = np.array(ImageGrab.grab())
            screen_cv2 = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
            
            # Template matching con OpenCV
            result = cv2.matchTemplate(screen_cv2, template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)
            
            # Threshold de similitud: 0.65 (65%)
            threshold = 0.65
            if max_val >= threshold:
                self.logger.info(f" Imagen encontrada con similitud: {max_val:.2%}")
                
                # Calcular centro de la imagen
                h, w = template.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                
                # Click en el campo
                self.logger.info(f"Haciendo clic en coordenadas: ({center_x}, {center_y})")
                pyautogui.click(center_x, center_y)
                time.sleep(0.3)
                
                # Limpiar campo con 15× SUPR y 15× BORRADO (BackSpace)           
                self.logger.info("Limpiando campo con 25× BORRADO (BackSpace)...")
                for _ in range(25):
                    pyautogui.press('backspace')
                    time.sleep(0.01)
                
                time.sleep(0.3)
                
                # Digitar dependencia
                self.logger.info(f"Digitando dependencia: {dependencia}")
                pyautogui.write(dependencia, interval=0.01)
                time.sleep(0.3)
                
                # Presionar TAB para avanzar a contraseña
                self.logger.info("Presionando TAB para avanzar al campo contraseña...")
                pyautogui.press('tab')
                time.sleep(0.5)
                
                self.logger.info(" Campo DEPENDENCIA completado")
                return True
            else:
                self.logger.error(f"Similitud insuficiente: {max_val:.2%} (requerido: {threshold:.0%})")
                return False
                
        except Exception as e:
            self.logger.error(f"Error en find_and_fill_dependencia_field: {e}")
            return False
    
    def find_and_click_image(self, image_name: str, timeout: int = 360, click_offset_x: int = 0, click_offset_y: int = 0) -> bool:
        """
        Busca una imagen en carpeta IMG/ y hace clic en ella si la encuentra.
        Usa OpenCV para template matching.
        
        Args:
            image_name: nombre de archivo (ej: "002.png", "003.png")
            timeout: segundos de timeout para la búsqueda (default 360s)
            click_offset_x: offset horizontal del clic respecto al centro (default 0)
            click_offset_y: offset vertical del clic respecto al centro (default 0)
        
        Retorna: True si encontrada y clickeada, False si falla
        """
        try:
            self.logger.info(f"Buscando imagen {image_name} usando OpenCV (timeout: {timeout}s)...")
            
            # Ruta de la imagen: usar self.img_dir que fue pasado en constructor
            image_path = self.img_dir / image_name
            
            self.logger.info(f"Buscando: {image_path}")
            if not image_path.exists():
                self.logger.error(f"Imagen no encontrada: {image_path}")
                return False
            
            # Cargar template con OpenCV
            template = cv2.imread(str(image_path))
            if template is None:
                self.logger.error(f"No se pudo cargar la imagen: {image_path}")
                return False
            
            template_h, template_w = template.shape[:2]
            threshold = 0.7  # 70% de similitud mínima
            
            # Búsqueda con reintentos hasta timeout
            start_time = time.time()
            intento = 0
            
            while time.time() - start_time < timeout:
                intento += 1
                tiempo_transcurrido = int(time.time() - start_time)
                
                try:
                    # Capturar pantalla actual
                    screen = np.array(ImageGrab.grab())
                    screen_cv2 = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
                    
                    # Template matching
                    result = cv2.matchTemplate(screen_cv2, template, cv2.TM_CCOEFF_NORMED)
                    _, max_val, _, max_loc = cv2.minMaxLoc(result)
                    
                    if max_val >= threshold:
                        self.logger.info(f" Imagen {image_name} encontrada (intento {intento}) con similitud: {max_val:.2%}")
                        
                        # Calcular centro de la imagen
                        center_x = max_loc[0] + template_w // 2 + click_offset_x
                        center_y = max_loc[1] + template_h // 2 + click_offset_y
                        
                        # Click en las coordenadas
                        self.logger.info(f"Haciendo clic en: ({center_x}, {center_y})")
                        pyautogui.click(center_x, center_y)
                        time.sleep(0.5)
                        
                        return True
                    else:
                        self.logger.debug(f"Intento {intento} ({tiempo_transcurrido}s): similitud {max_val:.2%} < {threshold:.0%}")
                
                except Exception as e:
                    self.logger.debug(f"Intento {intento}: {e}")
                
                time.sleep(2)  # Esperar 2 segundos antes de siguiente intento
            
            # Timeout alcanzado
            self.logger.error(f"Timeout alcanzado ({timeout}s) buscando imagen {image_name}")
            self.logger.error(f"  └─ Imagen no fue localizada en la pantalla durante el período de búsqueda")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en find_and_click_image: {e}")
            return False
    
    def check_app_window_exists(self) -> bool:
        """
        Verifica si la ventana SIRAT sigue abierta.
        Retorna True si está abierta, False si se cerró (posible crasheo).
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            try:
                windows = desktop.windows()
                for window in windows:
                    try:
                        title = str(window.element_info.name or "")
                        if title == "SIRAT":
                            return True
                    except Exception:
                        continue
            except Exception:
                pass
            
            self.logger.warning("[ALERTA] Ventana SIRAT NO encontrada - Aplicación posiblemente cerrada/crasheada")
            return False
        
        except Exception as e:
            self.logger.error(f"Error verificando ventana SIRAT: {e}")
            return False
    
    # VALIDACIONES PRE-LOGIN
    
    def check_and_disable_capslock(self):
        """
        Detecta si Bloq Mayús (CAPS LOCK) está activado.
        Si está activado, lo desactiva presionando la tecla CAPS LOCK.
        Esto evita que la contraseña se escriba en mayúsculas.
        """
        try:
            import ctypes
            # GetKeyState retorna valor par si la tecla NO está pulsada, impar si está pulsada
            # VK_CAPITAL = 0x14 (código de CAPS LOCK)
            capslock_state = ctypes.windll.user32.GetKeyState(0x14)
            
            # Si capslock_state es impar, Bloq Mayús está activado
            if capslock_state % 2 == 1:
                self.logger.warning(" Bloq Mayús (CAPS LOCK) está ACTIVADO")
                self.logger.info("  Desactivando Bloq Mayús...")
                pyautogui.press('capslock')
                time.sleep(0.5)
                self.logger.info("   Bloq Mayús desactivado")
            else:
                self.logger.info(" Bloq Mayús está desactivado (normal)")
        except Exception as e:
            self.logger.warning(f"No se pudo verificar Bloq Mayús: {e}")
    
    # ENFOQUE DE VENTANA (FUNCIÓN GENERAL)
    
    def ensure_sirat_focus(self):
        """
        FUNCIÓN GENERAL DE ENFOQUE DE VENTANA SIRAT.
        
        Responsabilidades:
        1. Buscar ventana SIRAT mediante múltiples estrategias escalonadas
        2. Traer a frente y establecer foco (set_focus)
        3. Actualizar cache (self.app) para reutilización
        4. Validar que la ventana encontrada es realmente SIRAT
        
        ESTRATEGIAS (en orden):
        1. Verificar cache local (self.app) si existe
        2. Buscar por título exacto "SIRAT"
        3. Fallback a ventana activa con validación
        4. Buscar por patrón (RSIRAT, COBRANZA, etc)
        
        RETORNA: Referencia a ventana SIRAT o None si no se encuentra
        
        BENEFICIOS:
        - Centraliza lógica de búsqueda (eliminadas repeticiones)
        - set_focus() integrado = previene "ventana no encontrada"
        - Cache actualizado = búsquedas más rápidas
        - Validación extra = early error detection
        """
        try:
            # ESTRATEGIA 1: Verificar cache local
            if self.app is not None:
                try:
                    if self.app.exists():
                        self.app.set_focus()
                        self.logger.debug("[ensure_sirat_focus] Cache válido, ventana enfocada")
                        self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] Cache local válido - ventana enfocada")
                    return self.app
                except Exception:
                    self.app = None  # Invalidar cache si falla
                    self.logger.debug("[ ESTRATEGIA 1 FALLÓ] Cache inválido")
            
            # ESTRATEGIA 2: Buscar por título exacto "SIRAT"
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.window(title="SIRAT")
                if app and app.exists(timeout=1):
                    app.set_focus()
                    self.app = app  # Actualizar cache
                    self.logger.debug("[ensure_sirat_focus] Ventana SIRAT encontrada por título exacto")
                    self.logger.info("[ ESTRATEGIA 2 FUNCIONÓ] Ventana encontrada por título exacto - enfocada")
                    return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 2 FALLÓ] No se encontró ventana por título exacto")
                pass
            
            # ESTRATEGIA 3: Fallback a ventana activa con validación
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.active()
                if app:
                    title = app.window_title().lower()
                    # Validar que sea SIRAT (por título o clase)
                    if "sirat" in title or "rsirat" in title or "cobranza" in title:
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana activa validada como SIRAT: '{title}'")
                        self.logger.info(f"[ ESTRATEGIA 3 FUNCIONÓ] Ventana activa validada ('{title}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 3 FALLÓ] No se validó ventana activa como SIRAT")
                pass
            
            # ESTRATEGIA 4: Buscar por patrón usando findwindows
            try:
                for pattern in RSIRAT_WINDOW_PATTERNS:
                    windows = findwindows.find_windows(title_re=f".*{pattern}.*")
                    if windows:
                        app = Application(backend=MSAA_BACKEND).connect(
                            handle=windows[0]
                        ).top_window()
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana encontrada por patrón '{pattern}'")
                        self.logger.info(f"[ ESTRATEGIA 4 FUNCIONÓ] Ventana encontrada por patrón ('{pattern}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 4 FALLÓ] No se encontró ventana por patrón")
                pass
            
            # No encontrada con ninguna estrategia
            self.logger.error("[ensure_sirat_focus] No se pudo encontrar/enfocar ventana SIRAT después de 4 intentos")
            self.app = None
            return None
        
        except Exception as e:
            self.logger.error(f"[ensure_sirat_focus] Error general: {e}")
            self.app = None
            return None
    
    def find_sirat_window(self):
        """
        Obtiene referencia a ventana SIRAT usando Desktop y MSAA backend.
        
        Utilizado por funciones de detección de mensajes (detect_*) que necesitan
        buscar elementos SOLO dentro de la ventana SIRAT (optimización).
        
        Retorna: 
            - Ventana SIRAT si se encuentra y existe
            - None si no se encuentra o hay error
        
        IMPORTANTE:
        - Este método es ACCESO DIRECTO a ventana (sin enfocar)
        - Para enfocar, usar ensure_sirat_focus()
        - Para búsquedas optimizadas de mensajes, usar este método
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            sirat_window = desktop.window(title="SIRAT")
            
            if sirat_window.exists(timeout=1):
                return sirat_window
            
            return None
        
        except Exception as e:
            self.logger.debug(f"find_sirat_window() error: {e}")
            return None
    
    # LOGIN
    
    def login(self, dependencia: str, password: str) -> Outcome:
        """
        Realiza login con reintentos dinámicos y tolerancia a delays.
        Espera hasta 30 segundos a que aparezca la ventana de login.
        Retorna OK_RC si login OK, FAIL_LOGIN_PASSWORD si hay error.
        """

        try:
            self.logger.info("Iniciando proceso de login...")
            
            # Esperar ventana de login con reintentos dinámicos
            self.logger.info("Esperando ventana de login (hasta 60 segundos)...")
            dlg = None
            
            desktop = Desktop(backend=MSAA_BACKEND)
            start_time = time.time()
            timeout = 60  # Aumentado de 30 a 60 segundos para dar más tiempo a la app
            
            while time.time() - start_time < timeout:
                try:
                    # Búsqueda exacta: ventana con título exacto "SIRAT"
                    windows = desktop.windows()
                    
                    for window in windows:
                        try:
                            title = str(window.element_info.name or "")
                            # Búsqueda por exactitud: solo "SIRAT"
                            if title == "SIRAT":
                                dlg = window
                                self.logger.info(f"Ventana SIRAT encontrada")
                                break
                        except Exception:
                            continue
                    
                    if dlg:
                        break
                    
                except Exception as e:
                    self.logger.debug(f"Error buscando ventana SIRAT: {e}")
                    pass
                
                time.sleep(0.5)
            
            if dlg is None:
                self.logger.error("No se pudo encontrar la ventana SIRAT después de 60 segundos")
                return Outcome.FAIL_UI
            
            time.sleep(1)
            
            # OPTIMIZACIÓN: Usar OpenCV + imagen 001.png para detectar y llenar campo DEPENDENCIA
            self.logger.info("Usando OpenCV + imagen 001.png para llenar campo DEPENDENCIA...")
            
            # Preparar texto completo de dependencia para el login
            dep_code = str(dependencia).strip()
            dep_map = {
                "21": "0021 I.R. Lima - PRICO",
                "23": "0023 I.R. Lima - MEPECO",
            }
            login_dep = dep_map.get(dep_code, dependencia)
            
            # Intentar llenar DEPENDENCIA con OpenCV + imagen
            success = self.find_and_fill_dependencia_field(login_dep)
            
            if not success:
                self.logger.error("Falló llenado de DEPENDENCIA con OpenCV. Retornando FAIL_UI")
                return Outcome.FAIL_UI
            
            self.logger.info("DEPENDENCIA llenada exitosamente con OpenCV. Buscando campo CONTRASEÑA...")
            
            # OPTIMIZACIÓN: Después del TAB (que avanza a campo CONTRASEÑA automáticamente),
            # directamente digitamos la contraseña sin buscar el campo
            self.logger.info("Después del TAB, campo CONTRASEÑA debería estar enfocado. Digitando contraseña...")
            
            # Verificar y desactivar Bloq Mayús antes de escribir la contraseña
            self.check_and_disable_capslock()
            
            time.sleep(0.2)  # Pequeña pausa para que TAB tome efecto
            
            self.logger.info(f"Escribiendo contraseña (0.02s entre caracteres)...")
            pyautogui.write(password, interval=0.02)
            time.sleep(0.2)
            
            # Presionar ENTER para confirmar login
            self.logger.info("Presionando ENTER para confirmar login...")
            pyautogui.press('return')
            
            # Pequeña pausa para que aparezca posible error
            time.sleep(0.5)
            
            # Verificar si hay mensaje de error de contraseña
            pwd_err, pwd_msg = self.detect_password_error(timeout=0.5)
            if pwd_err:
                self.logger.error(f" Contraseña incorrecta. Mensaje: {pwd_msg}")
                # Presionar ENTER para cerrar el aviso de error
                self.logger.info("  └─ Presionando ENTER para cerrar aviso de error")
                time.sleep(0.5)
                pyautogui.press('return')
                time.sleep(0.5)
                # Presionar ALT+C para seleccionar 'Cancelar' y cerrar la aplicación (solo en etapa de login)
                self.logger.info("  └─ Presionando ALT+C para cancelar login y cerrar la app...")
                try:
                    pyautogui.hotkey('alt', 'c')
                except Exception:
                    # En caso de que hotkey falle, intentar enviar secuencia alternativa
                    pyautogui.keyDown('alt')
                    pyautogui.press('c')
                    pyautogui.keyUp('alt')
                time.sleep(1)
                self.logger.info(" Cerrando aplicación debido a credenciales inválidas")
                return Outcome.FAIL_LOGIN_PASSWORD
            
            self.logger.info(" Login completado exitosamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return Outcome.FAIL_UI

    # DETECTORES (copiados y adaptados de test2.py)
    def detect_password_error(self, timeout=0.5):
        """
        Detecta si hay mensaje de error de contraseña.
        
        OPTIMIZADO: timeout=0.5s (muy corto)
        - Si hay error, aparece INMEDIATAMENTE (dentro de 0.1-0.2s)
        - Si no hay error en 0.5s, entonces login fue exitoso
        - Los errores son visibles al instante después de presionar Aceptar
        
        Retorna: (True, mensaje) si hay error, (False, "") si no hay error
        """
        try:
            self.logger.info("Verificando si hay mensaje de error...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "no puede ser accedido",
                                            "estimado usuario",
                                            "aplicativo",
                                            "credenciales",
                                            "error en las credenciales",
                                            "error numero"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.error(f"Mensaje de error detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.1)  # Reducido de 0.3s a 0.1s para búsqueda más frecuente
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False, ""

    def detect_monto_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de aviso del MONTO...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "monto",
                                            "excede",
                                            "saldo",
                                            "expediente",
                                            "aviso",
                                            "error"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.info(f"Mensaje de aviso detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_monto_aviso: {e}")
            return False, ""

    def detect_expediente_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error de expediente...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        # Buscar SOLO el mensaje específico de expediente inválido
                                        # y evitar texto muy largo (falsos positivos)
                                        if len(texto) < 200 and "expediente" in texto_lower and ("válido" in texto_lower or "no es valido" in texto_lower):
                                            self.logger.warning(f"Error de expediente detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_error: {e}")
            return False, ""

    def detect_expediente_aviso(self, timeout=2):
        """
        Detecta el aviso de embargos activos en DSE.
        Patrón: "El Expediente [NUM] correspondiente al RUC [NUM] tiene [NUM] Embargos activos..."
        Los números pueden variar, busca las palabras clave.
        """
        try:
            self.logger.info("Verificando aviso de embargos activos (expediente+ruc+embargo)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    texto = str(desc.window_text() or "").strip()
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón: debe contener las 4 palabras clave
                                    # (independiente de números específicos)
                                    if ("expediente" in texto_lower and 
                                        "ruc" in texto_lower and 
                                        "embargo" in texto_lower and 
                                        "activo" in texto_lower):
                                        self.logger.info(f" Aviso embargos activos: {texto[:80]}...")
                                        return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_aviso: {e}")
            return False, ""

    def handle_dse_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en DSE que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (DSE)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_dse_embargo_aviso: {e}")
            return False

    def handle_iei_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en IEI que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (IEI)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado (IEI)")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos (IEI)")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_iei_embargo_aviso: {e}")
            return False

    def extract_ruc_from_message(self, mensaje):
        try:
            self.logger.info("Extrayendo RUC del mensaje...")
            ruc_index = mensaje.upper().find("RUC")
            if ruc_index == -1:
                self.logger.warning("No se encontró 'RUC' en el mensaje")
                return ""
            texto_despues_ruc = mensaje[ruc_index + 3:].strip()
            self.logger.info(f"Texto después de 'RUC': '{texto_despues_ruc[:50]}'")
            ruc = ""
            for caracter in texto_despues_ruc:
                if caracter.isdigit():
                    ruc += caracter
                elif ruc:
                    break
            if ruc:
                self.logger.info(f" RUC extraído: {ruc}")
                return ruc
            else:
                self.logger.warning("No se encontraron dígitos después de 'RUC'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo RUC: {e}")
            return ""

    def detect_resolucion_coactiva_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de Resolución Coactiva...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        if "se grabó" in texto.lower() and "resolución coactiva" in texto.lower():
                                            self.logger.warning(f" MENSAJE DE RESOLUCIÓN COACTIVA DETECTADO: {texto[:100]}...")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_resolucion_coactiva_aviso: {e}")
            return False, ""

    def extract_resolucion_coactiva_number(self, mensaje):
        try:
            self.logger.info("Extrayendo número de Resolución Coactiva del mensaje...")
            numero_index = mensaje.lower().find("número")
            if numero_index == -1:
                self.logger.warning("No se encontró 'palabra 'número' en el mensaje")
                return ""
            texto_despues_numero = mensaje[numero_index + 6:].strip()
            self.logger.info(f"Texto después de 'número': '{texto_despues_numero[:50]}'")
            rc_number = ""
            for caracter in texto_despues_numero:
                if caracter.isdigit():
                    rc_number += caracter
                elif rc_number:
                    break
            if rc_number:
                self.logger.info(f" Número de RC extraído: {rc_number}")
                return rc_number
            else:
                self.logger.warning("No se encontraron dígitos después de 'número'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo número de RC: {e}")
            return ""

    def detect_desea_continuar_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje '¿ Desea Continuar ?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    dlgs = desktop.windows()
                    for dlg in dlgs:
                        try:
                            descendants = dlg.descendants()
                            for desc in descendants:
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        if "desea" in texto_lower and "continuar" in texto_lower:
                                            self.logger.warning(f"Aviso '¿ Desea Continuar ?' detectado")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.1)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_continuar_aviso: {e}")
            return False, ""

    def detect_interventor_error(self, timeout=2):
        """
        OPTIMIZADO: Detecta error de interventor buscando SOLO en SIRAT + controles Text
        
        PROBLEMA ORIGINAL:
        - Buscaba en TODO desktop (10+ ventanas) + ALL descendants (100+)
        - En producción: 24 segundos (bloqueaba digitación de PLAZO)
        
        SOLUCIÓN:
        - Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
        - Busca SOLO en controles de tipo "Text" (más preciso y rápido)
        - Timeout: 0.5s (suficiente para detectar mensaje)
        - Esperado: 0.5 segundos vs 24 segundos
        
        Retorna: (True, "mensaje") si error detectado, (False, "") si no
        """
        try:
            self.logger.info(f"Verificando error 'Código de Interventor incorrecto' en controles Text (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.05)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        descendants = sirat_window.descendants()
                        for desc in descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # FILTRO: Solo controles de tipo "Text" con contenido
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    # Búsqueda de 3 palabras clave
                                    if ("codigo" in texto_lower and 
                                        "interventor" in texto_lower and 
                                        "incorrecto" in texto_lower):
                                        self.logger.warning(f" Error INTERVENTOR detectado: '{texto}'")
                                        return True, texto
                            except Exception:
                                pass
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.05)  # Polling rápido (50ms intervals)
            
            self.logger.info("No hay error de INTERVENTOR")
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_interventor_error: {e}")
            return False, ""
    
    def detect_aviso_monto_excede_20pct(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto ingresado excede en mas del [X]% el Saldo del Expediente"
        Tolerante con cualquier porcentaje (20%, 10%, 15%, X%, etc).
        """
        try:
            self.logger.info("Verificando aviso 'monto excede porcentaje'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante con expresión regular para cualquier porcentaje
                                        import re
                                        has_excede = "excede" in texto_lower
                                        has_percent = bool(re.search(r'\d+\s*%', texto))
                                        has_saldo = "saldo" in texto_lower
                                        has_expediente = "expediente" in texto_lower
                                        
                                        if has_excede and has_percent and has_saldo and has_expediente:
                                            self.logger.info(f" Aviso monto excede: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_excede_20pct: {e}")
            return False, ""

    def detect_aviso_monto_supera_saldo(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto de embargo ingresado supera el saldo embargable del expediente..."
        Tolerante con variación de texto y números.
        """
        try:
            self.logger.info("Verificando aviso 'monto supera saldo'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("monto" in texto_lower and
                                            "embargo" in texto_lower and
                                            "supera" in texto_lower and 
                                            "saldo" in texto_lower):
                                            self.logger.info(f" Aviso monto supera saldo: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_supera_saldo: {e}")
            return False, ""

    def detect_desea_grabar_resolucion(self, timeout=2):
        """
        Detecta el aviso de confirmación de grabación en controles de tipo "Text":
        "¿Desea Ud. grabar la Resolución?" (puede variar ligeramente)
        Tolerante con variaciones (resolucion, resolución, etc).
        """
        try:
            self.logger.info("Verificando aviso '¿Desea grabar Resolución?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("desea" in texto_lower and 
                                            "grabar" in texto_lower and 
                                            "resolu" in texto_lower):  # resolu cubre resolución, resolucion
                                            self.logger.info(f" Aviso grabar Resolución: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_grabar_resolucion: {e}")
            return False, ""

    def detect_first_aviso(self, timeout=2):
        """
        Detecta CUALQUIER PRIMER MENSAJE de texto que aparezca en la pantalla.
        
        Se utiliza después de ALT+A para extraer el primer aviso/mensaje que aparece,
        sin importar cuál sea su contenido.
        
        Retorna: (True, "texto_del_mensaje") si detecta, (False, "") si no
        """
        try:
            self.logger.info(f"Detectando PRIMER AVISO/MENSAJE (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # Buscar en ventana SIRAT
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.1)
                        continue
                    
                    # Iterar descendants
                    try:
                        all_descendants = list(sirat_window.descendants())
                        
                        for desc in all_descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # CRITERIO: Controles de tipo "Text" con contenido (excluyendo etiquetas muy cortas)
                                if control_type == "Text" and texto and len(texto.strip()) > 3:
                                    self.logger.info(f"[ PRIMER AVISO DETECTADO] {texto[:100]}")
                                    return True, texto
                            
                            except Exception:
                                pass
                    
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.2)
            
            self.logger.warning("No se detectó primer aviso/mensaje")
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_first_aviso: {e}")
            return False, ""

    def detect_rc_message(self, timeout=3):
        """
        OPTIMIZADO: Detecta "Se grabó la Resolución Coactiva" buscando SOLO en SIRAT
        
        Ahora: Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
               = 1 segundo vs 20 segundos
        
        Retorna: (True, "numero_rc") si se detecta, (False, "") si no
        IMPORTANTE: Retorna número como STRING para preservar 0s iniciales
        """
        try:
            self.logger.info(f"Buscando RC en SIRAT: 'Se grabó la Resolución Coactiva' (timeout={timeout}s OPTIMIZADO)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.1)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        all_descendants = list(sirat_window.descendants())
                        
                        for desc in all_descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # Filtrar: solo controles de tipo "Text" que contengan el patrón
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón "Se grabó la Resolución Coactiva"
                                    if "se grabó" in texto_lower and "resolución coactiva" in texto_lower:
                                        self.logger.info(f" Mensaje RC detectado: {texto[:100]}...")
                                        
                                        # Extraer número después de "número"
                                        numero_index = texto_lower.find("número")
                                        if numero_index >= 0:
                                            texto_despues = texto[numero_index + 6:].strip()
                                            
                                            # Extraer dígitos consecutivos
                                            rc_number = ""
                                            for char in texto_despues:
                                                if char.isdigit():
                                                    rc_number += char
                                                elif rc_number:  # Ya tenemos dígitos, paramos en primer no-dígito
                                                    break
                                            
                                            if rc_number:
                                                self.logger.info(f" RC extraída como STRING: {rc_number}")
                                                return True, rc_number
                            
                            except Exception:
                                pass
                    
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.1)
            
            self.logger.warning(f"No se detectó RC después de {timeout} segundos")
            return False, ""
        
        except Exception as e:
            self.logger.error(f"Error en detect_rc_message: {e}")
            return False, ""
    
    # NAVEGACIÓN BÁSICA
    
    def navigate_to_module(self) -> bool:
        """
        Navega a Cobranza Coactiva usando imagen 002.png con OpenCV (timeout: 360 segundos).
        """
        try:
            self.logger.info("Buscando 'Cobranza Coactiva' usando imagen 002.png...")
            
            # Usar find_and_click_image para buscar y hacer clic en 002.png
            success = self.find_and_click_image(
                image_name="002.png",
                timeout=360,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if not success:
                self.logger.error("No se pudo encontrar o hacer clic en imagen 002.png (Cobranza Coactiva)")
                return False
            
            time.sleep(1)
            
            # Después de clic en Cobranza Coactiva, seleccionar 'Exp. Cob. Coactiva - Individual'
            self.logger.info("Seleccionando 'Exp. Cob. Coactiva - Individual'...")
            app = Desktop(backend=MSAA_BACKEND).window(title="SIRAT")
            ok = self.click_exp_individual(app)
            
            if ok:
                return True
            else:
                self.logger.warning("No se pudo seleccionar 'Exp. Cob. Coactiva - Individual'")
                return False
        
        except Exception as e:
            self.logger.error(f"Error navegando a Cobranza Coactiva: {e}")
            return False
    
    def click_exp_individual(self, app=None):
        """
        Selecciona 'Exp. Cob. Coactiva - Individual' presionando ENTER.
        Se llama DESPUÉS de navigate_to_module().
        """
        try:
            self.logger.info("Seleccionando 'Exp. Cob. Coactiva - Individual' con ENTER...")
            
            # Presionar ENTER para seleccionar la opción enfocada
            pyautogui.press('return')
            time.sleep(1)
            
            self.logger.info(" ENTER presionado para seleccionar 'Exp. Cob. Coactiva - Individual'")
            return True

        except Exception as e:
            self.logger.error(f"Error en click_exp_individual: {e}")
            return False
    
    # ENTRADA DE EXPEDIENTES
    
    def enter_expediente_initial(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa el primer expediente usando imagen 004.png.
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente inicial: {expediente}")
            
            # Verificar que SIRAT siga abierto
            if not self.check_app_window_exists():
                self.logger.error("[CRÍTICO] SIRAT se cerró o crasheó antes de ingresar expediente")
                return (Outcome.FAIL_UI, None)
            
            # Buscar y hacer clic en 004.png (campo de expediente)
            self.logger.info("Buscando campo de expediente (004.png)...")
            success = self.find_and_click_image(
                image_name="004.png",
                timeout=10,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if not success:
                self.logger.error("No se pudo encontrar imagen 004.png (campo expediente)")
                return (Outcome.FAIL_UI, None)
            
            # Borrar con 15× CTRL+BACKSPACE
            self.logger.info("Limpiando campo con 15× CTRL+BACKSPACE...")
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.02)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar TAB
            self.logger.info("Presionando TAB...")
            pyautogui.press('tab')
            time.sleep(0.5)
            
            # Detectar error de expediente (esperar 0.5s)
            exp_err, exp_msg = self.detect_expediente_error(timeout=0.5)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            # Buscar 005.png (aviso de expediente inválido), esperar 1 segundo
            self.logger.info("Verificando si aparece aviso de expediente inválido (005.png)...")
            aviso_found = self.find_and_click_image(
                image_name="005.png",
                timeout=1,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if aviso_found:
                self.logger.warning("Aviso de expediente inválido detectado (005.png)")
                # Intentar cerrar el aviso
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            # Si no hay aviso, el expediente es válido
            self.logger.info("Expediente ingresado correctamente (sin aviso)")
            
            # Presionar ALT+A
            self.logger.info("Presionando ALT+A...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(0.5)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente inicial: {e}")
            return (Outcome.FAIL_UI, None)
    
    def enter_expediente_change(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa expediente usando Accesos → Cambio de Expediente (con imagen 004.png).
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        
        Secuencia:
        1. Buscar y clic en 004.png (campo expediente)
        2. Digitar expediente
        3. Presionar TAB
        4. Verificar si aparece error de expediente inválido (005.png, 1s timeout)
        5. Si error: SKIP, Si no: ALT+A para continuar
        
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente (con Cambio): {expediente}")
            
            # Verificar que SIRAT siga abierto
            if not self.check_app_window_exists():
                self.logger.error("[CRÍTICO] SIRAT se cerró o crasheó antes de ingresar expediente")
                return (Outcome.FAIL_UI, None)
            
            # Buscar y hacer clic en 004.png (campo de expediente)
            self.logger.info("Buscando campo de expediente (004.png)...")
            success = self.find_and_click_image(
                image_name="004.png",
                timeout=10,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if not success:
                self.logger.error("No se pudo encontrar imagen 004.png (campo expediente)")
                return (Outcome.FAIL_UI, None)
            
            # Borrar con 15× CTRL+BACKSPACE
            self.logger.info("Limpiando campo con 15× CTRL+BACKSPACE...")
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.02)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar TAB para validar
            self.logger.info("Presionando TAB para validar expediente...")
            pyautogui.press('tab')
            time.sleep(0.5)
            
            # Verificar si aparece error de expediente inválido (005.png, 1s timeout)
            self.logger.info("Verificando si aparece aviso de expediente inválido (005.png)...")
            aviso_found = self.find_and_click_image(
                image_name="005.png",
                timeout=1,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if aviso_found:
                self.logger.warning("Aviso de expediente inválido detectado (005.png)")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            # Si no hay aviso, el expediente es válido
            self.logger.info("Expediente ingresado correctamente (sin aviso)")
            
            # Presionar ALT+A para continuar
            self.logger.info("Presionando ALT+A para continuar...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(0.5)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente (cambio): {e}")
            return (Outcome.FAIL_UI, None)
    
    # NAVEGACIÓN ACCESOS
    
    def iter_all_descendants(self):
        """
        Generador que itera solo los descendientes de la ventana SIRAT.
        La ventana SIRAT es la única ventana relevante para la automatización.
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            try:
                app = desktop.window(title="SIRAT")
                if app.exists(timeout=1):
                    for desc in app.descendants():
                        yield desc
            except Exception:
                pass
        except Exception:
            return
    
    def _find_pbedit_field(self) -> Optional[object]:
        """
        Busca campo PBEDIT de forma flexible, SOLO en la ventana SIRAT.
        Prioridad: PBEDIT125 (para expedientes) → PBEDIT124 → Otros PBEDIT* → Fallback Edit
        
        Retorna el elemento o None si no se encuentra (máximo 3 segundos).
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Obtener ventana SIRAT (la única ventana relevante)
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=1):
                    return None
            except Exception:
                return None
            
            descendants = list(app.descendants())
            
            # Estrategia 1: Buscar PBEDIT125 específicamente (expedientes)
            self.logger.info("Buscando PBEDIT125 (campo estándar para expedientes)...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name == "PBEDIT125":
                        self.logger.info(f"  {class_name} encontrado (estándar para expedientes)")
                        self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] PBEDIT125 encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 1 FALLÓ] PBEDIT125 no encontrado")
            
            # Estrategia 2: Buscar otros PBEDIT* (PBEDIT124, etc.)
            self.logger.info("PBEDIT125 no encontrado, buscando otro PBEDIT*...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name.startswith("PBEDIT"):
                        self.logger.info(f"  {class_name} encontrado (variante)")
                        self.logger.info(f"[ ESTRATEGIA 2 FUNCIONÓ] {class_name} encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 2 FALLÓ] Ningún PBEDIT* encontrado")
            
            # Estrategia 3: Fallback - buscar por tipo Edit
            self.logger.info("PBEDIT* no encontrado, usando fallback (campo Edit)...")
            for element in descendants:
                try:
                    control_type = str(element.element_info.control_type or "")
                    if "Edit" in control_type or "text" in control_type.lower():
                        self.logger.info(f"  Campo editable encontrado por tipo: {control_type}")
                        self.logger.info("[ ESTRATEGIA 3 FUNCIONÓ] Campo Edit encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 3 FALLÓ] Ningún campo Edit encontrado")
            
            return None
        except Exception as e:
            self.logger.debug(f"Error en _find_pbedit_field: {e}")
            return None
    
    def _type_string_preserving_zeros(self, text: str) -> None:
        """
        Escribe un string carácter por carácter para preservar ceros iniciales.
        Evita que pyautogui.write() interprete '029' como número 29.
        """
        text_str = str(text)  # Asegurar que es string
        for char in text_str:
            pyautogui.typewrite(char, interval=0.02)  # typewrite es más seguro para caracteres
        time.sleep(0.2)

    def go_to_accesos_change_expediente(self) -> bool:
        """Va a Accesos → Cambio de Expediente."""
        try:
            self.logger.info("Navegando a Accesos → Cambio de Expediente...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Click en Accesos
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").strip().lower()
                    if name == "accesos":
                        element.click()
                        self.logger.info("  Click en Accesos")
                        time.sleep(0.5)
                        break
                except Exception:
                    continue
            
            # Doble click en Cambio de Expediente
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").lower()
                    if "cambio" in name and "expediente" in name:
                        element.double_click()
                        self.logger.info("  Doble click en Cambio de Expediente")
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue
            
            self.logger.warning("No se encontró Cambio de Expediente")
            return False
        
        except Exception as e:
            self.logger.error(f"Error navegando a Accesos: {e}")
            return False
    
    # NAVEGACIÓN EMBARGO - FUNCIONES SEPARADAS
    
    def click_proceso_embargo(self) -> bool:
        """
        Busca y hace clic en 'Proceso de Embargo' usando imagen 006.png.
        Guarda las coordenadas para reutilizar en restart_embargo_flow().
        """
        # Usar find_and_click_image (busca y clickea)
        if not self.find_and_click_image("006.png", timeout=10):
            return False
        
        # Si se encontró, intentar guardar coordenadas para reinicio rápido
        try:
            image_path = self.img_dir / "006.png"
            if image_path.exists():
                template = cv2.imread(str(image_path))
                if template is not None:
                    screen = np.array(ImageGrab.grab())
                    screen_cv2 = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
                    result = cv2.matchTemplate(screen_cv2, template, cv2.TM_CCOEFF)
                    _, max_val, _, max_loc = cv2.minMaxLoc(result)
                    
                    if max_val > 0.7:
                        h, w = template.shape[:2]
                        self.proceso_embargo_coords = (max_loc[0] + w // 2, max_loc[1] + h // 2)
                        self.logger.info(f" Coords guardadas para reinicio: {self.proceso_embargo_coords}")
        except Exception as e:
            self.logger.debug(f"No se pudieron guardar coords: {e}")
        
        time.sleep(2)
        return True
    
    def click_trabar_embargo(self) -> bool:
        """
        Busca y hace clic en 'Trabar Embargo' usando imagen 007.png.
        """
        self.logger.info("Buscando 'Trabar Embargo' (007.png)...")
        success = self.find_and_click_image(
            image_name="007.png",
            timeout=10,
            click_offset_x=0,
            click_offset_y=0
        )
        
        if success:
            self.logger.info(" 'Trabar Embargo' encontrado y clickeado")
            time.sleep(0.5)
            return True
        else:
            self.logger.error("No se pudo encontrar imagen 007.png (Trabar Embargo)")
            return False
    
    # IEI (INTERVENCIÓN)
    
    def click_trabar_intervencion(self) -> bool:
        """
        Busca y hace clic en 'Trabar Intervención en Información' usando imagen 008.png.
        """
        self.logger.info("Buscando 'Trabar Intervención en Información' (008.png)...")
        success = self.find_and_click_image(
            image_name="008.png",
            timeout=10,
            click_offset_x=0,
            click_offset_y=0
        )
        
        if success:
            self.logger.info(" 'Trabar Intervención en Información' encontrado y clickeado")
            time.sleep(0.5)
            return True
        else:
            self.logger.error("No se pudo encontrar imagen 008.png (Trabar Intervención)")
            return False
    
    def iei_enter_interventor(self, interventor: str) -> Outcome:
        """
        Ingresa código de INTERVENTOR SIN validación de error.
        
        FLUJO SIMPLIFICADO (v2):
        1. Espera 0.5s para renderizado del campo INTERVENTOR
        2. Digita INTERVENTOR
        3. TAB para pasar a PLAZO (sin validación)
        4. Retorna OK_RC inmediatamente
        
        La validación de errores se realiza después en iei_set_plazo_and_confirm()
        mediante los avisos que aparecen tras ALT+A.
        """
        try:
            self.logger.info(f"Ingresando INTERVENTOR: {interventor}")
            
            # Esperar un poco para que se renderice el campo
            time.sleep(0.5)
            
            # Digitar INTERVENTOR directamente (sin hacer clic en el campo)
            self.logger.info(f"Digitando INTERVENTOR: '{interventor}'")
            pyautogui.write(str(interventor), interval=0.05)
            time.sleep(0.3)
            
            # Presionar TAB para pasar al campo PLAZO
            self.logger.info("Presionando TAB para pasar al campo PLAZO...")
            pyautogui.press('tab')
            time.sleep(0.3)
            
            self.logger.info(f" INTERVENTOR ingresado correctamente (sin validación)")
            return Outcome.OK_RC
                    
        except Exception as e:
            self.logger.error(f"Error ingresando interventor: {e}")
            return Outcome.FAIL_UI
    
    def iei_set_plazo_and_confirm(self, plazo: int) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa PLAZO y maneja confirmación simplificada.
        Retorna (Outcome, rc_number).
        
        FLUJO SIMPLIFICADO (v2):
        1. Digitar PLAZO directamente
        2. ALT+A para confirmar
        3. Esperar 1s → ALT+S (primer aviso)
        4. Esperar 1s → ALT+S (segundo aviso)
        5. Buscar "Se grabó la Resolución Coactiva" y extraer RC
        
        El RC siempre comienza con "0" y se guarda como STRING en Excel.
        """
        try:
            self.logger.info(f"Ingresando PLAZO: {plazo}")
            
            # Digitar PLAZO directamente
            self.logger.info(f"Digitando PLAZO: '{plazo}'")
            pyautogui.write(str(plazo), interval=0.05)
            time.sleep(0.3)
            
            # Presionar ALT+A para confirmar pantalla
            self.logger.info("Presionando ALT+A para confirmar PLAZO...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            
            # PRIMER ALT+S (primer aviso)
            self.logger.info("Presionando ALT+S (primer aviso)...")
            pyautogui.hotkey('alt', 's')
            time.sleep(1)
            
            # SEGUNDO ALT+S (segundo aviso)
            self.logger.info("Presionando ALT+S (segundo aviso)...")
            pyautogui.hotkey('alt', 's')
            time.sleep(0.5)
            
            # Buscar RC "Se grabó la Resolución Coactiva con número..."
            self.logger.info("Buscando RC...")
            rc_det, rc_num = self.detect_rc_message(timeout=3.0)
            
            if rc_det and rc_num:
                self.logger.info(f" RC DETECTADA (IEI): {rc_num}")
                
                # Presionar ENTER para cerrar mensaje
                self.logger.info("Presionando ENTER para cerrar mensaje...")
                pyautogui.press('return')
                time.sleep(0.5)
                
                # Presionar ALT+C para cerrar ventana
                self.logger.info("Presionando ALT+C para cerrar ventana...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                
                return (Outcome.OK_RC, rc_num)
            else:
                self.logger.warning("RC no detectada después de confirmación")
                return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en iei_set_plazo_and_confirm: {e}")
            return (Outcome.FAIL_UI, None)
    
    # SELECCIÓN DE TIPO DE EMBARGO
    
    def select_embargo_type(self, tipo_medida: str) -> bool:
        """
        Selecciona el tipo de embargo (IEI o DSE) en 'Trabar Embargo'.
        
        Nota: 'Trabar Embargo' ya debe estar visible (buscado por click_proceso_embargo()).
        Solo selecciona el tipo: IEI (008.png) o DSE (009.png)
        
        Args:
            tipo_medida: "IEI" o "DSE"
        
        Returns:
            True si se seleccionó correctamente, False si hubo error
        """
        try:
            # Seleccionar tipo de embargo
            tipo_upper = str(tipo_medida).strip().upper()
            
            if "IEI" in tipo_upper:
                self.logger.info(f"Seleccionando IEI (Intervención, 008.png)...")
                return self.click_trabar_intervencion()
            elif "DSE" in tipo_upper:
                self.logger.info(f"Seleccionando DSE (Depósito, 009.png)...")
                return self.click_trabar_deposito()
            else:
                self.logger.error(f"Tipo de medida no válido: {tipo_medida}")
                return False
        
        except Exception as e:
            self.logger.error(f"Error seleccionando tipo de embargo: {e}")
            return False
    
    # DSE (DEPÓSITO)
    
    def click_trabar_deposito(self) -> bool:
        """
        Busca y hace clic en 'Trabar Depósito sin Extracción' usando imagen 009.png.
        """
        self.logger.info("Buscando 'Trabar Depósito sin Extracción' (009.png)...")
        success = self.find_and_click_image(
            image_name="009.png",
            timeout=10,
            click_offset_x=0,
            click_offset_y=0
        )
        
        if success:
            self.logger.info(" 'Trabar Depósito sin Extracción' encontrado y clickeado")
            time.sleep(0.5)
            return True
        else:
            self.logger.error("No se pudo encontrar imagen 009.png (Trabar Depósito)")
            return False
    
    def dse_set_monto_and_confirm(self, monto: float) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa MONTO y maneja dos escenarios mediante detección inteligente de mensajes.
        
        FLUJO CORRECTO:
        1. Digitar MONTO en el campo ya seleccionado
        2. Presionar ALT+A para confirmar
        3. Esperar y extraer el PRIMER AVISO que aparece (siempre hay uno)
        4. Comparar el primer aviso:
           IF aviso.startswith("El monto") → MONTO MAYOR:
               - ENTER → 1s → ENTER → ALT+C
               - Retorna: SKIP_MONTO_MAYOR
           ELSE → MONTO VÁLIDO:
               - ALT+S → 1s → ALT+S → Buscar RC
               - Retorna: (OK_RC, numero_rc_como_string)
        """
        try:
            self.logger.info(f"Ingresando MONTO: {monto}")
            
            # PASO 1: Escribir MONTO
            monto_str = str(monto).replace(',', '.')
            self.logger.info(f"Paso 1: Escribiendo monto: {monto_str}")
            pyautogui.write(monto_str, interval=0.05)
            time.sleep(0.5)
            
            # PASO 2: Presionar ALT+A para confirmar monto
            self.logger.info("Paso 2: Presionando ALT+A para confirmar monto...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            
            # PASO 3: Detectar el PRIMER AVISO que aparece
            self.logger.info("Paso 3: Esperando y extrayendo el PRIMER AVISO...")
            aviso_detectado, primer_aviso = self.detect_first_aviso(timeout=3.0)
            
            if not aviso_detectado or not primer_aviso:
                self.logger.warning("No se detectó primer aviso. Retornando OK_RC sin RC.")
                return (Outcome.OK_RC, None)
            
            primer_aviso = str(primer_aviso).strip()
            self.logger.info(f"Primer aviso extraído: '{primer_aviso[:80]}'")
            
            # PASO 4: Comparar si es "El monto..." (MONTO MAYOR)
            if primer_aviso.startswith("El monto"):
                self.logger.warning(f"[ MONTO MAYOR DETECTADO]")
                self.logger.info(f"  Mensaje: '{primer_aviso[:80]}'")
                self.logger.info("  Ruta: ENTER → 1s → ENTER → ALT+C")
                
                # ENTER para cerrar primer aviso
                pyautogui.press('return')
                time.sleep(1)
                
                # ENTER para cerrar segundo aviso (si existe)
                pyautogui.press('return')
                time.sleep(1)
                
                # ALT+C para cancelar
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                
                self.logger.info("Monto rechazado por excesivo. Retornando SKIP_MONTO_MAYOR")
                return (Outcome.SKIP_MONTO_MAYOR, None)
            
            # PASO 5: Monto Válido - Usar ALT+S secuencia
            else:
                self.logger.info(f"[ MONTO VÁLIDO]")
                self.logger.info(f"  Primer aviso NO es 'El monto': '{primer_aviso[:80]}'")
                self.logger.info("  Ruta: ALT+S → 1s → ALT+S → buscar RC")
                
                # Primer ALT+S (cierra "¿Desea Continuar?" o similar)
                pyautogui.hotkey('alt', 's')
                time.sleep(1)
                
                # Segundo ALT+S (cierra "¿Desea grabar Resolución?" o similar)
                pyautogui.hotkey('alt', 's')
                time.sleep(1)
                
                # Buscar el mensaje de RC
                self.logger.info("Buscando mensaje de RC...")
                rc_detectado, rc_num = self.detect_rc_message(timeout=3.0)
                
                if rc_detectado and rc_num:
                    rc_number = str(rc_num).strip()
                    self.logger.info(f"[ RC ENCONTRADA] {rc_number}")
                    
                    # ENTER y ALT+C para cerrar
                    pyautogui.press('return')
                    time.sleep(1)
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    
                    return (Outcome.OK_RC, rc_number)
                else:
                    self.logger.warning("No se detectó RC final. Cerrando...")
                    pyautogui.press('return')
                    time.sleep(1)
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    
                    return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en dse_set_monto_and_confirm: {e}", exc_info=True)
            return (Outcome.FAIL_UI, None)
    
    # REINICIO DE FLUJO PARA SIGUIENTE EXPEDIENTE
    
    def click_proceso_embargo_for_restart(self) -> bool:
        """
        Hace clic en "Proceso de Embargo" usando imagen 006.png.
        Reutiliza coordenadas guardadas si existen (fast path).
        Se usa como primer paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [1/3] Haciendo clic en 'Proceso de Embargo' (006.png)...")
            
            # FAST PATH: Si ya tenemos coordenadas guardadas, usar directo
            if self.proceso_embargo_coords:
                try:
                    click_x, click_y = self.proceso_embargo_coords
                    self.logger.info(f"    Usando coordenadas guardadas: ({click_x}, {click_y})")
                    pyautogui.click(click_x, click_y)
                    time.sleep(2)
                    self.logger.info("    Click completado (coords guardadas)")
                    return True
                except Exception as e:
                    self.logger.warning(f"    Error con coords guardadas: {e}")
                    self.logger.warning("    Intentando búsqueda por imagen...")
            
            # FALLBACK: Usar método que busca y guarda coords
            return self.click_proceso_embargo()
        
        except Exception as e:
            self.logger.error(f"Error en click_proceso_embargo_for_restart: {e}")
            return False
    
    def click_accesos_from_menu(self) -> bool:
        """
        Hace clic en "Accesos" usando imagen 010.png.
        Se usa como segundo paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [2/3] Haciendo clic en 'Accesos' (010.png)...")
            
            success = self.find_and_click_image(
                image_name="010.png",
                timeout=10,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if success:
                self.logger.info("   'Accesos' encontrado y clickeado")
                time.sleep(1)
                return True
            else:
                self.logger.error("  No se pudo encontrar imagen 010.png (Accesos)")
                return False
        
        except Exception as e:
            self.logger.warning(f"Error en click_accesos_from_menu: {e}")
            return False
    
    def double_click_cambio_expediente(self) -> bool:
        """
        Hace clic en "Cambio de Expediente" usando imagen 011.png.
        Se usa como tercer paso en el reinicio de flujo.
        Esto prepara para ingresar el siguiente expediente.
        """
        try:
            self.logger.info("  [3/3] Haciendo clic en 'Cambio de Expediente' (011.png)...")
            
            success = self.find_and_click_image(
                image_name="011.png",
                timeout=10,
                click_offset_x=0,
                click_offset_y=0
            )
            
            if success:
                self.logger.info("   'Cambio de Expediente' encontrado y clickeado")
                time.sleep(1.5)
                return True
            else:
                self.logger.error("  No se pudo encontrar imagen 011.png (Cambio de Expediente)")
                return False
        
        except Exception as e:
            self.logger.warning(f"Error en double_click_cambio_expediente: {e}")
            return False
    
    def restart_embargo_flow(self) -> bool:
        """
        Reinicia el flujo de embargo para pasar al siguiente expediente.
        
        Secuencia:
        1. Click en "Proceso de Embargo" (006.png) - usa coordenadas guardadas si existen
        2. Click en "Accesos" (010.png)
        3. Click en "Cambio de Expediente" (011.png)
        
        Se usa después de completar un expediente (monto mayor, RC extraída en IEI/DSE).
        
        Las coordenadas de "Proceso de Embargo" se guardan en la primera ejecución
        para reutilizarlas y evitar búsqueda repetida por imagen.
        
        Retorna: True si completó todos los pasos, False si hay error
        """
        try:
            self.logger.info("\n[REINICIO] Reiniciando flujo para siguiente expediente...")
            self.logger.info("=" * 70)
            
            # PASO 1: Click en "Proceso de Embargo" (006.png)
            # Usar coordenadas guardadas si existen
            if self.proceso_embargo_coords:
                self.logger.info("  [1/3] Usando coordenadas guardadas de 'Proceso de Embargo'...")
                try:
                    click_x, click_y = self.proceso_embargo_coords
                    self.logger.info(f"    Clickeando en coordenadas guardadas: ({click_x}, {click_y})")
                    pyautogui.click(click_x, click_y)
                    time.sleep(2)
                    self.logger.info("   Click en 'Proceso de Embargo' completado (coordenadas guardadas)")
                except Exception as e:
                    self.logger.warning(f"    Error usando coordenadas guardadas: {e}")
                    self.logger.warning("    Intentando búsqueda por imagen...")
                    if not self.click_proceso_embargo():
                        self.logger.warning("   No se pudo hacer clic en 'Proceso de Embargo'")
                        return False
            else:
                self.logger.info("  [1/3] Buscando 'Proceso de Embargo' por imagen (primera vez)...")
                if not self.click_proceso_embargo():
                    self.logger.warning("   No se pudo hacer clic en 'Proceso de Embargo'")
                    return False
            
            # PASO 2: Click en "Accesos" (010.png)
            if not self.click_accesos_from_menu():
                self.logger.warning("   No se pudo hacer clic en 'Accesos'")
                return False
            
            # PASO 3: Click en "Cambio de Expediente" (011.png)
            if not self.double_click_cambio_expediente():
                self.logger.warning("   No se pudo hacer clic en 'Cambio de Expediente'")
                return False
            
            self.logger.info("   Flujo reiniciado exitosamente")
            self.logger.info("=" * 70)
            return True
        
        except Exception as e:
            self.logger.error(f"Error reiniciando flujo de embargo: {e}")
            return False
    
    def fill_monto(self, monto_value: str) -> bool:
        """
        Llena el campo de MONTO en el formulario (usado para Trabar Depósito sin Extracción - MEPECO).
        
        Flujo:
        1. Espera 0.5 segundos
        2. Digita el MONTO directamente
        3. Presiona ALT+A para confirmar
        4. Detecta si hay mensaje de aviso (puede variar según el monto)
        5. Retorna True si se completó exitosamente
        
        El campo MONTO aparece después de ejecutar "Trabar Depósito sin Extracción".
        """
        self.logger.info("Rellenando campo de MONTO...")
        
        try:
            # ============================================================
            # PASO 1: Esperar 0.5s y digitar MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 1: Esperando 0.5s y digitando MONTO")
            self.logger.info("=" * 70)
            
            # Esperar 0.5 segundos antes de digitar MONTO
            self.logger.info("Esperando 0.5 segundos antes de digitar MONTO...")
            time.sleep(0.5)
            
            # Digitar MONTO directamente con intervalo entre caracteres
            self.logger.info(f"Digitando MONTO: '{monto_value}'")
            pyautogui.write(monto_value, interval=0.05)
            time.sleep(0.3)
            
            # ============================================================
            # PASO 2: Presionar ALT+A para confirmar
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 2: Presionando ALT+A para confirmar MONTO")
            self.logger.info("=" * 70)
            
            self.logger.info("Presionando ALT+A...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            self.logger.info(" ALT+A presionado correctamente")
            
            # ============================================================
            # PASO 3: Detectar mensaje de aviso del MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 3: Detectando posible mensaje de aviso del MONTO")
            self.logger.info("=" * 70)
            
            # La detección de avisos se realiza en workflow.py/app_driver.py
            # mediante detect_monto_aviso() que es llamado después de fill_monto()
            self.logger.info("Aviso (si existe) será detectado en paso posterior")
            
            self.logger.info("=" * 70)
            self.logger.info(" CAMPO MONTO COMPLETADO EXITOSAMENTE")
            self.logger.info("=" * 70)
            
            return True
        
        except Exception as e:
            self.logger.error(f"Error en fill_monto: {str(e)}")
            return False
    
    # EXTRACCIÓN DE RC
    
    def _extract_rc_from_dialog(self) -> Optional[str]:
        """Busca mensaje de RC y extrae el número. Retorna string "XXXXX" o None."""
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            for element in self.iter_all_descendants():
                try:
                    text = str(element.element_info.name or "").lower()
                    
                    if "se grabó" in text and "resolución" in text and "número" in text:
                        # Encontrado el mensaje, extraer número
                        full_text = str(element.element_info.name or "")
                        
                        # Buscar la palabra "número" y extraer dígitos después
                        idx = full_text.lower().find("número")
                        if idx >= 0:
                            after_numero = full_text[idx + 6:]
                            # Extraer dígitos consecutivos
                            rc = ""
                            for char in after_numero:
                                if char.isdigit():
                                    rc += char
                                elif rc:  # Si ya tenemos dígitos y encontramos no-dígito, terminar
                                    break
                            
                            if rc:
                                return rc
                except Exception:
                    continue
            
            return None
        
        except Exception as e:
            self.logger.warning(f"Error extrayendo RC: {e}")
            return None
