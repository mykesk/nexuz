"""
workflow.py - Lógica de negocio y state machine del flujo RSIRAT
Responsabilidades:
  1. Definir Outcome (enums) y ContextoExpediente (dataclass)
  2. Orquestar el flujo por dependencia (state machine con has_active_expediente)
  3. Procesar cada expediente: categorizar tipo (IEI/DSE) y ejecutar flujo
  4. Manejar retorno a "Accesos → Cambio de Expediente" después del primer expediente válido
  5. Retornar list de outcomes con razones
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Dict, Callable, Optional
import logging
import pandas as pd
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app_driver import AppDriver


# ENUMS Y DATACLASSES
class Outcome(Enum):
    """Estados posibles al terminar un expediente."""
    OK_RC = auto()                          # Éxito: RC grabada
    SKIP_EXP_INVALIDO = auto()              # Expediente inválido en RSIRAT
    SKIP_INTERVENTOR_INVALIDO = auto()      # Código de interventor inválido (IEI)
    SKIP_MONTO_MAYOR = auto()               # Monto excede saldo (DSE)
    FAIL_LOGIN_PASSWORD = auto()             # Contraseña incorrecta (crítico)
    FAIL_UI = auto()                        # Error UI inesperado
    SKIP_DATA_INCOMPLETE = auto()            # Datos incompletos en Excel


def outcome_to_label(outcome: Outcome) -> str:
    """
    Convierte un Outcome a etiqueta legible para guardar en Excel.
    
    Mapeo:
    - OK_RC → "OK_RC"
    - SKIP_EXP_INVALIDO → "EXP INVALIDO"
    - SKIP_INTERVENTOR_INVALIDO → "INTERVENTOR INVALIDO"
    - SKIP_MONTO_MAYOR → "MONTO MAYOR"
    - SKIP_DATA_INCOMPLETE → "DATOS INCOMPLETOS"
    - FAIL_LOGIN_PASSWORD → "CONTRASEÑA INCORRECTA"
    - FAIL_UI → "FAIL_UI"
    """
    mapping = {
        Outcome.OK_RC: "OK_RC",
        Outcome.SKIP_EXP_INVALIDO: "EXP INVALIDO",
        Outcome.SKIP_INTERVENTOR_INVALIDO: "INTERVENTOR INVALIDO",
        Outcome.SKIP_MONTO_MAYOR: "MONTO MAYOR",
        Outcome.SKIP_DATA_INCOMPLETE: "DATOS INCOMPLETOS",
        Outcome.FAIL_LOGIN_PASSWORD: "CONTRASEÑA INCORRECTA",
        Outcome.FAIL_UI: "FAIL_UI",
    }
    return mapping.get(outcome, outcome.name)


@dataclass
class ContextoExpediente:
    """Contexto de un expediente siendo procesado."""
    expediente: str
    row_idx: int
    dependencia: str
    tipo_medida: str  # "IEI" o "DSE"
    interventor: Optional[str] = None
    ejecutor: Optional[str] = None
    plazo: Optional[int] = None
    monto: Optional[float] = None


@dataclass
class ProcessOutcome:
    """Resultado del procesamiento de un expediente."""
    expediente: str
    row_idx: int
    dependencia: str
    outcome: Outcome
    rc_number: Optional[str] = None
    reason: str = ""
    error_detail: str = ""


# VALIDACIONES EXCEL
def validate_expediente_row(row: pd.Series, row_idx: int) -> tuple[bool, str]:
    """
    Valida que una fila del Excel tenga los datos necesarios.
    
    Retorna: (is_valid, error_msg)
    """
    dependencia = str(row.get("DEPENDENCIA", "")).strip()
    tipo = str(row.get("TIPO DE MEDIDA", "")).strip().upper()
    interventor = str(row.get("INTERVENTOR", "")).strip()
    plazo = str(row.get("PLAZO", "")).strip()
    monto = str(row.get("MONTO", "")).strip()
    
    # Validar DEPENDENCIA
    if not dependencia or dependencia == "nan":
        return False, "Falta DEPENDENCIA"
    
    # Validar TIPO DE MEDIDA
    if not tipo or tipo == "NAN":
        return False, "Falta TIPO DE MEDIDA"
    
    if tipo not in ["IEI", "DSE"]:
        return False, f"TIPO DE MEDIDA debe ser IEI o DSE, encontrado: {tipo}"
    
    # Validar según tipo
    if "IEI" in tipo:
        if not interventor or interventor == "nan":
            return False, "IEI requiere INTERVENTOR"
        if not plazo or plazo == "nan":
            return False, "IEI requiere PLAZO"
    
    elif "DSE" in tipo:
        if not monto or monto == "nan":
            return False, "DSE requiere MONTO"
    
    return True, ""


# ESTADO MACHINE PRINCIPAL
def process_dependency(
    dependencia: str,
    indices: List[int],
    df: pd.DataFrame,
    driver: "AppDriver",
    update_result_fn: Callable,
    is_first: bool,
    is_last: bool,
    logger: logging.Logger,
    password: str
) -> List[ProcessOutcome]:
    """
    Procesa TODOS los expedientes de una dependencia en una sesión.
    
    State machine:
      1. Si is_first: abrir app + login
      2. Navegar a modulo base
      3. Para cada expediente:
         - Si es el primero válido: entrar sin Accesos, luego has_active=True
         - Si es siguiente: ir a Accesos → Cambio expediente
         - Procesar (IEI o DSE)
      4. Si is_last: cerrar app
    
    Retorna: lista de ProcessOutcome
    """
    outcomes = []
    has_active_expediente = False  # Controla si podemos usar "Accesos"
    
    logger.info(f"Iniciando procesamiento de {len(indices)} expediente(s)...")
    
    # -------- FASE 1: Abrir app y login (solo si es primera dependencia) --------
    if is_first:
        logger.info("[INIT] Abriendo aplicación...")
        if not driver.open_app():
            logger.error("   No se pudo abrir la aplicación")
            # Registrar fallo en todos los expedientes
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo abrir aplicación"
                ))
            return outcomes
        
        logger.info("[LOGIN] Autenticando...")
        login_outcome = driver.login(dependencia, password)
        if login_outcome != Outcome.OK_RC:
            logger.error(f"   Login falló: {login_outcome.name}")
            # Registrar fallo en todos los expedientes
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=login_outcome,
                    reason="Fallo en login"
                ))

            # Actualizar SOLO la PRIMERA fila con el mensaje específico de contraseña
            try:
                if login_outcome == Outcome.FAIL_LOGIN_PASSWORD and len(indices) > 0:
                    first_row = indices[0]
                    update_result_fn(first_row, "CONTRASEÑA INCORRECTA")
            except Exception as e:
                logger.warning(f"No se pudo actualizar Excel (primer fila) por fallo de login: {e}")

            return outcomes
        
        logger.info("   Login exitoso")
        
        # Navegar al módulo (Cobranza Coactiva)
        logger.info("[NAV] Navegando a módulo base...")
        if not driver.navigate_to_module():
            logger.error("   No se pudo navegar al módulo")
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo navegar al módulo"
                ))
            return outcomes
        
        logger.info("   Módulo listo")
    
    # -------- FASE 2: Procesar cada expediente --------
    for pos, row_idx in enumerate(indices, 1):
        logger.info(f"\n[EXP {pos}/{len(indices)}] Procesando fila {row_idx + 1}...")
        
        row = df.iloc[row_idx]
        expediente = str(row["EXPEDIENTE"]).strip()
        
        # Validar datos en Excel
        is_valid, error_msg = validate_expediente_row(row, row_idx)
        if not is_valid:
            logger.warning(f"   Datos incompletos: {error_msg}")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.SKIP_DATA_INCOMPLETE,
                reason=error_msg
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, error_msg)
            continue
        
        # Crear contexto (usar conversiones seguras para PLAZO y MONTO)
        # Interventor
        interventor_val = None
        if "INTERVENTOR" in row.index:
            iv_raw = row.get("INTERVENTOR", "")
            if pd.notna(iv_raw):
                s_iv = str(iv_raw).strip()
                if s_iv != "":
                    interventor_val = s_iv

        # Plazo (int seguro)
        plazo_val = None
        if "PLAZO" in row.index:
            raw_plazo = row["PLAZO"]
            if pd.notna(raw_plazo):
                s_plazo = str(raw_plazo).strip()
                if s_plazo != "":
                    try:
                        # Manejar valores como '1.0' o '1'
                        plazo_val = int(float(s_plazo))
                    except Exception:
                        plazo_val = None

        # Monto (float seguro)
        monto_val = None
        if "MONTO" in row.index:
            raw_monto = row["MONTO"]
            if pd.notna(raw_monto):
                s_monto = str(raw_monto).strip()
                if s_monto != "":
                    try:
                        monto_val = float(s_monto)
                    except Exception:
                        monto_val = None

        # Ejecutora/ejecutor esperado (desde Excel, columna 'EJECUTOR' opcional)
        ejecutor_val = None
        if "EJECUTOR" in row.index:
            raw_ejec = row.get("EJECUTOR", "")
            if pd.notna(raw_ejec):
                s_ejec = str(raw_ejec).strip()
                if s_ejec != "":
                    ejecutor_val = s_ejec

        ctx = ContextoExpediente(
            expediente=expediente,
            row_idx=row_idx,
            dependencia=dependencia,
            tipo_medida=str(row["TIPO DE MEDIDA"]).strip().upper(),
            interventor=interventor_val,
            ejecutor=ejecutor_val,
            plazo=plazo_val,
            monto=monto_val
        )
        
        # -------- Ingresar expediente --------
        if has_active_expediente:
            # Segundo expediente en adelante
            # El expediente anterior fue válido y completado exitosamente (OK_RC) con IEI o DSE
            # Se necesita hacer el flujo: Proceso de Embargo → Accesos → Cambio de Expediente
            # para limpiar los menús y dejar visible "Cambio de Expediente"
            logger.info(f"  Expediente anterior fue procesado exitosamente")
            logger.info(f"  Navegando mediante flujo de embargo para cambio de expediente...")
            logger.info(f"    (Proceso de Embargo → Accesos → Cambio de Expediente)")
            
            if not driver.restart_embargo_flow():
                logger.error("   No se pudo hacer restart del flujo de embargo")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo hacer restart del flujo"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_RESTART_EMBARGO")
                continue
            
            # El método restart_embargo_flow() ya incluye ir a Accesos → Cambio de Expediente
            # así que solo queda ingresar el expediente
            outcome, rc = driver.enter_expediente_change(ctx.expediente)
        else:
            # Primer expediente: sin limpieza previa
            logger.info(f"  Ingresando expediente inicial...")
            outcome, rc = driver.enter_expediente_initial(ctx.expediente)
        
        # -------- Procesar resultado de ingreso de expediente --------
        if outcome == Outcome.OK_RC:
            logger.info(f"   Expediente válido encontrado")
        else:
            # El expediente no fue válido (SKIP_EXP_INVALIDO u otro error)
            logger.info(f"   Expediente fue rechazado")
            has_active_expediente = False
        
        # IMPORTANTE: Si expediente fue validado (OK_RC), enviar Alt+A para continuar con embargo
        # Alt+A es NECESARIO DESPUÉS DE CADA INGRESO DE EXPEDIENTE VÁLIDO:
        # - MOMENTO 1: Primer expediente (después de enter_expediente_initial)
        # - MOMENTO 2: Segundo expediente en adelante (después de enter_expediente_change)
        # Alt+A acepta el expediente y permite continuar al siguiente paso (Trabar Embargo)
        if outcome == Outcome.OK_RC:
            logger.info(f"  Enviando Alt+A para aceptar expediente y continuar...")
            import pyautogui
            import time as time_module
            pyautogui.hotkey('alt', 'a')
            time_module.sleep(1.5)  # Tiempo para que app procese el cambio
            
            # Enfocar ventana SIRAT después de Alt+A
            logger.info(f"  Enfocando ventana SIRAT...")
            t0_enfoque = time_module.time()
            driver.ensure_sirat_focus()
            t1_enfoque = time_module.time()
            logger.info(f"  [TIMER] ensure_sirat_focus() completó en {t1_enfoque - t0_enfoque:.3f}s")
            time_module.sleep(0.3)
            
            # PARA AMBOS CASOS (primer y segundo expediente en adelante):
            # Navegar a Trabar Embargo
            logger.info(f"  Navegando a 'Trabar Embargo'...")
            
            # PASO 1: Hacer clic en "Proceso de Embargo" (006.png)
            if not driver.click_proceso_embargo():
                logger.error("   No se pudo hacer clic en 'Proceso de Embargo'")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo hacer clic en 'Proceso de Embargo'"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_EMBARGO_NAV")
                continue
            
            # PASO 2: Hacer clic en "Trabar Embargo" (007.png)
            if not driver.click_trabar_embargo():
                logger.error("   No se pudo hacer clic en 'Trabar Embargo'")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo hacer clic en 'Trabar Embargo'"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_EMBARGO_NAV")
                continue
            
            # Seleccionar tipo de embargo (IEI o DSE) en Trabar Embargo
            logger.info(f"   Seleccionando tipo de medida: {ctx.tipo_medida}...")
            select_result = driver.select_embargo_type(ctx.tipo_medida)
            logger.info(f"     └─ Resultado select_embargo_type: {select_result}")
            
            if not select_result:
                logger.error(f"    No se pudo seleccionar tipo {ctx.tipo_medida}")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason=f"No se pudo seleccionar tipo {ctx.tipo_medida}"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, f"FAIL_{ctx.tipo_medida}_SELECT")
                continue
            
            logger.info(f"      Tipo {ctx.tipo_medida} seleccionado correctamente")
            
            # IMPORTANTE: Después de seleccionar el tipo de medida,
            # marcar que tenemos un expediente activo en la UI para procesar
            has_active_expediente = True
            logger.info(f"     EXPEDIENTE ACTIVO EN UI: has_active_expediente = True")
        
        # Si expediente inválido, continuar
        if outcome == Outcome.SKIP_EXP_INVALIDO:
            logger.warning(f"   Expediente inválido")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome,
                reason="Expediente no válido en RSIRAT"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, "EXP_INVALIDO")
            # Resetear has_active_expediente cuando un expediente es inválido
            # Sin importar si fue ingresado por primera vez o mediante "Cambio de Expediente"
            has_active_expediente = False
            continue
        
        if outcome != Outcome.OK_RC or not has_active_expediente:
            # Error inesperado - debugging detallado
            logger.error(f"    ERROR AL INGRESAR EXPEDIENTE - DEBUG INFO:")
            logger.error(f"      - outcome: {outcome}")
            logger.error(f"      - outcome == OK_RC: {outcome == Outcome.OK_RC}")
            logger.error(f"      - has_active_expediente: {has_active_expediente}")
            logger.error(f"      - tipo_medida: {ctx.tipo_medida}")
            logger.error(f"      - expediente: {expediente}")
            logger.error(f"      - Razón: {'outcome no es OK_RC' if outcome != Outcome.OK_RC else 'no hay expediente activo'}")
            
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome if outcome else Outcome.FAIL_UI,
                reason="Error al ingresar expediente"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome))
            continue
        
        # -------- Procesar según tipo --------
        logger.info(f"   PROCESANDO EXPEDIENTE: {ctx.tipo_medida}")
        logger.info(f"     - Expediente: {expediente}")
        logger.info(f"     - Dependencia: {dependencia}")
        logger.info(f"     - Fila: {row_idx}")
        
        if "IEI" in ctx.tipo_medida:
            logger.info(f"   Ejecutando process_iei()...")
            outcome_obj = process_iei(ctx, driver, logger)
            logger.info(f"   process_iei() retornó: {outcome_obj.outcome} | RC: {outcome_obj.rc_number}")
        elif "DSE" in ctx.tipo_medida:
            logger.info(f"   Ejecutando process_dse()...")
            outcome_obj = process_dse(ctx, driver, logger)
            logger.info(f"   process_dse() retornó: {outcome_obj.outcome} | RC: {outcome_obj.rc_number}")
        else:
            logger.error(f"   Tipo desconocido: {ctx.tipo_medida}")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.FAIL_UI,
                reason=f"Tipo desconocido: {ctx.tipo_medida}"
            )
        
        outcomes.append(outcome_obj)
        
        # Actualizar Excel
        if outcome_obj.outcome == Outcome.OK_RC and outcome_obj.rc_number:
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome), outcome_obj.rc_number)
            logger.info(f"   RC guardada: {outcome_obj.rc_number}")
        else:
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome))
            logger.warning(f"   {outcome_to_label(outcome_obj.outcome)}: {outcome_obj.reason}")
        
        # -------- ESTABLECER has_active_expediente SOLO DESPUÉS DE ÉXITO --------
        # IMPORTANTE: has_active_expediente es True cuando se completó exitosamente
        # un expediente en la UI (OK_RC o SKIP_MONTO_MAYOR, etc).
        # Es False solo si fue rechazado ANTES de llegar a la UI (EXP_INVALIDO, etc).
        # 
        # Esto habilita el flujo "Proceso de Embargo → Accesos → Cambio de Expediente"
        # para el siguiente expediente, ya que el anterior dejó la aplicación en un
        # estado consistente.
        if outcome_obj.outcome in [Outcome.OK_RC, Outcome.SKIP_MONTO_MAYOR, Outcome.SKIP_INTERVENTOR_INVALIDO]:
            has_active_expediente = True
            logger.info(f"    Expediente procesado en UI, habilitando flujo de cambio para siguiente")
        else:
            has_active_expediente = False
            logger.info(f"    Expediente rechazado sin procesar UI, se debe ingresar siguiente de forma inicial")
        
    # -------- FASE 3: Cerrar app (solo si es última dependencia) --------
    if is_last:
        logger.info("\n[CLOSE] Cerrando aplicación...")
        driver.close_app()
        logger.info("   Aplicación cerrada")
    
    logger.info(f"\nDependencia {dependencia} completada: {len(outcomes)} expediente(s) procesado(s)")
    return outcomes


# PROCESOS ESPECÍFICOS POR TIPO
def process_iei(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:
    """Procesa un expediente tipo IEI (Intervención en Información).
    
    IMPORTANTE: Asume que ya se navegó a Trabar Embargo y se seleccionó IEI.
    Solo ingresa INTERVENTOR y PLAZO.
    """
    logger.info(f"  [IEI]  INICIANDO PROCESO IEI")
    logger.info(f"       - Expediente: {ctx.expediente}")
    logger.info(f"       - Interventor: {ctx.interventor}")
    logger.info(f"       - Plazo: {ctx.plazo}")
    
    # NOTA: Ya se navegó a Trabar Embargo y se seleccionó IEI en logica.py
    # Ahora solo ingresamos los datos del formulario
    
    # 1. Ingresar INTERVENTOR
    logger.info(f"  [IEI] PASO 1: Ingresando INTERVENTOR = '{ctx.interventor}'...")
    outcome_int = driver.iei_enter_interventor(ctx.interventor)
    if outcome_int != Outcome.OK_RC:
        logger.error(f"        INTERVENTOR FALLÓ: {outcome_int.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_int,
            reason="Código de interventor inválido"
        )
    logger.info(f"        INTERVENTOR ingresado correctamente")
    
    # 2. Ingresar PLAZO y confirmar
    logger.info(f"  [IEI] PASO 2: Ingresando PLAZO = {ctx.plazo}...")
    outcome_plazo, rc = driver.iei_set_plazo_and_confirm(ctx.plazo)
    if outcome_plazo != Outcome.OK_RC:
        logger.error(f"        PLAZO FALLÓ: {outcome_plazo.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_plazo,
            reason="Error al setear plazo o confirmar RC"
        )
    logger.info(f"        PLAZO ingresado y confirmado")
    
    logger.info(f"  [IEI]  Completado exitosamente con RC={rc}")
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="IEI completado exitosamente"
    )


def process_dse(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:
    """
    Procesa un expediente tipo DSE (Depósito Sin Extracción).
    
    IMPORTANTE: Asume que ya se navegó a Trabar Embargo y se seleccionó DSE.
    Solo ingresa MONTO.
    
    FLUJO:
    1. Ingresar MONTO
    
    El monto puede resultar en DOS ESCENARIOS:
    
    ESCENARIO 1 - MONTO MAYOR (RECHAZADO):
    - El sistema muestra uno o más avisos:
      * "El monto ingresado excede en mas del 20% el Saldo del Expediente"
      * "El monto de embargo ingresado supera el saldo embargable del expediente"
    - Se responde con ENTER a cada aviso (uno, dos, o en cualquier orden)
    - Luego ALT+C para cerrar
    - Retorna: SKIP_MONTO_MAYOR (expediente se salta, no hay RC)
    
    ESCENARIO 2 - MONTO VÁLIDO (ACEPTADO):
    - Secuencia de avisos de confirmación:
      1. "¿ Desea Continuar ?" → ALT+S
      2. "¿Desea Ud. grabar la Resolución?" → ALT+S
      3. "Se grabó la Resolución Coactiva con el número XXX" → RC extraída, ENTER, ALT+C
    - Retorna: OK_RC con número de resolución coactiva (como STRING, preserva 0s)
    """
    logger.info(f"  [DSE]  INICIANDO PROCESO DSE")
    logger.info(f"       - Expediente: {ctx.expediente}")
    logger.info(f"       - Monto: {ctx.monto}")
    logger.info(f"  [DSE] Iniciando proceso...")
    
    # NOTA: Ya se navegó a Trabar Embargo y se seleccionó DSE en logica.py
    # Ahora solo ingresamos el MONTO
    
    # 1. Ingresar MONTO y confirmar
    logger.info(f"  [DSE] PASO 1: Ingresando MONTO = {ctx.monto}...")
    outcome_monto, rc = driver.dse_set_monto_and_confirm(ctx.monto)
    logger.info(f"       └─ dse_set_monto_and_confirm() retornó: outcome={outcome_monto.name}, rc={rc}")
    
    if outcome_monto == Outcome.SKIP_MONTO_MAYOR:
        logger.warning(f"        MONTO RECHAZADO: Excede saldo disponible")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Monto excede saldo disponible o límites permitidos"
        )
    
    if outcome_monto != Outcome.OK_RC:
        logger.error(f"        ERROR EN MONTO: {outcome_monto.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Error al procesar monto"
        )
    
    logger.info(f"        MONTO ingresado correctamente")
    logger.info(f"  [DSE]  Completado exitosamente con RC={rc}")
    
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="DSE completado exitosamente"
    )
