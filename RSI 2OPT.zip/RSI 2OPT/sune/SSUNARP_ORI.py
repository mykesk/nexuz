from selenium import webdriver #SOLO Con selenium podemos usar driver. 
from selenium.webdriver.support.ui import Select #Menu desplegable
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
#from selenium.common.exceptions import NoSuchElementException
import base64
from getpass import getuser
import datetime
import time
import os
import shutil
import pyautogui as py
import constantes as cte
import json
import openpyxl
import pandas as pd 
import pyautogui
from PyPDF2 import PdfFileMerger
from sys import version_info
if version_info.major == 2:
    import Tkinter as tk
elif version_info.major == 3:
    import tkinter as tk

#==============================================================================
#
#==============================================================================
# Procedimiento de  definicion de forma de inicio de GoogleChrome
#==============================================================================
def IniciarGoogleChrome():
    if inicio_diver==0:
        IniciarGoogleChrome0()
    else:
        IniciarGoogleChrome1()
#============================================================================== 
#==============================================================================
# Procedimiento de Inicio de GoogleChrome
#==============================================================================       
def IniciarGoogleChrome0():  
    global driver # Variable global de navegador
    appState = {
    "recentDestinations": [
        {
            "id": "Save as PDF",
            "origin": "local",
            "account": ""
        }
    ],
    "mediaSize": {
        "name": "Pagina"
    },
    "selectedDestinationId": "Save as PDF",
    "version": 2  
    }
    download_path = os.getcwd() + '\Descargas' #ruta donde se almacena lass descargas
    profile = {'printing.print_preview_sticky_settings.appState': json.dumps(appState),
               'savefile.default_directory': download_path }
    
    chrome_options = webdriver.ChromeOptions()
    #chrome_options.binary_location = "C:\\Program Files (x86)\\Google\Chrome\\Application\\new_chrome.exe"
    chrome_options.add_experimental_option('prefs', profile)
    chrome_options.add_argument('--kiosk-printing')
    chrome_options.page_load_strategy = 'normal' #'none' 
    chrome_options.add_argument("--headless") #inicia Chrome en segundo plano
    chrome_options.add_argument('--log-level=3') #prueba para eliminar mensajes de advertencia
    path =".\\chromedriver.exe" #Ruta donde se encuentra el chromedriver
    executable_path=os.path.abspath(path) #ruta del ejecutable chromedriver.exe
    driver = webdriver.Chrome(executable_path,options=chrome_options) #Ejecucion del chromedriver
    driver.maximize_window() #maximizar ventana
    driver.get("https://enlinea.sunarp.gob.pe/")#ventana para usuario y clave SUNARP Extranet
    return driver
#==============================================================================
#==============================================================================
# Procedimiento de Inicio de GoogleChrome
#==============================================================================
def IniciarGoogleChrome1():  
    global driver # Variable global de navegador
    appState = {
    "recentDestinations": [
        {
            "id": "Save as PDF",
            "origin": "local",
            "account": ""
        }
    ],
    "mediaSize": {
        "name": "Pagina"
    },
    "selectedDestinationId": "Save as PDF",
    "version": 2  
    }
    download_path = os.getcwd() + '\Descargas' #ruta donde se almacena lass descargas
    profile = {'printing.print_preview_sticky_settings.appState': json.dumps(appState),
               'savefile.default_directory': download_path }
    
    chrome_options = webdriver.ChromeOptions()
    #chrome_options.binary_location = "C:\\Program Files (x86)\\Google\Chrome\\Application\\new_chrome.exe" 
    chrome_options.add_experimental_option('prefs', profile)
    chrome_options.add_argument('--kiosk-printing')
    chrome_options.page_load_strategy = 'normal' #'none' 
    #chrome_options.add_argument("--headless") #inicia Chrome en segundo plano
    chrome_options.add_argument('--log-level=3') #prueba para eliminar mensajes de advertencia
    path =".\\chromedriver.exe" #Ruta donde se encuentra el chromedriver
    executable_path=os.path.abspath(path) #ruta del ejecutable chromedriver.exe
    driver = webdriver.Chrome(executable_path,options=chrome_options) #Ejecucion del chromedriver
    driver.maximize_window() #maximizar ventana
    driver.get("https://enlinea.sunarp.gob.pe/")#ventana para usuario y clave SUNARP Extranet
    return driver
#==============================================================================
# Cerrar el GoogleChrome
#==============================================================================
def CerrarGoogleChrome():#Cerrar GogleChrome
    driver.stop_client()#Deteniendo
    try:
       driver.close()#Cerrando el Chrome
    except:
        py.alert("Cerrando Navegador-CerrarGoogleChrome",timeout=cte.AVISO1)
#==============================================================================

#==============================================================================
#
#
#==============================================================================
def leer_ruta_t():
    global ruta_tp
    path_usuario=r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    abspath_usuario=os.path.abspath(path_usuario)#Ruta del archivo txt   
    with open (abspath_usuario) as Usuario: # USUARIO   
        for line in Usuario:  #Leyedo usuario intranet
            #driver.find_element_by_name('username').send_keys(line) #Ingreso de usuario
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'username'))).send_keys(line) #Ingreso de usuario

#==============================================================================
#Manejor de Archivos Excel 
#==============================================================================
# Leer Oficinas Registrales:
# Lee Oficinas Registrales y lo almacena  en un areglo dataframe
#==============================================================================
def leer_ofregistrales():
    global hojaof # datos de Oficinas Registrales
    excel_of=pd.ExcelFile('Of_Registrales.xlsx') #Lee archivo excel
    hojaof=excel_of.parse('Oficinas_Registrales') #Lee la hoja que contiene datos de las oficinas registrales
    excel_of.close()
    return hojaof

#==============================================================================
# Encontrar valor de las Oficinas Registrales:
# Devuelve el valor de las Obtenido al buscar las Oficinas Registrales
#==============================================================================
def valor_ofregistrales(oficina_r):
    #print(hojaof[hojaof.nombre_OR=='LIMA'].Valor) #Si funciona
    valor_or=hojaof[hojaof.nombre_OR==oficina_r].Valor #Busca la fila que contiene la OF y se le asigana el campo Valor como data frame
    v_oficina_r=str(valor_or.iloc[0]) # se obtiene el valor del unico indice
    return v_oficina_r
#==============================================================================

#==============================================================================
# Generar Nombre de Busqueda:
# Completa Nombre de busqueda en Base_Contribuyente.xlsx
#==============================================================================
def completar_NB():
    excel_document_c = openpyxl.load_workbook('Base_Contribuyente_T.xlsx')
    sheetc = excel_document_c.get_sheet_by_name('Base')
    excel_document1_c = pd.ExcelFile('Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheetD1_c=excel_document1_c.parse('Relacion_C') #Leer relaciones
    i=2
    band=0
    valor=sheetc.cell(i, 2).value
    valor=valor.strip()
    sheetc.cell(i, 2).value=valor
    revisarnp=[[],[]]
    while valor != None:
        separador=sheetD1_c[sheetD1_c.Tipo_Contribuyente==sheetc.cell(i, 4).value]
        separador1=separador[separador.Tipo_S==1].Valor_Referencia
        separador0=separador[separador.Tipo_S==0].Valor_Referencia
        nombreB=sheetc.cell(i, 2).value
        if (sheetc.cell(i, 4).value =="PERSONA NATURAL CON NEGOCIO" or sheetc.cell(i, 
            4).value =="PERSONA NATURAL SIN NEGOCIO" or sheetc.cell(i, 4).value ==
           "SUCESION INDIVISA SIN NEGOCIO"):
            if str(areaR1)=='1':
                nombreB=nombreB.replace("SUCESION INDIVISA ","")
                nombreB=nombreB.replace("SUCESION INDIVISA DE ","")
                nombre=nombrePropio(nombreB)
                sheetc.cell(i, 3).value=nombre[0][0]+"|"+nombre[0][1]+"|"+nombre[0][2]
                if nombre[1][0]==1:
                    revisarnp[0].append(i)
                    revisarnp[1].append(sheetc.cell(i, 3).value)
                    
        else:
            a=len(valor)
            for separa in separador1: #separa variable de typo serie
                if nombreB.find(separa)>=0:
                   b=nombreB.index(separa)
                   sheetc.cell(i, 3).value=valor[0:b].strip()
                   band=1
                   break
            if band != 1:
                for separa in separador0: #separa variable de typo serie
                    if nombreB.find(separa)>=0:
                       b=nombreB.index(separa)
                       c= len(separa)
                       if a-(b+c)<2:
                           sheetc.cell(i, 3).value=valor[0:b].strip()
                           band=1
                           break  
                if band != 1:
                    sheetc.cell(i, 3).value=valor  
        i=i+1
        band=0
        valor=sheetc.cell(i, 2).value
        if valor  != None:
            valor=valor.strip()
        sheetc.cell(i, 2).value=valor
        #if i==3039:
        print (i)
    excel_document_c.save('Base_Contribuyente_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    for fila in revisarnp[0]:
        nombrea=revisarnp[1][revisarnp[0].index(fila)]
        nombrea=nombrea.split('|')
        nombrea1=nombrea[0]
        nombrea2=nombrea[1].split()
        nombreaa2=""
        nombrea3=nombrea[2].split()
        for n2 in range(len(nombrea2)):
            nombreaa2= nombreaa2 + " " + nombrea2[n2]
            nombreaa2=nombreaa2.strip()
            nombreaa3=""
            for n3 in range(len(nombrea3)):
                if n2!= len(nombrea2)-1 or n3!=len(nombrea3)-1:
                    nombreaa3= nombreaa3 + " " + nombrea3[n3]
                    nombreaa3=nombreaa3.strip()
                    sheetc.cell(i, 1).value=sheetc.cell(fila, 1).value
                    sheetc.cell(i, 2).value= nombrea1 + " " + nombreaa2 + " " + nombreaa3
                    sheetc.cell(i, 3).value= nombrea1 + "|" + nombreaa2 + "|" + nombreaa3
                    sheetc.cell(i, 4).value=sheetc.cell(fila, 4).value
                    i=i+1
    print(revisarnp)
    excel_document_c.save('Base_Contribuyente_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    excel_document_c.close()
    py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================

#=====> Manejo de generacion de carpetas <=======
#=============================================================================
# Generar Caarpeta General:
# Genera la carpeta general, donde se  almacenal lass busquedas
#==============================================================================
def capetaG():#Crea la carpeta global de busqueda
    global nCarpetaP #Declara como variable global el nombre de la carpeta principal
    fechaA=datetime.datetime.now()#()#Obtiene Fecha y Hora Actual
    nCarpetaP='Resultado_' + getuser() + '_' + fechaA.strftime('%d_%m_%Y_%H_%M_%S')#Nombre de la Carpeta
    try:
        os.mkdir(nCarpetaP) #Crea la Carpeta
    except OSError as e:
        print (e.args)
    return nCarpetaP
#==============================================================================
# Generar Caarpeta General - Alterno:
# Genera la carpeta general, donde se  almacenal lass busquedas
#==============================================================================
def capetaG_A(nCarpetaP1):#Crea la carpeta global de busqueda
    nCarpetaP=nCarpetaP1 
    try:
        os.mkdir(nCarpetaP) #Crea la Carpeta
    except OSError as e:
        print("Error capetaG_A")
        print (e.args)
    return nCarpetaP
#==============================================================================
# Genera Sub Ccarpetas:
# Genera sub carpetas donde se almacenara las partidas
#==============================================================================    
def carpetaSub(nCarpetaS):
    try:
        os.mkdir(nCarpetaS) #Crea la subCarpeta
    except OSError as e:
        print (e.args)
#================================================================================
# Procedimiento para Mover Archivo:
# Traslada archivos de la Carpeta Descargas a la carpeta creado para cada partida
#================================================================================
def moverArchivo(rutaDest,valoresE02):
    #rutaDest=str(os.getcwd()) + '\Destino'
    a=len(valoresE02)
    rutaOrig=str(os.getcwd()) # Ruta donde se ejecuta el aplicativo
    rutaOrig=rutaOrig + '\Descargas' # Ruta de descargas dentro de la carpeta del aplicativo
    archivosT01=os.listdir(rutaOrig) # Listar los archivos que se encuentar en la carpeta descargas
    valoresE02[a-2]=valoresE02[a-2] + '|' + str(len(archivosT01)) #Indica  el numero de archivos en contrados en carpeta descargas
    for arch in archivosT01:
        shutil.move(rutaOrig +'\\' + arch,rutaDest + '\\' + arch) #Mover el archivo
#================================================================================
# Procedimiento para Eliminar Archivo:
# Borrar achivos de la carpeta descargas
#==============================================================================   
def removerArchivo():
    rutaOrig=str(os.getcwd())
    rutaOrig=rutaOrig + '\Descargas'
    archivosT01=os.listdir(rutaOrig)
    for arch in archivosT01:
        os.remove(rutaOrig +'\\' + arch)   
#==============================================================================
#==============================================================================
# Procedimiento para Eliminar Archivo:
# Borrar achivos de la carpeta descargas
#==============================================================================
def removerArchivo1(carpeta_r):
    #rutaOrig=str(os.getcwd())
    rutaOrig=carpeta_r
    archivosT01=os.listdir(rutaOrig)
    for arch in archivosT01:
        os.remove(rutaOrig +'\\' + arch)   
#==============================================================================
#*********interaccion con browser************
#==============================================================================
# Procedimientod e Inicio de Sesion.
# Se inicia Sesion  se cargan planos para el usuario y contraseña
#==============================================================================
def IniciarSesion(contIni):
    #driver.get("https://enlinea.sunarp.gob.pe/")#https://enlinea.sunarp.gob.pe/") #ventana para usuario y clave intranet
    contIni=contIni+1
    driver.refresh()
    time.sleep(cte.TIME_3)
    try:
        path_usuario=r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
        abspath_usuario=os.path.abspath(path_usuario)#Ruta del archivo txt   
        with open (abspath_usuario) as Usuario: # USUARIO   
            for line in Usuario:  #Leyedo usuario intranet
                #driver.find_element_by_name('username').send_keys(line) #Ingreso de usuario
                WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'username'))).send_keys(line) #Ingreso de usuario
        time.sleep(cte.TIME_3)#esperando
        path_clave=r'.\clave.txt'#Archivo tipo txt donde se encuentra la clave
        abspath_clave=os.path.abspath(path_clave)#Ruta donde se encuentra la clave
        with open (abspath_clave) as Clave: #abre el archivo CLAVE
            for line2 in Clave:    #Leyendo la clave
                #driver.find_element_by_name('password').send_keys(line2) #Ingreso de clave
                WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'password'))).send_keys(line2) #Ingreso de clave
        #time.sleep(cte.TIME_3) #Espera        
        #driver.find_element_by_xpath('/html/body/div[1]/form/table/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr[4]/td/a').click() #boton inicio sesion
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/form/table/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr[4]/td/a'))).click() #boton inicio sesion
        time.sleep(cte.TIME_3) #Espera
        original_window = driver.current_window_handle # Almacena el ID de la ventana original
        for window_handle in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
            if window_handle != original_window:
                driver.switch_to.window(window_handle)
                driver.close() #Cierra Ventana emergente
                break
        driver.switch_to.window(original_window) #Vuelve a la ventana Original
        time.sleep(cte.TIME_3) #Espera 
    except:
        if contIni<2:
            driver.refresh()
            IniciarSesion(contIni)
        else:
            py.alert("Error al iniciar, comunicarse con soporte - def IniciarSesion",timeout=cte.AVISO1)#Mensaje de Inicio de sesion
            CerrarGoogleChrome()
#==============================================================================
# Procedimiento Cerrar Sesión.
#==============================================================================
def CerrarSesion(original_window): #Cierra la sesion activa de SUNARP
    try:
        for window_handle1 in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
            if window_handle1 != original_window:
                driver.switch_to.window(window_handle1)
                driver.maximize_window() #maximizar ventana
                driver.close() #Cierra Ventana
        driver.switch_to.window(original_window) #Vuelve a la ventana Original
        driver.switch_to.default_content() #Regresa al frame principal.
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # frame de opciones de la parte izquierda
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//*[@href='/sunarpweb/pages/acceso/salidaTAMTest.faces']"))).click() #click en cerra sesion
    except:
        print("Error al cerrar Sesion-- linea 162")
        CerrarGoogleChrome()
        IniciarGoogleChrome()#Iniciar el Chrome     
    
#=============================================================================

#=============================================================================
# Proceso para separar nombre de personas en en una lista de 3 columnas
#
#=============================================================================
def nombrePropio(valornommbre):
    aN1=[]
    apNombre=[["","",""],[0]]
    i=0
    valornommbre=valornommbre.strip()
    valornommbre = valornommbre.replace(".", " ")
    valornommbre = valornommbre.replace("  ", " ")
    aN1 = valornommbre.split(" ")
    l1 = len(aN1)
    j = 0
    k=0
    if l1 >2: # l1 >= 2:
        while i<l1:
            if j==2:
                k=k+1
            if NACompuesto(aN1[i])[0]:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
            else:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j==1:
                        if NACompuesto(aN1[i + 1])[0]:
                            j=j
                            if NACompuesto(aN1[i+1])[1]:
                                apNombre[1][0]=1
                        else:
                            j = j + 1
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j == 1:
                        if i+1<l1:
                            if NACompuesto(aN1[i + 1])[0]:
                                j=j
                                if NACompuesto(aN1[i])[1]:
                                    apNombre[1][0]=1
                            else:
                                j = j + 1
            i=i+1
        if k>1:
            apNombre[1][0]=1
    elif l1 == 2:
        apNombre[0][0] = aN1[0]
        apNombre[0][2] = aN1[1]
        
    return apNombre
#=============================================================================

#=============================================================================
# Funcion auxiliar que verifica si los componentes del nombre son parte de un 
# apellido compuesto
#=============================================================================
def NACompuesto(texto):
    rpt_nacompuesto=[]
    try:
        arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "KU", "MC", "R", "XU", 
               "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
               "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
               "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        # arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "SU", "KU", "MC", "R", "XU", 
        #        "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
        #        "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
        #        "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        arr1=["DE","VDA"]
        resultadol=arr.index(texto)
        rpt_nacompuesto.append(bool(1))
        try:
            resultadol=arr1.index(texto)
            rpt_nacompuesto.append(bool(1))
            return rpt_nacompuesto
        except:
            rpt_nacompuesto.append(bool(0))
            return rpt_nacompuesto
    except:
        rpt_nacompuesto.append(bool(0))
        rpt_nacompuesto.append(bool(0))
        return rpt_nacompuesto

#==============================================================================
# Procedimiento que genera el estado de la descarga, comparando con el numero de 
# partida si tubuera el archivo base
#==============================================================================
def VerificarC2(valor,razonSocialBE,sheetD1,sheetD2,valorEv):
    verificar=[]
    verificar.append(bool(0))
    verificar.append(0)
    
    if str(areaR1)=='1':
        #if valorEv[1].value!='LIMA': #verifica que la propiedad esta inscrita en oficina de Lima
        if valorEv[0].value!=zonaR and zonaR!='ZR00': #verifica que la propiedad esta inscrita en oficina seleccionado
            verificar[0]= bool(0)
            return verificar
        elif (valor[3].value =="PERSONA NATURAL CON NEGOCIO" or valor[3].value
              =="PERSONA NATURAL SIN NEGOCIO" or valor[3].value ==
           "SUCESION INDIVISA SIN NEGOCIO"):
            nombreBE=razonSocialBE.replace(",","")
            nombreAB=valor[2].value
            nombreAB=nombreAB.replace("|"," ")
            if nombreBE==nombreAB:
                verificar[0]= bool(1)
                return verificar
    elif str(areaR1)=='3':
        if valorEv[2].value==valor[4].value:
            verificar[0]=bool(1)
            verificar[1]=1
            return verificar
    try:
        nombre_r=sheetD1[sheetD1.Tipo_Contribuyente==valor[3].value].Valor_Referencia
        a=len(nombre_r)
        i=0
        verificar[0]= bool(0)
        band= bool(0)
        l2=len(valor[2].value)
        l=len(valor[1].value)
        print("===> " + str(a))
        while i<a:
            print(str(i))
            if razonSocialBE.find(nombre_r.iloc[i])>=0:
                b=razonSocialBE.index(nombre_r.iloc[i])
                l3=len(nombre_r.iloc[i])
                l1=len(razonSocialBE)
                if l1-b-l3<=3:
                    verificar[0]= bool(1)
                    return verificar
                    break
            i=i+1
        if valor[1].value== razonSocialBE:
            print(valor[1].value)
            print(valor[2].value)
            verificar[0]= bool(1)
            return verificar
        elif valor[2].value== razonSocialBE:
            print(valor[2].value)
            print(valor[1].value)
            verificar[0]= bool(1)
            return verificar
        return verificar    
    except:
        py.alert("Error en la Validación VerificarC2---linea 467",timeout=458000)#Mensaje de error
        print("Error en la ValidaciónC2---linea 468")
#==============================================================================

#==============================================================================
# Procedimiento de comparación de cadena.
# Verifica que la Razon Social ha Descargar  se ha el esperado
#==============================================================================
def VerificarC1(valor,razonSocialBE,sheetD1,sheetD2):
    try:
        nombre_r=sheetD1[sheetD1.Tipo_Contribuyente==valor[3].value].Valor_Referencia
        a=len(nombre_r)
        i=0
        verificar= bool(0)
        band= bool(0)
        l2=len(valor[2].value)
        l=len(valor[1].value)
        print("===> " + str(a))
        while i<a:
            print(str(i))
            if razonSocialBE.find(nombre_r.iloc[i])>=0:
                b=razonSocialBE.index(nombre_r.iloc[i])
                l3=len(nombre_r.iloc[i])
                l1=len(razonSocialBE)
                if l1-b-l3<=3:
                    verificar= bool(1)
                    return verificar
                    break
            i=i+1
        if valor[1].value== razonSocialBE:
            print(valor[1].value)
            print(valor[2].value)
            verificar= bool(1)
            return verificar
        elif valor[2].value== razonSocialBE:
            print(valor[2].value)
            print(valor[1].value)
            verificar= bool(1)
            return verificar
        return verificar    
    except:
        py.alert("Error en la Validación VerificarC1---linea 569",timeout=458000)#Mensaje de error
        print("Error en la Validación VerificarC1---linea 569")
#==============================================================================
#==============================================================================
# Procedimiento de comparación de cadena.
# Verifica que la Razon Social ha Descargar  se ha el esperado
#==============================================================================
def VerificarC(razonSocialB,razonSocialBE):
    tipoSocial=["SOCIEDAD ANONIMA", "S.A.C. (EN LIQUIDACION)", "SOCIEDAD ANONIMA CERRADA",  
                "SOCIEDAD COMERCIAL DE RESPONSABILIDAD LIMITADA", " S.R.LTDA."," SRLTDA", " E.I.R.L.","E.I.R.L.",
                "EMPRESA INDIVIDUAL DE RESPOSABILIDAD LIMITADA", "EMPRESA INDIVIDUAL DE RESPONSABILIDAD LIMITADA",
                "EMPRESA INDIVIDUAL DE RESPONSABILI DAD LIMITADA"," EIRL", " E.I.R.L.", " SRL.", " S.R.L",  " SRL" , " EIRL",
                " E I R L", "  E.I.R.L", " E.I.R.L", "E.I.R.L."," S.A.C", " S.A.C."," S A LTDA", " S R L"," S.R.L.",
                 " SAC","SA.","S.A."," S A", " S.A", " S.A.", " SA"]
    razonS01=str(razonSocialBE)
    verificar= bool(0)
    band= bool(0)
    if razonS01.find(razonSocialB)>=0:
        a=razonS01.index(razonSocialB)
        l1=len(razonS01)
        l2=len(razonSocialB)
        if l1==l2:
            verificar= bool(1)
            return verificar
        else:
            for tipoS in tipoSocial:
                if razonS01.find(tipoS)>=0:
                    if l1-(l2+len(tipoS))<=3:
                        verificar= bool(1)
                        return verificar
                        break
            return verificar
    else:
        return verificar
 
#=============================================================================

#==============================================================================
# Procedimiento de busqueda por Razon Social en Area Registral, segun Propiedad
# Inmueble Predial
#==============================================================================
def BuscarSUNARP009(razonSocialB,sheet2,arear):
    try: # Bloque 1
        sheet2.cell(row=2, column=3).value="Inicio - Bloque1 - BuscarSUNARP009"
        sheet2.cell(row=3, column=3).value=razonSocialB
        nombrepn=razonSocialB.split("|")
        auxpn=len(nombrepn)
        valoresE01=["0"] # Variable de retorno
        removerArchivo() #Limpiar la carpeta descargas
        print("Inicia Seción en SUNARP-Buscar SUNARP009")
        #py.alert("Iniciando Sesion ",timeout=cte.AVISO2) #Mensaje de Inicio de sesion
        IniciarSesion(0)#Iniciar Sesion
        time.sleep(cte.TIME_1)#Espera
        original_window = driver.current_window_handle
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # Frame de opciones de la parte izquierda
        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div/div/div[1]/div/div/table/tbody/tr/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td[2]/a'))).click() #boton Búsqueda por nombre del titular registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//a[@href='/sunarpweb/pages/publicidadSimple/indice/busquedaIndicePartida.faces']"))).click() #boton Búsqueda por nombre del titular registral
        time.sleep(cte.TIME_2) #Espera
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/table/tbody/tr[3]/td/form/span[2]/span/div/div/table/tbody/tr/td/table/tbody/tr/td[2]/button[2]'))).click() #boton Búsqueda total -->|
        time.sleep(cte.TIME_2) # Por parpadeo de la pantalla
        select = Select(driver.find_element_by_id('frmIndicePartida:menuIndicePartida'))#Seleccionar objeto Area registral
        select.select_by_value(str(arear))#Selecciona  el Area Registral #select.select_by_value('1')#Selecciona persona juridica opcion 3
        if auxpn==1:
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtRazSocialProp'))).send_keys(razonSocialB)
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:j_id1738699387_60d533'))).click() #boton Búsqueda 
        elif auxpn==3:
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtApPaternoProp'))).send_keys(nombrepn[0])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtApMaternoProp'))).send_keys(nombrepn[1])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtNombresProp'))).send_keys(nombrepn[2])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:j_id1738699387_60d4e0'))).click() #boton Búsqueda 
        time.sleep(cte.TIME_5) #Espera
        try: # Bloque 2
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP009"
            print("Busqueda de contribuyente:" + razonSocialB + "---->")
            contriNroTx=WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID,'fBusqSPE'))).text
            if len(contriNroTx)==20:
                contriNroT=contriNroTx[10:11] #Numero de pagina
            else:
                contriNroT=contriNroTx[10:len(contriNroTx)-10]#Numero de pagina
            contriNro=float(contriNroT) #Numero de pagina
            if contriNro ==0 :
                valoresE01[0]="NO SE ENCONTRÓ COINCIDENCIAS" #Variable de Resultado descargado 
                CerrarSesion(original_window)# Cerrar Sesion
                return valoresE01
            table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP009"
            print("Descarga de lista de contribuyente:" + razonSocialB + ", tiene " + contriNroT +
                  " coincidencias---->")
            a=len(rows)#Cantidad de filas de resultado
            j=0#variable de control de fila de tabla de resultado
            valoresE01[0]="SE ENCONTRÓ COINCIDENCIAS" + '|'+ contriNroT #Variable de Resultado descargado
            #valoresE01.append('Registro Público|Oficina Registral|Partida|Ficha|Tomo|Folio|Razón Social|Ruc')
            valoresE01.append('Registro Público|Oficina Registral|Partida|Placa|Propietario|Estado Titular|Estado Vehículo|Ver Detalle|Ver Asientos')
            d=1
            b=contriNro//15 + 1 # Indica la cantidad de pantallas a recorrer // obtiene cociente
            while d<=b: #Recorre pantallas 
                while j < a:
                    try:#Captura las columnas de las filas
                        cols = rows[j].find_elements_by_tag_name('td') # Capturamos las columnas de la fila de la tabla de resultados
                        #b=len(cols)#Cantidad de columnas
                        c=0#indicador de columna
                        try: #Inicio de lectura de columna
                            for col in cols:
                                if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                    valoresE01.append(col.text)#Nueva entrada al arreglo
                                else:
                                    #if c<15:#Verifica que no se ha el button
                                    if c==9 and auxpn==3:
                                        valoresE01[(d-1)*15+j+2]=valoresE01[(d-1)*15+j+2] + '|' 
                                    valoresE01[(d-1)*15+j+2]=valoresE01[(d-1)*15+j+2] + '|' + col.text #Alamcena en  el arreglo los valores de la columna
                                c=c+1
                        except:
                            py.alert("Error en lectura - Columna", timeout=cte.AVISO2)
                            print("Error en el recorrido de Columna:" + str(c))
                    except:
                        py.alert("Error al capturar datos de columna", timeout=cte.AVISO2)
                        print("Error al capturar Columna" )
                    j=j+1
                if b==1:
                    CerrarSesion(original_window)# Cerrar Sesion
                    return valoresE01
                else:
                    #inicio de bloque2
                    try:
                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//div[@id='frmResultadoPJ:tblResulPJ_paginator_bottom']/span[5]"))).click()#pagina siguiente
                        time.sleep(cte.TIME_2) #Espera
                        table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
                        table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
                        table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
                        tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
                        rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
                        a=len(rows)#Cantidad de filas de resultado
                        j=0#variable de control de fila de tabla de resultado
                        time.sleep(cte.TIME_1) #Espera
                    except:
                        valoresE01[0]="0"
                        CerrarSesion(original_window)# Cerrar 
                        sheet2.cell(row=2, column=3).value="Error  - Bloque2 - BuscarSUNARP009"
                        print("Error al cargar pagina siguiente" + str(d) + " SUNARP-BuscarSUNARP009")
                        #py.alert("Error en Bloque2 - SUNARP002",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
                        return valoresE01
                d=d+1
            CerrarSesion(original_window)# Cerrar Sesion
            if len(valoresE01)!=contriNro+2:
                valoresE01[0]="0"
            return valoresE01
        except:
            mrpta=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.CLASS_NAME,'ui-messages-error-summary'))).text
            print(mrpta)
            valoresE01[0]="NO SE ENCONTRÓ COINCIDENCIAS" #Variable de Resultado descargado 
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE01
    except:
        valoresE01[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion
        py.alert("Error en Bloque1 - SUNARP009",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
        return valoresE01
#=============================================================================    


#==============================================================================
# Procedimiento BuscarSUNARP008: Descarga partidas registrales , por numero de 
# partidad, con parametros de paginas a descargar y area registral
#==============================================================================
def BuscarSUNARP008(npartida,ofreg_aux,rutaS1,ind,pag_rp,pag_c,celda,arear):
    try: 
        pag_f=pag_c-1
        print("Inicio bloque 1-BuscarSUNARP008; Número de Partida " + str(npartida)+" ;Paginas  ")
        print(pag_rp)
        removerArchivo()#Limpiar la carpeta descargas
        valoresE02=["Detalle de la Partida"]#Variable de Resultado de detalle de la partida registral
        IniciarSesion(0)#Iniciar Sesion
        ofreg=valor_ofregistrales(ofreg_aux)#Obtiene Oficina Registral
        time.sleep(cte.TIME_2)#Espera
        original_window = driver.current_window_handle # captura id de ventana principal
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # frame de opciones de la parte izquierda
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//a[@href='/sunarpweb/pages/publicidadSimple/directa/busquedaPartidaDirecta.faces']"))).click() #boton Búsqueda por nombre del titular registral
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        select_or=Select(driver.find_element_by_id('frmPartidaDirecta:cmbOficina')) # carga el combobox ce Oficina registral
        select_or.select_by_value(ofreg)#Selecciona la Oficina Regitral
        time.sleep(cte.TIME_1)
        select = Select(driver.find_element_by_id('frmPartidaDirecta:j_id545962668_58eaf6a7'))#Seleccionar Seleccionar Area registral
        select.select_by_value(str(arear))#Selecciona  el Area Registral
        time.sleep(cte.TIME_5) #Espera
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:radioPartida:1']"))).click() #Activa boton de partida registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:txtPartida']"))).send_keys(npartida) #Ingresa numero de partida en el cuadro de texto
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//button[@id='frmPartidaDirecta:btnBuscar']"))).click() #Preciona el boton Buscar
        time.sleep(cte.TIME_5) #Espera
        aux_cargar=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//div[@id='fBusqSPE']"))) # Verifica que se vizualiza la tabla de resultado de busqueda
        print("Fin de Bloque 1-BuscarSUNARP008 =====>")           
        # Fin de bloque 1
        try:
            # Inicio de bloque 2
            original_window = driver.current_window_handle # Almacena el ID de la ventana original"
            print("Inicio de Bloque 2-BuscarSUNARP008-Tabla de resultado de Busqueda =====>")
            table = driver.find_elements_by_class_name('contentClass') # Obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[4].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            a=len(rows)#Cantidad de filas de resultado
            # Fin de Bloque 2
            print("Fin de Bloque 2-BuscarSUNARP008 =====>")
            try:#Captura las columnas de las filas
                # Inicio de Bloque 3
                print("Inicio de Bloque 3-BuscarSUNARP008; cantidad de filas " + str(a) + " =====>")
                cols = rows[ind].find_elements_by_tag_name('td') #Capturamos las columnas de la fila de la tabla de resultados
                botonB=rows[ind].find_elements_by_tag_name('button') #Obtiene el boton de lupa de la fila a descargar
                botonB[0].click() #Click en el boton de lupa
                time.sleep(cte.TIME_5)#Espera a que cargue pagina                
                try:#Verifica si existe mensaje  para confirmación
                    #Revisar https://www.it-swarm-es.com/es/python/compruebe-si-existe-alguna-alerta-utilizando-selenium-con-python/1042134131/
                    WebDriverWait(driver, 3).until(EC.alert_is_present()).accept() #, 'Timed out waiting for PA creation ' + 'confirmation popup to appear.')
                    time.sleep(cte.TIME_1) #Espera
                except:
                    print("No existe alertas-bloque3")
                    #py.alert("No existe alertas",timeout=800)
                carpetaSub(rutaS1)#Crea sub carpeta
                for window_handle in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)#Coloca el foco en la nueva venta
                        driver.maximize_window() #maximizar ventana
                        try:
                            print("bonton de primera pag 1")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[4]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            print("bonton de primera pag 2")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[5]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        paginaNro=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[2]/td/font/b').text # cantidad de Paginas
                        pNro=int(paginaNro[12:len(paginaNro)])#Numero de  paginas
                        # if pag_f!=pNro and pag_f>pNro:
                        #     pag_f=pNro
                        # pag_v=pag_f-pag_i+1    
                        try:#Verifica si inicio en 1                            
                            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490c86']"))).click() # Pagina siguiente
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            py.alert("Se cargo en pagina 1",timeout=800)
                        if int(pag_rp[0]) ==1:
                            tablaContP=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table')#ubica la tabla de detalle de la partida
                            rows1 = tablaContP.find_elements_by_tag_name('tr')#Obtine la cantidad de filas
                            k=0
                            for row in rows1:
                                try:#Capturando alguna incidencia con el excel en su hoja de trabajo
                                    cols = row.find_elements_by_tag_name('td') # se puede indexar con 0, 1, 2... depende del tamanio de la tabla y la columna que queramos
                                    c=0#indicador de columna
                                    for col in cols:
                                        if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                            valoresE02.append(col.text)#Nueva entrada
                                        else:
                                            valoresE02[k+1]=valoresE02[k+1] + '|' + col.text                                            
                                        c=c+1
                                except:
                                    py.alert("Error al leer detalle de partida", timeout=cte.AVISO2) 
                                k=k+1
                            valoresE02.append(str(pNro))
                        else:
                            k=0
                            valoresE02.append(str(pag_rp[0])) 
                        lista_pnd=""
                        cont_dp=0
                        try: #imicio de bloque 4
                            original_window_1 = driver.current_window_handle # Almacena el ID de  la ventana de partidas Registrales
                            i=0
                            vimagenp=""
                            vimagenps=""
                            print("Inicio de impresión, cantidad de Paginas: " + str(pNro) + " , Imprime Pagina del " + str(pag_rp[i]) + " al " + str(pag_rp[pag_f]) + " =======>")
                            #i=pag_i
                            band_dp=1
                            while i<=pag_f: # Inicio de bucle de descarga de partida registral
                                if band_dp!=0 and i!=0:
                                    if lista_pnd=="":
                                        lista_pnd=lista_pnd + str(pag_rp[i-1])
                                    else:
                                        lista_pnd=lista_pnd + "|" + str(pag_rp[i-1])
                                band_pd=1
                                print("Impresión de Pagina Nro. " + str(pag_rp[i]))
                                if int(pag_rp[i])>1:
                                    time.sleep(cte.TIME_2) #
                                    btonS1=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490cc7']")))
                                    driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(pag_rp[i]) + ")][1].click()')", btonS1)
                                    driver.execute_script("arguments[0].click()", btonS1)
                                    time.sleep(cte.TIME_3) #Espera
                                bandimg=0
                                while bandimg<=2: #Verifica que no se cargue imagen duplicado o se quede  pegado pagina anterior
                                    try:
                                        imagenp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='frmVisualizar:imagenContent']"))) #Verifica id de imagen de hoja
                                        if vimagenps== imagenp.get_attribute("src"):
                                            print("Refresca_528 Pagina Nro" + str(i))
                                            btnpag1=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(pag_rp[i]) + ")][1].click()')", btnpag1)
                                            driver.execute_script("arguments[0].click()", btnpag1)
                                            valor_btn1=btnpag1.get_attribute("onclick")
                                            driver.refresh()
                                            btnpag2=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn2=btnpag2.get_attribute("onclick")
                                            driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(pag_rp[i]) + ")][1].click()')", btnpag2)
                                            driver.execute_script("arguments[0].click();", btnpag2)
                                            time.sleep(cte.TIME_3) #Espera
                                            btnpag3=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn3=btnpag3.get_attribute("onclick")
                                            bandimg=bandimg+1
                                            if bandimg>2:
                                                valoresE02[0]="0"
                                                CerrarSesion(original_window)# Cerrar Sesion
                                                return valoresE02 
                                        else:
                                            vimagenps=imagenp.get_attribute("src")
                                            vimagenp=vimagenp + imagenp.get_attribute("src") + "|"
                                            break
                                    except:
                                        driver.refresh()
                                        btnpag1=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                        driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(pag_rp[i]) + ")][1].click()')", btnpag1)
                                        driver.execute_script("arguments[0].click()", btnpag1)
                                        print("Refresca_555 Pagina Nro" + str(i))
                                        bandimg=bandimg+1
                                        
                                if bandimg<=2:         
                                    try:
                                        print("Enlace de impresion Pagina Nro " + str(pag_rp[i]))
                                        driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a').click() # Enlace de impresión
                                        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                    except:
                                        driver.refresh()
                                        print("Enlace de impresion Refesh Pagina Nro " + str(pag_rp[i]))
                                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                    time.sleep(cte.TIME_3) #Espera
                                    try:#Verificar Alerta Para 
                                        alert = driver.switch_to_alert()
                                        mensaje=alert.text
                                        print (str(mensaje))
                                        valoresE02[k+1]=valoresE02[k+1] + '|' + str(pag_rp[i]) + str(mensaje)
                                        alert.accept()
                                        time.sleep(cte.TIME_2) #Espera
                                    except:
                                        valoresE02[k+1]=valoresE02[k+1] + '|' + str(pag_rp[i]) + '-Ok'
                                        #py.alert("Se ejecutara Impresion",timeout=200)
                                        print ("impresion")
                                    print("Web de impresion Pagina Nro. " + str(pag_rp[i]))
                                    for window_handle1 in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                                        if window_handle1 != original_window and window_handle1 != original_window_1:
                                            print("Web encontrada impresion Pagina Nro. " + str(pag_rp[i]))
                                            driver.switch_to.window(window_handle1)
                                            time.sleep(cte.TIME_1) #Espera
                                            driver.maximize_window() #maximizar ventana
                                            time.sleep(cte.TIME_3) #Espera
                                            img_imp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='j_id564306970_21a2a458:img']"))) #Verifica id de imagen de hoja
                                            if inicio_diver==0:
                                                pdf = driver.execute_cdp_cmd("Page.printToPDF", {"printBackground": True ,"pageRanges": '1' })
                                                if pdf !=None:
                                                    print("Generación de impresión Pagina Nro" + str(pag_rp[i]))
                                                    with open(os.getcwd() +'\Descargas\Pagina' + str(pag_rp[i])+'.pdf', "wb") as f:
                                                        f.write(base64.b64decode(pdf['data']))
                                                    band_dp=0
                                                    cont_dp=cont_dp+1
                                                    print("fin de impresion Pagina Nro" + str(pag_rp[i]))
                                                    f=None
                                                else:
                                                    print("Error en generar PDF impresion Pagina Nro" + str(pag_rp[i]))
                                                pdf=None
                                            else:
                                                print("Impresion impresion Pagina Nro" + str(pag_rp[i]))
                                                try:
                                                    driver.execute_script('document.title="{}";'.format('Pagina' + str(pag_rp[i])))#Indica el numero de pagina
                                                    driver.execute_script('window.print();')
                                                    print("fin de impresion Pagina Nro" + str(pag_rp[i]))
                                                    band_dp=0
                                                    cont_dp=cont_dp+1
                                                except:
                                                    print("Error en generar PDF impresion Pagina Nro" + str(pag_rp[i]))
                                            driver.close() #Cierra Ventana emergente
                                            time.sleep(cte.TIME_3) #Espera
                                            driver.switch_to.window(original_window_1) #Vuelve a la ventana Original
                                            time.sleep(cte.TIME_3) #Espera
                                            break
                                i=i+1
                            if band_dp!=0 and i!=0:
                                    if lista_pnd=="":
                                        lista_pnd=lista_pnd + str(pag_rp[i-1])
                                    else:
                                        lista_pnd=lista_pnd + "|" + str(pag_rp[i-1])
                            valoresE02.append(lista_pnd)
                            celda.value=vimagenp
                            driver.close() #Cierra Ventana 
                            driver.switch_to.window(original_window) #Vuelve a la ventana Original Principal
                            moverArchivo(rutaS1,valoresE02)#Mueve archivo descargado  a la carpeta de la aprtida 
                            CerrarSesion(original_window)# Cerrar Sesion
                            return valoresE02
                            #break
                        except:
                            if cont_dp<(pag_f/2):
                                valoresE02[0]="0"
                                CerrarSesion(original_window)# Cerrar Sesion
                                py.alert('Error bloque 4',timeout=cte.AVISO1)
                                return valoresE02 
                            else:
                                celda.value=vimagenp
                                driver.close() #Cierra Ventana 
                                driver.switch_to.window(original_window) #Vuelve a la ventana Original Principal
                                moverArchivo(rutaS1,valoresE02)#Mueve archivo descargado  a la carpeta de la aprtida 
                                CerrarSesion(original_window)# Cerrar Sesion
                                return valoresE02
                                
            except:
                valoresE02[0]="0"
                CerrarSesion(original_window)# Cerrar Sesion
                py.alert("Error en bloque 3", timeout=cte.AVISO1)
                return valoresE02
        except:
            py.alert("Error en Bloque 2", timeout=cte.AVISO1)
            valoresE02[0]="0"
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE02
    except:
        valoresE02[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion)
        py.alert("Error en bloque N° 1", timeout=cte.AVISO1)
        return valoresE02
#==============================================================================


#==============================================================================
# Procedimiento BuscarSUNARP007: Descarga partidas registrales , por numero de 
# partidad, con parametros de inicio, cantidad y area registral
#==============================================================================
def BuscarSUNARP007(npartida,ofreg_aux,rutaS1,ind,pag_i,pag_c,celda,arear):
    try: 
        pag_f=pag_i + pag_c-1
        print("Inicio bloque 1-BuscarSUNARP007; Número de Partida" + str(npartida)+" ;Pagina del " + str(pag_i) + " al " +  str(pag_f))
        removerArchivo()#Limpiar la carpeta descargas
        valoresE02=["Detalle de la Partida"]#Variable de Resultado de detalle de la partida registral
        IniciarSesion(0)#Iniciar Sesion
        ofreg=valor_ofregistrales(ofreg_aux)#Obtiene Oficina Registral
        time.sleep(cte.TIME_2)#Espera
        original_window = driver.current_window_handle # captura id de ventana principal
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # frame de opciones de la parte izquierda
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//a[@href='/sunarpweb/pages/publicidadSimple/directa/busquedaPartidaDirecta.faces']"))).click() #boton Búsqueda por nombre del titular registral
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        select_or=Select(driver.find_element_by_id('frmPartidaDirecta:cmbOficina')) # carga el combobox ce Oficina registral
        select_or.select_by_value(ofreg)#Selecciona la Oficina Regitral
        time.sleep(cte.TIME_1)
        select = Select(driver.find_element_by_id('frmPartidaDirecta:j_id545962668_58eaf6a7'))#Seleccionar Seleccionar Area registral
        select.select_by_value(str(arear))#Selecciona  el Area Registral
        time.sleep(cte.TIME_5) #Espera
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:radioPartida:1']"))).click() #Activa boton de partida registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:txtPartida']"))).send_keys(npartida) #Ingresa numero de partida en el cuadro de texto
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//button[@id='frmPartidaDirecta:btnBuscar']"))).click() #Preciona el boton Buscar
        time.sleep(cte.TIME_5) #Espera
        aux_cargar=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//div[@id='fBusqSPE']"))) # Verifica que se vizualiza la tabla de resultado de busqueda
        print("Fin de Bloque 1-BuscarSUNARP007 =====>")           
        # Fin de bloque 1
        try:
            # Inicio de bloque 2
            original_window = driver.current_window_handle # Almacena el ID de la ventana original"
            print("Inicio de Bloque 2-BuscarSUNARP007-Tabla de resultado de Busqueda =====>")
            table = driver.find_elements_by_class_name('contentClass') # Obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[4].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            a=len(rows)#Cantidad de filas de resultado
            # Fin de Bloque 2
            print("Fin de Bloque 2-BuscarSUNARP007 =====>")
            try:#Captura las columnas de las filas
                # Inicio de Bloque 3
                print("Inicio de Bloque 3-BuscarSUNARP007; cantidad de filas " + str(a) + " =====>")
                cols = rows[ind].find_elements_by_tag_name('td') #Capturamos las columnas de la fila de la tabla de resultados
                botonB=rows[ind].find_elements_by_tag_name('button') #Obtiene el boton de lupa de la fila a descargar
                botonB[0].click() #Click en el boton de lupa
                time.sleep(cte.TIME_5)#Espera a que cargue pagina                
                try:#Verifica si existe mensaje  para confirmación
                    #Revisar https://www.it-swarm-es.com/es/python/compruebe-si-existe-alguna-alerta-utilizando-selenium-con-python/1042134131/
                    WebDriverWait(driver, 3).until(EC.alert_is_present()).accept() #, 'Timed out waiting for PA creation ' + 'confirmation popup to appear.')
                    #alert = driver.switch_to.alert
                    #alert.accept()
                    time.sleep(cte.TIME_1) #Espera
                except:
                    print("No existe alertas-bloque3")
                    #py.alert("No existe alertas",timeout=800)
                carpetaSub(rutaS1)#Crea sub carpeta
                for window_handle in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)#Coloca el foco en la nueva venta
                        driver.maximize_window() #maximizar ventana
                        try:
                            print("bonton de primera pag 1")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[4]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            print("bonton de primera pag 2")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[5]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        paginaNro=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[2]/td/font/b').text # cantidad de Paginas
                        pNro=int(paginaNro[12:len(paginaNro)])#Numero de  paginas
                        if pag_f!=pNro and pag_f>pNro:
                            pag_f=pNro
                        pag_v=pag_f-pag_i+1    
                        try:#Verifica si inicio en 1                            
                            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490c86']"))).click() # Pagina siguiente
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            py.alert("Se cargo en pagina 1",timeout=800)
                        if pag_i ==1:
                            tablaContP=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table')#ubica la tabla de detalle de la partida
                            rows1 = tablaContP.find_elements_by_tag_name('tr')#Obtine la cantidad de filas
                            k=0
                            for row in rows1:
                                try:#Capturando alguna incidencia con el excel en su hoja de trabajo
                                    cols = row.find_elements_by_tag_name('td') # se puede indexar con 0, 1, 2... depende del tamanio de la tabla y la columna que queramos
                                    c=0#indicador de columna
                                    for col in cols:
                                        if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                            valoresE02.append(col.text)#Nueva entrada
                                        else:
                                            valoresE02[k+1]=valoresE02[k+1] + '|' + col.text                                            
                                        c=c+1
                                except:
                                    py.alert("Error al leer detalle de partida", timeout=cte.AVISO2) 
                                k=k+1
                            valoresE02.append(str(pNro))
                        else:
                            k=0
                            valoresE02.append(str(pag_i))
                        #valoresE02.append(str(pNro))  
                        lista_pnd=""
                        cont_dp=0
                        try: #imicio de bloque 4
                            original_window_1 = driver.current_window_handle # Almacena el ID de  la ventana de partidas Registrales
                            #i=1
                            vimagenp=""
                            vimagenps=""
                            print("Inicio de impresión, cantidad de Paginas: " + str(pNro) + " , Imprime Pagina del " + str(pag_i) + " al " + str(pag_f) + " =======>")
                            i=pag_i
                            band_dp=1
                            while i<=pag_f: # Inicio de bucle de descarga de partida registral
                                if band_dp!=0 and i!=pag_i:
                                    if lista_pnd=="":
                                        lista_pnd=lista_pnd + str(i-1)
                                    else:
                                        lista_pnd=lista_pnd + "|" + str(i-1)
                                band_pd=1
                                print("Impresión de Pagina Nro" + str(i))
                                if i>1:
                                    time.sleep(cte.TIME_2) #
                                    btonS1=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490cc7']")))
                                    driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(i) + ")][1].click()')", btonS1)
                                    driver.execute_script("arguments[0].click()", btonS1)
                                    time.sleep(cte.TIME_3) #Espera
                                bandimg=0
                                while bandimg<=2: #Verifica que no se cargue imagen duplicado o se quede  pegado pagina anterior
                                    try:
                                        imagenp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='frmVisualizar:imagenContent']"))) #Verifica id de imagen de hoja
                                        if vimagenps== imagenp.get_attribute("src"):
                                            print("Refresca_528 Pagina Nro" + str(i))
                                            btnpag1=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(i) + ")][1].click()')", btnpag1)
                                            driver.execute_script("arguments[0].click()", btnpag1)
                                            valor_btn1=btnpag1.get_attribute("onclick")
                                            driver.refresh()
                                            btnpag2=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn2=btnpag2.get_attribute("onclick")
                                            driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(i) + ")][1].click()')", btnpag2)
                                            driver.execute_script("arguments[0].click();", btnpag2)
                                            time.sleep(cte.TIME_3) #Espera
                                            btnpag3=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn3=btnpag3.get_attribute("onclick")
                                            bandimg=bandimg+1
                                            if bandimg>2:
                                                valoresE02[0]="0"
                                                CerrarSesion(original_window)# Cerrar Sesion
                                                return valoresE02 
                                        else:
                                            vimagenps=imagenp.get_attribute("src")
                                            vimagenp=vimagenp + imagenp.get_attribute("src") + "|"
                                            break
                                    except:
                                        driver.refresh()
                                        btnpag1=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                        driver.execute_script("arguments[0].setAttribute('onclick','linksVisualizar[buscarPagina("+ str(i) + ")][1].click()')", btnpag1)
                                        driver.execute_script("arguments[0].click()", btnpag1)
                                        print("Refresca_555 Pagina Nro" + str(i))
                                        bandimg=bandimg+1
                                        
                                if bandimg<=2:         
                                    try:
                                        print("Enlace de impresion Pagina Nro" + str(i))
                                        driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a').click() # Enlace de impresión
                                        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                    except:
                                        driver.refresh()
                                        print("Enlace de impresion Refesh Pagina Nro" + str(i))
                                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                    time.sleep(cte.TIME_3) #Espera
                                    try:#Verificar Alerta Para 
                                        alert = driver.switch_to_alert()
                                        mensaje=alert.text
                                        print (str(mensaje))
                                        valoresE02[k+1]=valoresE02[k+1] + '|' + str(mensaje)
                                        alert.accept()
                                        time.sleep(cte.TIME_2) #Espera
                                    except:
                                        valoresE02[k+1]=valoresE02[k+1] + '|' + 'Ok'
                                        #py.alert("Se ejecutara Impresion",timeout=200)
                                        print ("impresion")
                                    print("Web de impresion Pagina Nro" + str(i))
                                    for window_handle1 in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                                        if window_handle1 != original_window and window_handle1 != original_window_1:
                                            print("Web encontrada impresion Pagina Nro" + str(i))
                                            driver.switch_to.window(window_handle1)
                                            time.sleep(cte.TIME_1) #Espera
                                            driver.maximize_window() #maximizar ventana
                                            time.sleep(cte.TIME_3) #Espera
                                            img_imp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='j_id564306970_21a2a458:img']"))) #Verifica id de imagen de hoja
                                            if inicio_diver==0:
                                                pdf = driver.execute_cdp_cmd("Page.printToPDF", {"printBackground": True ,"pageRanges": '1' })
                                                if pdf !=None:
                                                    print("Generación de impresión Pagina Nro" + str(i))
                                                    with open(os.getcwd() +'\Descargas\Pagina' + str(i)+'.pdf', "wb") as f:
                                                        f.write(base64.b64decode(pdf['data']))
                                                    band_dp=0
                                                    cont_dp=cont_dp+1
                                                    print("fin de impresion Pagina Nro" + str(i))
                                                    f=None
                                                else:
                                                    print("Error en generar PDF impresion Pagina Nro" + str(i))
                                                pdf=None
                                            else:
                                                print("Impresion impresion Pagina Nro" + str(i))
                                                try:
                                                    driver.execute_script('document.title="{}";'.format('Pagina' + str(i)))#Indica el numero de pagina
                                                    driver.execute_script('window.print();')
                                                    print("fin de impresion Pagina Nro" + str(i))
                                                    band_dp=0
                                                    cont_dp=cont_dp+1
                                                except:
                                                    print("Error en generar PDF impresion Pagina Nro" + str(i))
                                            driver.close() #Cierra Ventana emergente
                                            time.sleep(cte.TIME_3) #Espera
                                            driver.switch_to.window(original_window_1) #Vuelve a la ventana Original
                                            time.sleep(cte.TIME_3) #Espera
                                            break
                                i=i+1
                            if band_dp!=0 and i!=pag_i:
                                    if lista_pnd=="":
                                        lista_pnd=lista_pnd + str(i-1)
                                    else:
                                        lista_pnd=lista_pnd + "|" + str(i-1)
                            valoresE02.append(lista_pnd)
                            celda.value=vimagenp
                            driver.close() #Cierra Ventana 
                            driver.switch_to.window(original_window) #Vuelve a la ventana Original Principal
                            moverArchivo(rutaS1,valoresE02)#Mueve archivo descargado  a la carpeta de la aprtida 
                            CerrarSesion(original_window)# Cerrar Sesion
                            return valoresE02
                            #break
                        except:
                            if cont_dp<(pag_v/2):
                                valoresE02[0]="0"
                                CerrarSesion(original_window)# Cerrar Sesion
                                py.alert('Error bloque 4',timeout=cte.AVISO1)
                                return valoresE02 
                            else:
                                celda.value=vimagenp
                                driver.close() #Cierra Ventana 
                                driver.switch_to.window(original_window) #Vuelve a la ventana Original Principal
                                moverArchivo(rutaS1,valoresE02)#Mueve archivo descargado  a la carpeta de la aprtida 
                                CerrarSesion(original_window)# Cerrar Sesion
                                return valoresE02
                                
            except:
                valoresE02[0]="0"
                CerrarSesion(original_window)# Cerrar Sesion
                py.alert("Error en bloque 3", timeout=cte.AVISO1)
                return valoresE02
        except:
            py.alert("Error en Bloque 2", timeout=cte.AVISO1)
            valoresE02[0]="0"
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE02
    except:
        valoresE02[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion)
        py.alert("Error en bloque N° 1", timeout=cte.AVISO1)
        return valoresE02
#==============================================================================

#==============================================================================
#
#==============================================================================
def BuscarSUNARP006(npartida,ofreg_aux,rutaS1,ind,pag,param_c,celda):
    try:
        #inicio de bloque1
        print("Inicio bloque 1-BuscarSUNARP006; Número de Partida" + str(npartida) )
        removerArchivo()#Limpiar la carpeta descargas
        valoresE02=["Detalle de la Partida"]#Variable de Resultado de detalle de la partida registral
        IniciarSesion(0)#Iniciar Sesion
        ofreg=valor_ofregistrales(ofreg_aux)#Obtiene Oficina Registral
        time.sleep(cte.TIME_2)#Espera
        original_window = driver.current_window_handle # captura id de ventana principal
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # frame de opciones de la parte izquierda
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//a[@href='/sunarpweb/pages/publicidadSimple/directa/busquedaPartidaDirecta.faces']"))).click() #boton Búsqueda por nombre del titular registral
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        select_or=Select(driver.find_element_by_id('frmPartidaDirecta:cmbOficina')) # carga el combobox ce Oficina registral
        select_or.select_by_value(ofreg)#Selecciona la Oficina Regitral
        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/table/tbody/tr[3]/td/form/span[2]/span/div/div/table/tbody/tr/td/table/tbody/tr/td[2]/button[2]'))).click() #boton Búsqueda total -->|
        time.sleep(cte.TIME_1)
        select = Select(driver.find_element_by_id('frmPartidaDirecta:j_id545962668_58eaf6a7'))#Seleccionar Seleccionar Area registral
        select.select_by_value('1')#Selecciona persona juridica
        time.sleep(cte.TIME_5) #Espera
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:radioPartida:1']"))).click() #Activa boton de partida registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='frmPartidaDirecta:txtPartida']"))).send_keys(npartida) #Ingresa numero de partida en el cuadro de texto
        #time.sleep(cte.TIME_1) #Espera
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//button[@id='frmPartidaDirecta:btnBuscar']"))).click() #Preciona el boton Buscar
        time.sleep(cte.TIME_5) #Espera
        aux_cargar=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//div[@id='fBusqSPE']"))) #verifica que se vizualiza la tabla de resultado de busqueda
        
        print("Fin de Bloque 1-BuscarSUNARP006 =====>")           
        # Fin de bloque 1
        try:
            # Inicio de bloque 2
            original_window = driver.current_window_handle # Almacena el ID de la ventana original"
            print("Inicio de Bloque 2-BuscarSUNARP006 =====>")
            table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[4].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            a=len(rows)#Cantidad de filas de resultado
            # Fin de Bloque 2
            print("Fin de Bloque 2-BuscarSUNARP006 =====>")
            try:#Captura las columnas de las filas
                # Inicio de Bloque 3
                print("Inicio de Bloque 3-BuscarSUNARP006; cantidad de filas " + str(a) + " =====>")
                cols = rows[ind].find_elements_by_tag_name('td') #Capturamos las columnas de la fila de la tabla de resultados
                carpetaSub(rutaS1)#Crea sub carpeta
                botonB=rows[ind].find_elements_by_tag_name('button') #Obtiene el boton de lupa de la fila a descargar
                botonB[0].click() #Click en el boton de lupa
                time.sleep(cte.TIME_5)#Espera a que cargue pagina                
                try:#Verifica si existe mensaje  para confirmación
                    #Revisar https://www.it-swarm-es.com/es/python/compruebe-si-existe-alguna-alerta-utilizando-selenium-con-python/1042134131/
                    WebDriverWait(driver, 3).until(EC.alert_is_present()).accept() #, 'Timed out waiting for PA creation ' + 'confirmation popup to appear.')
                    #alert = driver.switch_to.alert
                    #alert.accept()
                    time.sleep(cte.TIME_1) #Espera
                except:
                    print("No existe alertas-bloque3")
                    #py.alert("No existe alertas",timeout=800)
                #original_window = driver.current_window_handle # Almacena el ID de la ventana original
                for window_handle in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)#Coloca el foco en la nueva venta
                        driver.maximize_window() #maximizar ventana
                        try:
                            print("bonton de primera pag 1")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[4]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            print("bonton de primera pag 2")
                            driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[5]/td/a[1]').click() # click en primer boton de pagina
                            time.sleep(cte.TIME_3) #Espera
                        paginaNro=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table/tbody/tr[2]/td/font/b').text # cantidad de Paginas
                        pNro=float(paginaNro[12:len(paginaNro)])#Numero de                         
                        try:#Verifica si inicio en 1
                            #driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[3]/div/div/button[1]/span[1]').click() #pagina inicio
                            # pagini=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490c86']"))) # Pagina siguiente
                            # btn_pagini=pagini.get_attribute("onclick")
                            # driver.execute_script("arguments[0].click();", btn_pagini)
                            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490c86']"))).click() # Pagina siguiente
                            time.sleep(cte.TIME_3) #Espera
                        except:
                            py.alert("Se cargo en pagina 1",timeout=800)
                        tablaContP=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[1]/table/tbody/tr[3]/td/div/div/div/table')#ubica la tabla de detalle de la partida
                        rows1 = tablaContP.find_elements_by_tag_name('tr')#Obtine la cantidad de filas
                        k=0
                        for row in rows1:
                            try:#Capturando alguna incidencia con el excel en su hoja de trabajo
                                cols = row.find_elements_by_tag_name('td') # se puede indexar con 0, 1, 2... depende del tamanio de la tabla y la columna que queramos
                                c=0#indicador de columna
                                for col in cols:
                                    if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                        valoresE02.append(col.text)#Nueva entrada
                                    else:
                                        valoresE02[k+1]=valoresE02[k+1] + '|' + col.text                                            
                                    c=c+1
                            except:
                                py.alert("Error al leer detalle de partida", timeout=cte.AVISO2) 
                            k=k+1
                        valoresE02.append(str(pNro))  
                        try: #imicio de bloque 4
                            original_window_1 = driver.current_window_handle # Almacena el ID de  la ventana de partidas Registrales
                            i=1
                            vimagenp=""
                            vimagenps=""
                            print("Inicio de impresión cantidad de Paginas: " + str(pNro) + "=======>")
                            while i<=pNro:
                                print("Impresión de Pagina Nro" + str(i))
                                if i>1:
                                    time.sleep(cte.TIME_2) #Espera
                                    try:
                                        print("Ubicar_1  Pagina Nro " + str(i))
                                        #driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button').click() # Pagina siguiente
                                        btnpag=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                        valor_btn=btnpag.get_attribute("onclick")
                                        driver.execute_script("arguments[0].click();", btnpag)
                                    except:
                                        print("Ubicar_2  Pagina Nro " + str(i))
                                        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490cc7']"))).click() # Pagina siguiente
                                        btnpag=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//button[@id='frmVisualizar:j_id7941133_4d490cc7']"))) # Pagina siguiente
                                        valor_btn=btnpag.get_attribute("onclick")
                                        driver.execute_script("arguments[0].click();", btnpag)
                                    time.sleep(cte.TIME_3) #Espera
                                bandimg=0
                                while bandimg<=2:
                                    try:
                                        imagenp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='frmVisualizar:imagenContent']"))) #Verifica id de imagen de hoja
                                        if vimagenps== imagenp.get_attribute("src"):
                                            print("Refresca_522 Pagina Nro" + str(i))
                                            btnpag1=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn1=btnpag1.get_attribute("onclick")
                                            driver.refresh()
                                            btnpag2=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn2=btnpag2.get_attribute("onclick")
                                            driver.execute_script("arguments[0].click();", btnpag2)
                                            time.sleep(cte.TIME_3) #Espera
                                            btnpag3=driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[5]/div/div/button') # Pagina siguiente
                                            valor_btn3=btnpag3.get_attribute("onclick")
                                            bandimg=bandimg+1
                                            if bandimg>2:
                                                valoresE02[0]="0"
                                                CerrarSesion(original_window)# Cerrar Sesion
                                                return valoresE02 
                                        else:
                                            vimagenps=imagenp.get_attribute("src")
                                            vimagenp=vimagenp + imagenp.get_attribute("src") + "|"
                                            break
                                    except:
                                        driver.refresh()
                                        print("Refresca_534 Pagina Nro" + str(i))
                                        bandimg=bandimg+1
                                        if bandimg>2:
                                                valoresE02[0]="0"
                                                CerrarSesion(original_window)# Cerrar Sesion
                                                return valoresE02
                                        
                                try:
                                    print("Enlace de impresion Pagina Nro" + str(i))
                                    driver.find_element_by_xpath('/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a').click() # Enlace de impresión
                                    #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                except:
                                    driver.refresh()
                                    print("Enlace de impresion Refesh Pagina Nro" + str(i))
                                    WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '/html/body/form/table/tbody/tr/td[2]/div/table/tbody/tr/td/div[2]/div/span/table/tbody/tr/td[4]/a'))).click() # Enlace de  de impresion
                                time.sleep(cte.TIME_3) #Espera
                                try:#Verificar Alerta Para 
                                    alert = driver.switch_to_alert()
                                    mensaje=alert.text
                                    print (str(mensaje))
                                    valoresE02[k+1]=valoresE02[k+1] + '|' + str(mensaje)
                                    alert.accept()
                                    time.sleep(cte.TIME_2) #Espera
                                except:
                                    valoresE02[k+1]=valoresE02[k+1] + '|' + 'Ok'
                                    #py.alert("Se ejecutara Impresion",timeout=200)
                                print("Web de impresion Pagina Nro" + str(i))
                                for window_handle1 in driver.window_handles: # Recorrelas hasta encontrar el controlador de la nueva ventana
                                    if window_handle1 != original_window and window_handle1 != original_window_1:
                                        print("Web encontrada impresion Pagina Nro" + str(i))
                                        driver.switch_to.window(window_handle1)
                                        time.sleep(cte.TIME_1) #Espera
                                        driver.maximize_window() #maximizar ventana
                                        time.sleep(cte.TIME_3) #Espera
                                        img_imp=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//img[@id='j_id564306970_21a2a458:img']"))) #Verifica id de imagen de hoja
                                        if inicio_diver==0:
                                            pdf = driver.execute_cdp_cmd("Page.printToPDF", {"printBackground": True ,"pageRanges": '1' })
                                            if pdf !=None:
                                                print("Generación de impresión Pagina Nro" + str(i))
                                                with open(os.getcwd() +'\Descargas\Pagina' + str(i)+'.pdf', "wb") as f:
                                                    f.write(base64.b64decode(pdf['data']))
                                                f=None
                                            else:
                                                print("Error en generar PDF impresion Pagina Nro" + str(i))
                                            pdf=None
                                        else:
                                            print("Impresion impresion Pagina Nro" + str(i))
                                            try:
                                                driver.execute_script('document.title="{}";'.format('Pagina' + str(i)))#Indica el numero de pagina
                                                driver.execute_script('window.print();')
                                            except:
                                                print("Error en generar PDF impresion Pagina Nro" + str(i))
                                        driver.close() #Cierra Ventana emergente
                                        time.sleep(cte.TIME_3) #Espera
                                        driver.switch_to.window(original_window_1) #Vuelve a la ventana Original
                                        time.sleep(cte.TIME_3) #Espera
                                        print("fin de impresion Pagina Nro" + str(i))
                                        break
                                i=i+1
                            celda.value=vimagenp
                            driver.close() #Cierra Ventana 
                            driver.switch_to.window(original_window) #Vuelve a la ventana Original Principal
                            moverArchivo(rutaS1,valoresE02)#Mueve archivo descargado  a la carpeta de la aprtida 
                            CerrarSesion(original_window)# Cerrar Sesion
                            return valoresE02
                            #break
                        except:
                            valoresE02[0]="0"
                            CerrarSesion(original_window)# Cerrar Sesion
                            py.alert('Error bloque 4',timeout=cte.AVISO1)
                            return valoresE02 
            except:
                valoresE02[0]="0"
                CerrarSesion(original_window)# Cerrar Sesion
                py.alert("Error en bloque 3", timeout=cte.AVISO1)
                return valoresE02
        except:
            py.alert("Error en Bloque 2", timeout=cte.AVISO1)
            valoresE02[0]="0"
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE02
    except:
        valoresE02[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion)
        py.alert("Error en bloque N° 1", timeout=cte.AVISO1)
        return valoresE02
    #driver.switch_to.window(original_window) #Vuelve a la ventana Original
    #time.sleep(cte.TIME_5) #Espera 
#==============================================================================
#==============================================================================
# Procedimiento de busqueda por Razon Social en Area Registral, segun Propiedad
# Inmueble Predial
#==============================================================================
def BuscarSUNARP005(razonSocialB,sheet2,arear):
    try: # Bloque 1
        sheet2.cell(row=2, column=3).value="Inicio - Bloque1 - BuscarSUNARP005"
        sheet2.cell(row=3, column=3).value=razonSocialB
        nombrepn=razonSocialB.split("|")
        auxpn=len(nombrepn)
        valoresE01=["0"] # Variable de retorno
        removerArchivo() #Limpiar la carpeta descargas
        print("Inicia Seción en SUNARP-Buscar SUNARP005")
        #py.alert("Iniciando Sesion ",timeout=cte.AVISO2) #Mensaje de Inicio de sesion
        IniciarSesion(0)#Iniciar Sesion
        time.sleep(cte.TIME_1)#Espera
        original_window = driver.current_window_handle
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # Frame de opciones de la parte izquierda
        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div/div/div[1]/div/div/table/tbody/tr/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td[2]/a'))).click() #boton Búsqueda por nombre del titular registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//a[@href='/sunarpweb/pages/publicidadSimple/indice/busquedaIndicePartida.faces']"))).click() #boton Búsqueda por nombre del titular registral
        time.sleep(cte.TIME_2) #Espera
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/table/tbody/tr[3]/td/form/span[2]/span/div/div/table/tbody/tr/td/table/tbody/tr/td[2]/button[2]'))).click() #boton Búsqueda total -->|
        time.sleep(cte.TIME_2) # Por parpadeo de la pantalla
        select = Select(driver.find_element_by_id('frmIndicePartida:menuIndicePartida'))#Seleccionar objeto Area registral
        select.select_by_value(str(arear))#Selecciona  el Area Registral #select.select_by_value('1')#Selecciona persona juridica opcion 3
        if auxpn==1:
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtRazSocialPre'))).send_keys(razonSocialB)
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//input[@id='frmIndicePartida:j_id1437043120_43de052f']"))).click() #boton activos 
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:j_id1437043120_43de05db'))).click() #boton Búsqueda 
        elif auxpn==3:
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtApPaternoPre'))).send_keys(nombrepn[0])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtApMaternoPre'))).send_keys(nombrepn[1])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtNombresPre'))).send_keys(nombrepn[2])
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//input[@id='frmIndicePartida:j_id1437043120_43de03e0']"))).click() #boton activos 
            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:j_id1437043120_43de036b'))).click() #boton Búsqueda 
        time.sleep(cte.TIME_5) #Espera
        try: # Bloque 2
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP005"
            print("Busqueda de contribuyente:" + razonSocialB + "---->")
            contriNroTx=WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID,'fBusqSPE'))).text
            if len(contriNroTx)==20:
                contriNroT=contriNroTx[10:11] #Numero de pagina
            else:
                contriNroT=contriNroTx[10:len(contriNroTx)-10]#Numero de pagina
            contriNro=float(contriNroT) #Numero de pagina
            if contriNro ==0 :
                valoresE01[0]="NO SE ENCONTRÓ COINCIDENCIAS" #Variable de Resultado descargado 
                CerrarSesion(original_window)# Cerrar Sesion
                return valoresE01
            table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP005"
            print("Descarga de lista de contribuyente:" + razonSocialB + ", tiene " + contriNroT +
                  " coincidencias---->")
            a=len(rows)#Cantidad de filas de resultado
            j=0#variable de control de fila de tabla de resultado
            valoresE01[0]="SE ENCONTRÓ COINCIDENCIAS" + '|'+ contriNroT #Variable de Resultado descargado
            #valoresE01.append('Registro Público|Oficina Registral|Partida|Ficha|Tomo|Folio|Razón Social|Ruc')
            valoresE01.append('Registro Público|Oficina Registral|Partida|Ficha|Tomo|Folio|Area Registral|Registro de|Participante|Participación|Documento identidad|Número Documento|Dirección|Estado|Visualizar|Buscar BGR')
            d=1
            b=contriNro//15 + 1 # Indica la cantidad de pantallas a recorrer // obtiene cociente
            while d<=b: #Recorre pantallas 
                while j < a:
                    try:#Captura las columnas de las filas
                        cols = rows[j].find_elements_by_tag_name('td') # Capturamos las columnas de la fila de la tabla de resultados
                        #b=len(cols)#Cantidad de columnas
                        c=0#indicador de columna
                        try: #Inicio de lectura de columna
                            for col in cols:
                                if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                    valoresE01.append(col.text)#Nueva entrada al arreglo
                                else:
                                    #if c<15:#Verifica que no se ha el button
                                    if c==9 and auxpn==3:
                                        valoresE01[(d-1)*15+j+2]=valoresE01[(d-1)*15+j+2] + '|' 
                                    valoresE01[(d-1)*15+j+2]=valoresE01[(d-1)*15+j+2] + '|' + col.text #Alamcena en  el arreglo los valores de la columna
                                c=c+1
                        except:
                            py.alert("Error en lectura - Columna", timeout=cte.AVISO2)
                            print("Error en el recorrido de Columna:" + str(c))
                    except:
                        py.alert("Error al capturar datos de columna", timeout=cte.AVISO2)
                        print("Error al capturar Columna" )
                    j=j+1
                if b==1:
                    CerrarSesion(original_window)# Cerrar Sesion
                    return valoresE01
                else:
                    #inicio de bloque2
                    try:
                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//div[@id='frmResultadoPJ:tblResulPJ_paginator_bottom']/span[5]"))).click()#pagina siguiente
                        time.sleep(cte.TIME_2) #Espera
                        table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
                        table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
                        table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
                        tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
                        rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
                        a=len(rows)#Cantidad de filas de resultado
                        j=0#variable de control de fila de tabla de resultado
                        time.sleep(cte.TIME_1) #Espera
                    except:
                        valoresE01[0]="0"
                        CerrarSesion(original_window)# Cerrar 
                        sheet2.cell(row=2, column=3).value="Error  - Bloque2 - BuscarSUNARP005"
                        print("Error al cargar pagina siguiente" + str(d) + " SUNARP-BuscarSUNARP005")
                        #py.alert("Error en Bloque2 - SUNARP002",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
                        return valoresE01
                d=d+1
            CerrarSesion(original_window)# Cerrar Sesion
            if len(valoresE01)!=contriNro+2:
                valoresE01[0]="0"
            return valoresE01
        except:
            mrpta=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.CLASS_NAME,'ui-messages-error-summary'))).text
            print(mrpta)
            valoresE01[0]="NO SE ENCONTRÓ COINCIDENCIAS" #Variable de Resultado descargado 
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE01
    except:
        valoresE01[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion
        py.alert("Error en Bloque1 - SUNARP005",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
        return valoresE01
#=============================================================================    

#==============================================================================
# Procedimiento de busqueda por Razon Social en Area Registral, segun Personas 
# Juridicas
#==============================================================================
def BuscarSUNARP002(razonSocialB,sheet2):
    try: # Bloque 1
        sheet2.cell(row=2, column=3).value="Inicio - Bloque1 - BuscarSUNARP002"
        sheet2.cell(row=3, column=3).value=razonSocialB
        valoresE01=["0"] # Variable de retorno
        removerArchivo() #Limpiar la carpeta descargas
        print("Inicia Seción en SUNARP-Buscar SUNARP002")
        #py.alert("Iniciando Sesion ",timeout=cte.AVISO2) #Mensaje de Inicio de sesion
        IniciarSesion(0)#Iniciar Sesion
        time.sleep(cte.TIME_1)#Espera
        original_window = driver.current_window_handle
        driver.switch_to.frame("main_frame")#Frame de Busqueda
        driver.switch_to.frame("left_frame") # Frame de opciones de la parte izquierda
        #WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div/div/div[1]/div/div/table/tbody/tr/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td[2]/a'))).click() #boton Búsqueda por nombre del titular registral
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//a[@href='/sunarpweb/pages/publicidadSimple/indice/busquedaIndicePartida.faces']"))).click() #boton Búsqueda por nombre del titular registral
        time.sleep(cte.TIME_2) #Espera
        driver.switch_to.window(original_window)#Vuelve el foco a la pagina principal
        driver.switch_to.frame("main_frame") #Frame de Busqueda
        driver.switch_to.frame("main_frame1")#Frame de Opciones
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/table/tbody/tr[3]/td/form/span[2]/span/div/div/table/tbody/tr/td/table/tbody/tr/td[2]/button[2]'))).click() #boton Búsqueda total -->|
        time.sleep(cte.TIME_2) # Por parpadeo de la pantalla
        select = Select(driver.find_element_by_id('frmIndicePartida:menuIndicePartida'))#Seleccionar objeto Area registral
        select.select_by_value('3')#Selecciona persona juridica opcion 3
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.NAME,'frmIndicePartida:txtRazonSoc'))).send_keys(razonSocialB)
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,'/html/body/table/tbody/tr[3]/td/form/span[6]/span[1]/div[2]/div[2]/table/tbody/tr[2]/td/button/span'))).click() #boton Búsqueda 
        time.sleep(cte.TIME_5) #Espera
        try: # Bloque 2
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP002"
            print("Busqueda de contribuyente:" + razonSocialB + "---->")
            contriNroTx=WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID,'fBusqSPE'))).text
            if len(contriNroTx)==20:
                contriNroT=contriNroTx[10:11] #Numero de pagina
            else:
                contriNroT=contriNroTx[10:len(contriNroTx)-10]#Numero de pagina
            contriNro=float(contriNroT) #Numero de pagina
            table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
            table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
            table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
            tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
            rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
            sheet2.cell(row=2, column=3).value="Busqueda - Bloque2 - BuscarSUNARP002"
            print("Descarga de lista de contribuyente:" + razonSocialB + ", tiene " + contriNroT +
                  " coincidencias---->")
            a=len(rows)#Cantidad de filas de resultado
            j=0#variable de control de fila de tabla de resultado
            valoresE01[0]="SE ENCONTRÓ COINCIDENCIAS" + '|'+ contriNroT #Variable de Resultado descargado
            valoresE01.append('Registro Público|Oficina Registral|Partida|Ficha|Tomo|Folio|Razón Social|Ruc')
            d=1
            b=contriNro//15 + 1 # Indica la cantidad de pantallas a recorrer // obtiene cociente
            while d<=b: #Recorre pantallas 
                while j < a:
                    try:#Captura las columnas de las filas
                        cols = rows[j].find_elements_by_tag_name('td') # Capturamos las columnas de la fila de la tabla de resultados
                        #b=len(cols)#Cantidad de columnas
                        c=0#indicador de columna
                        try: #Inicio de lectura de columna
                            for col in cols:
                                if c==0:#verifica si es la primera entrada para agregar a variable de resultado
                                    valoresE01.append(col.text)#Nueva entrada al arreglo
                                else:
                                    if c<8:#Verifica que no se ha el button
                                        valoresE01[(d-1)*15+j+2]=valoresE01[(d-1)*15+j+2] + '|' + col.text #Alamcena en  el arreglo los valores de la columna
                                c=c+1
                        except:
                            py.alert("Error en lectura - Columna", timeout=cte.AVISO2)
                            print("Error en el recorrido de Columna:" + str(c))
                    except:
                        py.alert("Error al capturar datos de columna", timeout=cte.AVISO2)
                        print("Error al capturar Columna" )
                    j=j+1
                if b==1:
                    CerrarSesion(original_window)# Cerrar Sesion
                    return valoresE01
                else:
                    #inicio de bloque2
                    try:
                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH,"//div[@id='frmResultadoRazonSocial:tblResulRazonSoc_paginator_bottom']/span[5]"))).click()#pagina siguiente
                        time.sleep(cte.TIME_2) #Espera
                        table = driver.find_elements_by_class_name('contentClass') #'contentClass')# obtenemos los elementos que satisfacen la clase enviada como argumento
                        table_1 = table[0].find_elements_by_tag_name('table') # indexamos en 1 ya que dices que necesitas la segunda tabla
                        table_2 = table_1[3].find_elements_by_tag_name('table')#Ubicamos Tabla de resultados
                        tablaB = table_2[0].find_elements_by_tag_name('tbody')#Cuerpo de tabla
                        rows = tablaB[0].find_elements_by_tag_name('tr')#Capturamos filas d ela tabla resultados
                        a=len(rows)#Cantidad de filas de resultado
                        j=0#variable de control de fila de tabla de resultado
                        time.sleep(cte.TIME_1) #Espera
                    except:
                        valoresE01[0]="0"
                        CerrarSesion(original_window)# Cerrar 
                        sheet2.cell(row=2, column=3).value="Error  - Bloque2 - BuscarSUNARP002"
                        print("Error al cargar pagina siguiente" + str(d) + " SUNARP-BuscarSUNARP002")
                        #py.alert("Error en Bloque2 - SUNARP002",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
                        return valoresE01
                d=d+1
            CerrarSesion(original_window)# Cerrar Sesion
            if len(valoresE01)!=contriNro+2:
                valoresE01[0]="0"
            return valoresE01
        except:
            mrpta=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.CLASS_NAME,'ui-messages-error-summary'))).text
            print(mrpta)
            valoresE01[0]="NO SE ENCONTRÓ COINCIDENCIAS" #Variable de Resultado descargado 
            CerrarSesion(original_window)# Cerrar Sesion
            return valoresE01
    except:
        valoresE01[0]="0"
        CerrarSesion(original_window)# Cerrar Sesion
        py.alert("Error en Bloque1 - SUNARP002",timeout=cte.AVISO2)#Mensaje de Inicio de sesion
        return valoresE01
#=============================================================================

#==============================================================================
def unirPDF01():
#########   Declarando Constantes ##################
    OPT_SRUTA = "NO" # Botones.
    OPT_RUTA = 'SI'# Botones.
    OPT_CANCELAR = 'CANCELAR'# Botones.
    opt = py.confirm(
        "¿Desea ingresar la ruta?",
        "===> Consulta <===",
        [OPT_SRUTA,OPT_RUTA,OPT_CANCELAR]
    )

    if opt==OPT_SRUTA: #Cerrando la ventana emergente
        excel_document = openpyxl.load_workbook('Base_Contribuyente_Resultado_t.xlsx') #Base donde se encuentra el resultado a reprocesar
        sheet2= excel_document.get_sheet_by_name('Datos_Generales')
        nArch=sheet2.cell(6,3).value
        excel_document.close()
        unirPDF_aux(nArch)
    elif opt == OPT_RUTA:    #Regresar el menu de Inicio
        nArch=pyautogui.prompt('Ruta de Archivos: ', title='Ruta de Archivos a Unificar')
        time.sleep(1) #Reposa 1seg.
        unirPDF_aux(nArch)
    elif opt == OPT_CANCELAR:
        py.alert("Se Cancelo el Proceso de Unir PDFs")
    
#==============================================================================
def unirPDF_aux(nArch):
    rutaDest=os.getcwd() + '\\' + nArch
    rutaDest1=os.getcwd() + '\\' + nArch + "_PDF"
    capetaG_A(rutaDest1)
    carpetas=os.listdir(rutaDest)
    for carp in carpetas:
        carpetaSub(rutaDest1 +'\\'+ carp)
        subCarpetas = os.listdir(rutaDest+'\\'+carp)
        for subCarp in subCarpetas:
            if subCarp.count('.xlsx')==0:
                carpetaSub(rutaDest1 +'\\'+ carp  +'\\'+ subCarp)
                pdfs = os.listdir(rutaDest+'\\'+carp+'\\'+subCarp)
                p=0
                if len(pdfs)>0:
                    pass
                    while p <len(pdfs):
                        if pdfs[p][len(pdfs[p])-4:len(pdfs[p])]!='.pdf':
                            pdfs.remove(pdfs[p]) #Elimina datos del arreglo por el  contenido , para posiscion utilizar pop
                        else:
                            p=p+1
                    a=len(pdfs)
                    i=1
                    while i<a:
                        j=0
                        pNro1=float(pdfs[i][6:len(pdfs[i])-4])#Numero de pagina
                        while j<i:
                            pNro2=float(pdfs[j][6:len(pdfs[j])-4])#Numero de pagina
                            if pNro1<pNro2:
                                z=i
                                aux1=pdfs[i]
                                while z>j:
                                    pdfs[z]=pdfs[z-1]
                                    z=z-1
                                pdfs[z]=aux1
                                j=i
                            j=j+1
                        i=i+1
                    w= len(subCarp)
                    if len(subCarp)>50:
                        nombre_archivo_salida = subCarp[0:50] + ".pdf"
                    else:
                        nombre_archivo_salida = subCarp + ".pdf"
                    fusionador = PdfFileMerger()
                    for pdf in pdfs:
                        fusionador.append(open(rutaDest +'\\'+carp+'\\'+subCarp+'\\'+pdf, 'rb'))
                    with open(rutaDest1 +'\\'+carp+'\\'+subCarp+ '\\'+ nombre_archivo_salida, 'wb') as salida:
                        fusionador.write(salida)
#==============================================================================

#Procesos Principales
#==============================================================================
# Procedimiento General de Recorrido de Excel Base_Contribuyente_T.xlsx:
# Procedimiento principal ue se ativa con el boton Iniciar.
#==============================================================================
def generarAmb001():# Proceso de busqueda
    global estadoB01#Variable de Estado
    global lista_pnd
    bArchivo=ValoresAreaR()
    nhoja=bArchivo[2][bArchivo[1].index(str(areaR1))]
    print("Lectura de archivos xls-generarAmb001===>"+" Proceso nro 1")
    excel_document = openpyxl.load_workbook('Base_Contribuyente_T.xlsx')
    excel_document1 = pd.ExcelFile('Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheet = excel_document['Base']
    #sheet1 = excel_document['Resumen']
    sheet1 = excel_document[nhoja] #['B_P_Inmueble_Predial'] #
    sheet2= excel_document['Datos_Generales']
    sheetD1=excel_document1.parse('Relacion_C') #Leer relaciones
    sheetD2=excel_document1.parse('Tipo_C') #Leer relaciones
    sheet2.cell(6,3).value=nCarpetaP
    filaS1=2 #
    i=2
    valor= sheet.cell(row = i, column = 1) #Celda donde se almacena el RUC 
    valor_bc1=sheet[i]
    valor_bc2=sheet1[filaS1]
    razonSocialBB=sheet.cell(row = i, column = 2).value #Razon Social del Contribuyente
    tipoc1=sheet.cell(row = i, column = 4).value #Tipo de Contribuyente 
    valor_v=valor.value #RUC
    while not valor_v is None:
        razonSocialB= sheet.cell(row = i, column = 3).value #Razon Social de Busqueda
        band_est=0 #Bandera que se activa cuando la existe una busqueda que coincida con la partida Registral.
        if str(areaR1)=='1':
            ind_vf=8
            ind_est=17
            ind_ini=18
            resultadoB01=BuscarSUNARP005(razonSocialB,sheet2,areaR1) #Busqueda de Razon Social
            cont=0
            while resultadoB01[0]=="0" and cont<=2: #Bucle para verificar resultado de busqueda
                resultadoB01=BuscarSUNARP005(razonSocialB,sheet2,areaR1) #Busqueda de Razon Social
                cont=cont+1
        elif str(areaR1)=='3':
            ind_vf=6
            ind_est=9
            ind_ini=10
            resultadoB01=BuscarSUNARP002(razonSocialB,sheet2) #Busqueda de Razon Social
            cont=0
            while resultadoB01[0]=="0" and cont<=2: #Bucle para verificar resultado de busqueda
                resultadoB01=BuscarSUNARP002(razonSocialB,sheet2) #Busqueda de Razon Social
                cont=cont+1
        elif str(areaR1)=='6':
            ind_vf=8
            ind_est=17
            ind_ini=18
            resultadoB01=BuscarSUNARP009(razonSocialB,sheet2,areaR1) #Busqueda de Razon Social
            cont=0
            while resultadoB01[0]=="0" and cont<=2: #Bucle para verificar resultado de busqueda
                resultadoB01=BuscarSUNARP009(razonSocialB,sheet2,areaR1) #Busqueda de Razon Social
                cont=cont+1
        else:
            py.alert("Error-Opcion elegida no se encuentra implementado",timeout=408000)#Mensaje de Inicio de sesion
            Formulario()
            MenuDeInicio()
            return 
            
        a=len(resultadoB01) #Longitud
        wb = openpyxl.Workbook()
        hoja1 = wb.active
        hoja1.title='Detalle_Descarga'
        if a>1:
            rutaS=nCarpetaP + '/' + str(valor.value)
            carpetaSub(rutaS)
            b=1
            filaS0=filaS1
            while b<a: #Bucle de fila
                x=resultadoB01[b].split("|")
                c=len(x)
                d=0                
                while d<=c:#Bucle para llenar datos de columna en cada fila
                    if d<c:
                        hoja1.cell(row=b, column=d+1).value=x[d]
                        if b>1:
                            sheet1.cell(row= filaS1, column=d+1).value=x[d]
                    else:
                        if b==1:
                            hoja1.cell(row=b, column=d+1).value="Estado de Descarga"
                        else:
                            estadoD=VerificarC2(valor_bc1,x[ind_vf],sheetD1,sheetD2,valor_bc2)
                            if band_est==0:
                                hoja1.cell(row=b, column=d+1).value=estadoD[0]                            
                                sheet1.cell(row= filaS1, column=d+1).value=estadoD[0]
                            elif band_est==1:
                                if estadoD[1]==1:
                                    hoja1.cell(row=b, column=d+1).value=estadoD[0]                            
                                    sheet1.cell(row= filaS1, column=d+1).value=estadoD[0]
                                else:
                                    hoja1.cell(row=b, column=d+1).value=bool(0)                          
                                    sheet1.cell(row= filaS1, column=d+1).value=bool(0)
                    d=d+1
                wb.save(rutaS + '/' + 'Detalle_Descarga' + '.xlsx')
                if b>1:
                    sheet1.cell(row= filaS1, column=ind_ini).value=valor.value
                    sheet1.cell(row= filaS1, column=ind_ini+1).value=b-1
                    sheet1.cell(row= filaS1, column=ind_ini+2).value=razonSocialB
                    sheet1.cell(row= filaS1, column=ind_ini+3).value=sheet.cell(row = i, column = 2).value
                    if estadoD[1]==1:
                        if filaS0 < filaS1:
                            for celdat in range(filaS0,filaS1):
                                sheet1.cell(row= celdat, column=c+1).value=bool(0)
                            band_est=1
                    filaS1=filaS1+1
                    valor_bc2=sheet1[filaS1]
                b=b+1
                excel_document.save('Base_Contribuyente_Resultado_T.xlsx')
            wb.close()
        y=resultadoB01[0].split("|")
        sheet.cell(row = i, column = 7).value=y[0] # valor anterior resultadoB01[0]
        if len(y)>1:
            sheet.cell(row = i, column = 8).value=y[1]
        i=i+1
        valor= sheet.cell(row = i, column = 1)
        valor_v=valor.value
        valor_bc1=sheet[i]
        excel_document.save('Base_Contribuyente_Resultado_T.xlsx')
    i=2 # Contador
    valor= sheet1.cell(row = i, column = 1)
    valor_c= sheet1.cell(row = i, column = ind_ini+6)
    valor_v=valor.value
    while not valor_v is None:
        estadoD1=sheet1.cell(row = i, column = ind_est).value
        rutaS=nCarpetaP + '/' + str(sheet1.cell(row = i, column = ind_ini).value)
        if estadoD1==bool(1):
            if sheet1.cell(row = i, column = 3).value!="":
                rutaS1=rutaS + '/' + sheet1.cell(row = i, column = 3).value + '_' + sheet1.cell(row = i, column = 7).value
            else:
                fechaA=datetime.datetime.now()#()#Obtiene Fecha y Hora Actual
                rutaS1=rutaS + '/' + 'SNP_'+ sheet1.cell(row = i, column = 7).value + '_' + fechaA.strftime('_%H_%M_%S')#Nombre de la Carpeta
            try:
                rutaS1=rutaS1.replace(".", "_")
                sheet1.cell(row= i, column=ind_ini+5).value=rutaS1
                sheet1.cell(row= i, column=ind_ini+5).hyperlink =str(os.getcwd())+'\\'+rutaS1
                b=float(sheet1.cell(row=i,column=ind_ini+1).value)
                bandD =1
                resultadoB02=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,1,10,valor_c,areaR1)
                cont=0
                while resultadoB02[0]=="0" and cont<=2:                    
                    CerrarGoogleChrome()
                    IniciarGoogleChrome()#Iniciar el Chrome
                    resultadoB02=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,1,10,valor_c,areaR1)
                    cont=cont+1
                generarAmb002(rutaS1,resultadoB02)#Crea archivo Excel donde se almacenara el detalle
                pNro= resultadoB02[len(resultadoB02)-2]
                pNro=pNro.split("|")
                pagN=int(pNro[0])
                pag_i=11
                pag_c=10
                while pagN>=pag_i:
                    resultadoB03=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,pag_i,pag_c,valor_c,areaR1)
                    cont=0
                    while resultadoB03[0]=="0" and cont<=2:
                        CerrarGoogleChrome()
                        IniciarGoogleChrome()#Iniciar el Chrome
                        resultadoB03=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,pag_i,pag_c,valor_c,areaR1)
                        cont=cont+1
                    resultadoB02[len(resultadoB02)-2]=resultadoB02[len(resultadoB02)-2]+" : "+resultadoB03[len(resultadoB03)-2]
                    resultadoB02[len(resultadoB02)-1]=resultadoB02[len(resultadoB02)-1]+" : "+resultadoB03[len(resultadoB03)-1]
                    pag_i=pag_i+pag_c
                sheet1.cell(row= i, column=ind_ini+4).value=resultadoB02[len(resultadoB02)-2]
                sheet1.cell(row= i, column=ind_ini+9).value=resultadoB02[len(resultadoB02)-1]
            except:
                py.alert('Error Lectura - generarAmb001',timeout=cte.AVISO1)
                print(resultadoB02)
                print('/n')
                print('Error Lectura - generarAmb001')
        i=i+1
        valor= sheet1.cell(row = i, column = 1)
        valor_c= sheet1.cell(row = i, column = ind_ini+6)
        valor_v=valor.value
        valor_bc1=sheet[i]
        excel_document.save('Base_Contribuyente_Resultado_T.xlsx')
    excel_document.close()   
    py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================    
#==============================================================================
#Proccedimiento que genera archivo de Detalle_Partidas.xlsx
#Se genera solamente cuando se descarga la pagina 1
#==============================================================================
def generarAmb002(rutaS2,resultadoB02):
    wb = openpyxl.Workbook()
    hoja1 = wb.active
    hoja1.title='Detalle_Partidas'
    a=len(resultadoB02)-2
    b=0
    while b<a:
        x=resultadoB02[b].split("|")
        c=len(x)
        d=0
        while d<c:
            hoja1.cell(row=b+1, column=d+1).value=x[d]
            d=d+1
        b=b+1
        wb.save(rutaS2 + '/' + 'Detalle_Partidas' + '.xlsx')
    wb.close()

#==============================================================================
# Procedimiento General de Recorrido de Excel Base_Contribuyente_T.xlsx:
# Se ejecuta con el boton de reproceso
#==============================================================================
def generarAmb003(): # reproceso
    global estadoB01#Variable de Estado
    bArchivo=ValoresAreaR()
    nhoja=bArchivo[2][bArchivo[1].index(str(areaR1))]
    if str(areaR1)=='1':
        ind_vf=8
        ind_est=8
        ind_ini=18
    elif str(areaR1)=='3':
        ind_vf=6
        ind_est=7
        ind_ini=10
    else:
        py.alert("Error-Opcion elegida no se encuentra implementado",timeout=408000)#Mensaje de Inicio de sesion
        Formulario()
        MenuDeInicio()
        return
    excel_document = openpyxl.load_workbook('Base_Contribuyente_Resultado_T.xlsx') #Base donde se encuentra el resultado a reprocesar
    sheet = excel_document['Base'] #
    sheet1 = excel_document[nhoja] # Hoja donde se almacena el resultado #sheet1 = excel_document['Resumen']
    sheet2= excel_document['Datos_Generales']
    filaS1=2 #
    band=0
    i=2 # Contador
    valor= sheet1.cell(row = i, column = ind_ini+3) #Razon social del contribuyente
    valor_c= sheet1.cell(row = i, column = ind_ini +6) #
    valor_v=valor.value
    while not valor_v is None and band<=2:
        valor_r=sheet1.cell(row = i, column = ind_ini+7).value # Valor de Reproceso
        if not valor_r is None:
            valor_r=str(valor_r)
            rutaS=sheet2.cell(6,3).value + '/' + str(sheet1.cell(row = i, column = ind_ini).value) #Añade a la ruta principal el numero de RUC
            if sheet1.cell(row = i, column = 3).value!="":
                rutaS1=rutaS + '/' + sheet1.cell(row = i, column = 3).value + '_' + sheet1.cell(row = i, column = ind_est).value
            else:
                fechaA=datetime.datetime.now()#()#Obtiene Fecha y Hora Actual
                rutaS1=rutaS + '/' + 'SNP_'+ sheet1.cell(row = i, column = ind_est).value + '_' + fechaA.strftime('_%H_%M_%S')#Nombre de la Carpeta
            rutaS1=rutaS1.replace(".", "_")
            carpetaSub(rutaS1)#Crea sub carpeta
            if valor_r=="*":
                try:
                    sheet1.cell(row= i, column=ind_ini+5).value=rutaS1
                    sheet1.cell(row= i, column=ind_ini+5).hyperlink =str(os.getcwd())+'\\'+rutaS1
                    removerArchivo1(str(os.getcwd())+'\\'+rutaS1)
                    b=float(sheet1.cell(row=i,column=ind_ini+1).value)
                    #bandD =1
                    resultadoB02=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,1,10,valor_c,areaR1)
                    cont=0
                    while resultadoB02[0]=="0" and cont<=2:
                        CerrarGoogleChrome()
                        IniciarGoogleChrome()#Iniciar el Chrome
                        resultadoB02=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,1,10,valor_c,areaR1)
                        cont=cont+1
                    generarAmb002(rutaS1,resultadoB02)#Crea archivo Excel donde se almacenara el detalle
                    pNro= resultadoB02[len(resultadoB02)-2]
                    pNro=pNro.split("|")
                    pagN=int(pNro[0])
                    pag_i=11
                    pag_c=10
                    while pagN>=pag_i:
                        resultadoB03=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,pag_i,pag_c,valor_c,areaR1)
                        cont=0
                        while resultadoB03[0]=="0" and cont<=2:
                            CerrarGoogleChrome()
                            IniciarGoogleChrome()#Iniciar el Chrome
                            resultadoB03=BuscarSUNARP007(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,pag_i,pag_c,valor_c,areaR1)
                            cont=cont+1
                        resultadoB02[len(resultadoB02)-2]=resultadoB02[len(resultadoB02)-2]+" : "+resultadoB03[len(resultadoB03)-2]
                        resultadoB02[len(resultadoB02)-1]=resultadoB02[len(resultadoB02)-1]+" : "+resultadoB03[len(resultadoB03)-1]
                        pag_i=pag_i+pag_c
                    sheet1.cell(row= i, column=ind_ini+8).value=resultadoB02[len(resultadoB02)-2]
                    sheet1.cell(row= i, column=ind_ini+9).value=resultadoB02[len(resultadoB02)-1]
                    band=0
                except:
                    py.alert('Error Lectura- generarAmb003',timeout=cte.AVISO1)
                    print('Error Lectura- generarAmb003')
                    print(resultadoB02)
                    print('/n')
                    band=band+1
            else:
                paginas_b=valor_r.split(';')
                try:
                    sheet1.cell(row= i, column=ind_ini+5).value=rutaS1
                    sheet1.cell(row= i, column=ind_ini+5).hyperlink =str(os.getcwd())+'\\'+rutaS1
                    b=float(sheet1.cell(row=i,column=ind_ini+1).value)
                    a=len(paginas_b)
                    if a<10:
                        pag_c=a
                    else:
                        pag_c=10
                    resultadoB02=BuscarSUNARP008(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,paginas_b[0:pag_c],pag_c,valor_c,areaR1)
                    cont=0
                    while resultadoB02[0]=="0" and cont<=2:
                        CerrarGoogleChrome()
                        IniciarGoogleChrome()#Iniciar el Chrome
                        resultadoB02=BuscarSUNARP008(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,paginas_b[0:pag_c],pag_c,valor_c,areaR1)
                        cont=cont+1
                    pag_i=10
                    pag_f=pag_i+10
                    
                    while a>pag_i:
                        if a<pag_f:
                            pag_c=a-pag_i
                        else:
                            pag_c=10
                        pag_f=pag_i+pag_c
                        resultadoB03=BuscarSUNARP008(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,paginas_b[pag_i:pag_f],pag_c,valor_c,areaR1)
                        cont=0
                        while resultadoB03[0]=="0" and cont<=2:
                            CerrarGoogleChrome()
                            IniciarGoogleChrome()#Iniciar el Chrome
                            resultadoB03=BuscarSUNARP008(sheet1.cell(row = i, column = 3).value,sheet1.cell(row = i, column = 2).value,rutaS1,0,paginas_b[pag_i:pag_f],pag_c,valor_c,areaR1)
                            cont=cont+1
                        resultadoB02[len(resultadoB02)-2]=resultadoB02[len(resultadoB02)-2]+" : "+resultadoB03[len(resultadoB03)-2]
                        resultadoB02[len(resultadoB02)-1]=resultadoB02[len(resultadoB02)-1]+" : "+resultadoB03[len(resultadoB03)-1]
                        pag_i=pag_i+pag_c
                    sheet1.cell(row= i, column=ind_ini+8).value=resultadoB02[len(resultadoB02)-2]
                    sheet1.cell(row= i, column=ind_ini+9).value=resultadoB02[len(resultadoB02)-1]
                    band=0
                except:
                    py.alert('Error Lectura 2 - generarAmb003',timeout=cte.AVISO1)
                    print('Error Lectura 2- generarAmb003')
                    i=i-1
                    band=band+1
        i=i+1
        valor= sheet1.cell(row = i, column = 1)
        valor_c= sheet1.cell(row = i, column = ind_ini+6)
        valor_v=valor.value
        excel_document.save('Base_Contribuyente_Resultado_T.xlsx')
    excel_document.close()   
    #excel_document1.close()
    py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================

#==============================================================================
#Levantando proceso de Inicio
# Iniciando Chrome e iniciando Sesion
#==============================================================================
#==============================================================================
def LevantandoProcesoInicio():
    global FechaHoraInicio#variable global
    bArchivo=ValoresAreaR()
    nhoja=bArchivo[2][bArchivo[1].index(str(areaR1))]
    if nhoja=='':
        py.alert("Error-Opcion elegida no se encuentra implementado", timeout=408000)#Mensaje de Inicio de sesion
        Formulario()
        MenuDeInicio()
        return 
    IniciarGoogleChrome()#Iniciar el Chrome
    capetaG() # Genera Carpeta Gobal de busqueda
    leer_ofregistrales()# Funcion que carga en un dataframe las Oficinas Registrales
    generarAmb001()
    
#==============================================================================

def MenuDeInicio():
    if not 'areaR1' in globals(): # Se verifica si se registro el tipo de Area Registral
        Formulario()    
    #########   Declarando Constantes ##################
    OPT_CLOSE = "SÍ, CERRAR" # Botones.
    OPT_INICIAR_B = 'INICIAR'# Botones.
    OPT_REPROCESAR = "REPROCESAR"# Botones.
    OPT_CARGAR_DATA = "CARGAR DATA"# Botones.
    OPT_GENERAR_PDF = "PDFs"# Botones.
    #OPT_ACTAS = "REG_ACTAS" #  Boton para registrar actas
    opt = py.confirm(
        "**************************************************"+'\n'+   
        "Bienvenido al Robot SSUNARP" +'\n'+      
        "**************************************************"+'\n'+                                                            
        "Pre - condiciones:" +'\n' + '\n'+
        "1.- El usuario y contraseña de SUNARP extranet debe encontrarse en los archivos usuario.txt y clave.txt." +'\n'+'\n'+
        "2.- La plantilla de búsqueda de contribuyente  debe contener información referente a los representantes legales y partidas registrales."+ '\n'+'\n'+
        "3.- Los campos deben estar en formato Texto.",
        "Ejecutando Aplicativo SSUNARP V01 -Busqueda en SUNARP",
        [OPT_CLOSE,
         OPT_INICIAR_B,OPT_REPROCESAR,
         OPT_CARGAR_DATA,OPT_GENERAR_PDF]
    )

    if opt == OPT_CLOSE:#Cerrando la ventana emergente
        py.alert("Cerrando el aplicativo SSUNARP")
        
    elif opt == OPT_INICIAR_B:    #Iniciar el proceso de Busqueda
        if areaR1 ==1: # Verifica si el tipo seleccionado es Propiedad Inmueble Predial
            FormularioZR()
        navegar01()# Define el si el navegador se utilizara en segundo Plano
        LevantandoProcesoInicio()#Proceso se esta iniciando
        CerrarGoogleChrome()
        MenuDeInicio001()
    elif opt == OPT_REPROCESAR:    #Reprocesar
        navegar01()
        IniciarGoogleChrome()#Iniciar el Chrome
        leer_ofregistrales()# Funcion que carga en un dataframe las Oficinas Registrales
        generarAmb003()#Proceso se esta iniciando
        CerrarGoogleChrome()
        MenuDeInicio001()
    elif opt == OPT_CARGAR_DATA: #Procesar datos de excel
        global FechaHoraInicio#variable global
        completar_NB()#Completar el nombre de busqueda
        MenuDeInicio001()
    elif opt == OPT_GENERAR_PDF:
        global FechaHoraInicio#variable global
        unirPDF01()
        MenuDeInicio001()
#==============================================================================

def MenuDeInicio001():#Repetir menu
        #########   Declarando Constantes ##################
    global MSJ_RPTA_CERRAR01
    MSJ_RPTA_CERRAR01="Gracias, ceprocede a cerrar el aplicativo."
    global MSJ_RPTA
    MSJ_RPTA="El número de documento no pertenece al expediente"  
    
    OPT_CLOSE = "NO" # Botones.
    OPT_MENU = 'SI'# Botones.
    opt = py.confirm(
        "¿Desea regresar al menu principal?",
        "===> Consulta <===",
        [OPT_CLOSE,OPT_MENU]
    )

    if opt == OPT_CLOSE:#Cerrando la ventana emergente
        py.alert("Cerrando el aplicativo SSUNARP")
    elif opt == OPT_MENU:    #Regresar el menu de Inicio
        MenuDeInicio()
        
def navegar01():
    global inicio_diver
    OPT_V_SI= "SÍ" # Botones.
    OPT_V_NO= "NO" # Botones.
    opt1 = py.confirm(
        "**************************************************"+'\n'+   
        " ¿Desea iniciar el navegador en segundo plano?" +'\n'+      
        "**************************************************"+'\n',
        "====> Importante <====",
        [OPT_V_SI, OPT_V_NO])
    
    if opt1== OPT_V_NO:
        inicio_diver=1
    elif opt1== OPT_V_SI:
        inicio_diver=0
    else:
        inicio_diver=0
    return inicio_diver

#==============================================================================
#Proceso para cerrar el Formulario donde se seleccionara el Area Registral
#==============================================================================
def Close_Window ():
    global areaR1
    areaR1=labelAreaR.cget('text')
    APPG.destroy()
#==============================================================================
#Proceso para cerrar el Formulario donde se seleccionara la Zona Registral
#==============================================================================    
def Close_Window1 ():
    global zonaR
    zonaR=labelZonaR.cget('text')
    APPG.destroy()

    
#==============================================================================
#Formulario donde se seleccionara el Area Registral
#==============================================================================
def Formulario():
    global APPG
    global labelAreaR
    radio=[]
    APPG = tk.Tk() 
    APPG.geometry('450x380')
    radioValue = tk.IntVar() 
    areaR1=ValoresAreaR()
    i=0
    for inic in areaR1[0]:
        #print(inic)
        radio.append(tk.Radiobutton(APPG, text=str(inic),
                                 variable=radioValue, value=int(areaR1[1][i])))
        radio[i].grid(column=1, row=i, sticky="W")
        i=i+1   
    labelAreaR = tk.Label(APPG, textvariable=radioValue)
    labelAreaR.grid(column=2, row=0, sticky="E", padx=40)
    botonP=tk.Button(APPG,text="Grabar Selección",command= Close_Window)
    botonP.grid(column=2, row=i+1, sticky="E", padx=40)
    APPG.title("Seleccionar Area Registral")
    APPG.mainloop()
    
#==============================================================================
#Proceso que crea variable de Area Registral
#==============================================================================
def ValoresAreaR():
    areaRegistral =[['Propiedad Inmueble Predial','Propiedad Inmueble No Predial',
                    'Personas Juridicas','Personas Naturales','Propiedad Vehicular',
                    'Propiedad Mineria','Propiedad Emb. Pesqueras','Propiedad Aeronaves',
                    'Registro Mobiliario de Contratos','Registro de Naves'],['1','2','3',
                    '4','6','10','11','12','13','21','31'],['B_P_Inmueble_Predial',
                    '','Resumen','','B_Vehicular','','','','','','']]
    return areaRegistral

#==============================================================================
#Formulario donde se seleccionara el Area Registral
#==============================================================================
def FormularioZR():
    global APPG
    global labelZonaR
    radio=[]
    APPG = tk.Tk() 
    APPG.geometry('500x520')
    radioValue = tk.IntVar() 
    areaR1=ValoresZonaR()
    i=0
    for inic in areaR1[0]:
        #print(inic)
        radio.append(tk.Radiobutton(APPG, text=str(inic),
                                 variable=radioValue, value=str(areaR1[1][i])))
        radio[i].grid(column=1, row=i, sticky="W")
        i=i+1   
    labelZonaR = tk.Label(APPG, textvariable=radioValue)
    labelZonaR.grid(column=2, row=0, sticky="E", padx=40)
    botonP=tk.Button(APPG,text="Grabar Selección",command= Close_Window1)
    botonP.grid(column=2, row=i+1, sticky="E", padx=40)
    APPG.title("Seleccionar Area Registral")
    APPG.mainloop()

#==============================================================================
#Proceso que crea variable de Zona Registral
#==============================================================================
def ValoresZonaR():
    zonaRegistral =[['ZONA REGISTRAL I - SEDE PIURA','ZONA REGISTRAL II - SEDE CHICLAYO',
                    'ZONA REGISTRAL III - SEDE MOYOBAMBA','ZONA REGISTRAL IV - SEDE IQUITOS',
                    'ZONA REGISTRAL V - SEDE TRUJILLO','ZONA REGISTRAL VI - SEDE PUCALLPA',
                    'ZONA REGISTRAL VII - SEDE HUARAZ','ZONA REGISTRAL VIII - SEDE HUANCAYO',
                    'ZONA REGISTRAL IX - SEDE LIMA','ZONA REGISTRAL X - SEDE CUSCO',
                    'ZONA REGISTRAL XI - SEDE ICA','ZONA REGISTRAL XII - SEDE AREQUIPA',
                    'ZONA REGISTRAL XIII - SEDE TACNA','ZONA REGISTRAL XIV - SEDE AYACUCHO',
                    'TODAS LAS ZONAS REGISTRALE'],['ZR01','ZR02','ZR03', 'ZR04','ZR05','ZR06',
                    'ZR07','ZR08','ZR09','ZR10','ZR11','ZR12','ZR13','ZR14','ZR00']]
    return zonaRegistral

#==============================================================================
# Funcion principal que llama a las diversas funciones para la ejecucion de los procesos
#==============================================================================
def main():
    try:
        py.alert("Ejecutando ROBOT SSUNARP ",timeout=800)#Mensaje de incio de asignacion
        #print(areaR1)
        MenuDeInicio()
        #FormularioZR()
        print("Finalizo con exito")
    except:
        print("Se produjo un error")
        SystemExit()
    
if __name__ == "__main__":
    main()
